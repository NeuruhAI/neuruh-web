# Spatial Stack — Routing & Budgets

The Neuruh spatial layer. This file is a **routing table**, not a wish list: it says
which library owns which problem, what each surface is allowed to spend, and what the
fallback is. Every entry answers *when*, because the failure mode of a stack this large
is switching everything on at once.

**Governing rule:** no spatial canvas ships unwrapped. Mount every Three.js / R3F /
deck.gl / MapLibre / Cesium / Sigma / Spline canvas inside `SceneFrame`
(`components/spatial/`), which owns capability detection, the reduced-motion route, the
poster fallback, and scene framing. Colors, fog, lighting anchors, data ramps, and scene
choreography timing come from `tokens/spatial.css` — a scene that invents its own palette
is off-brand no matter how good it looks.

---

## 1 · Production spatial runtime

**Primary path.** Three.js + React Three Fiber, with the ecosystem R3F already maintains:

| Library | Repository | Owns |
| --- | --- | --- |
| Three.js | `mrdoob/three.js` | The renderer. Everything else sits on it. |
| React Three Fiber | `pmndrs/react-three-fiber` | Three inside React's lifecycle. Default for any scene inside a product. |
| Drei | `pmndrs/drei` | Helpers — cameras, controls, loaders, text, environments. Reach here before writing a helper. |
| gltfjsx | `pmndrs/gltfjsx` | glTF → declarative JSX. Use it; do not hand-transcribe scene graphs. |
| React Postprocessing | `pmndrs/react-postprocessing` | Bloom, DOF, outlines, tone. Budget below. |
| React Three Rapier | `pmndrs/react-three-rapier` | Physics. Only when interaction is genuinely physical. |
| React Three UI Kit | `pmndrs/uikit` | WebGL-rendered UI. Only inside XR or a fully spatial scene — never to replace DOM UI. |
| React Three XR | `pmndrs/xr` | Headset/AR sessions. |
| Three Mesh BVH | `gkjohnson/three-mesh-bvh` | Fast raycasting against dense geometry — required for parcel/terrain picking. |
| Offscreen / worker rendering | — | Only when the main thread is measurably blocked. Justify in the PR. |

**WebGPU is detected, never assumed.** Three exposes capability checks; `SceneFrame.detectTier()`
wraps them. Route order is always `webgpu → webgl → reduced → static`, and the static
route must be a real designed state, not a blank box.

**Alternates, by trigger:**

- **Babylon.js** — engine-heavy experiences (built-in physics, complex scene management) where R3F would mean rebuilding an engine.
- **PlayCanvas** — collaborative browser-based 3D production, when non-engineers must edit the scene.
- **PixiJS** — 2D/2.5D particle fields and large interactive canvases. Cheaper than 3D; use it when there is no depth.
- **OGL / regl** — a single small shader study. Do not pull Three for one quad.
- **Spline runtime** (`splinetool/react-spline`) — rapid spatial composition and prototypes. Spline exports code (vanilla JS, React, Next) and has a Code API, which makes it excellent for *arriving at* a scene. Shipping it to production is a measured decision, not a default: re-implement in R3F when the budget is tight.

## 2 · Scene & asset authoring

| Tool | When |
| --- | --- |
| Blender | Default authoring and the export gate. Everything lands as glTF. |
| Spline | Fast spatial composition, prototypes, and handoff stills. |
| Houdini | Serious procedural geometry — terrain, destruction, growth systems. |
| TouchDesigner | Generative and audio-reactive studies. Exploration only; never a runtime. |
| Unreal Engine | Offline cinematic sequences and pre-rendered source production. |
| Photogrammetry / Gaussian splats | Real-site capture for Field Scout and DeedSonar. Splats need an explicit budget — they are not free. |

**Asset pipeline is mandatory:**

- `glTF-Transform` (`donmccurdy/glTF-Transform`) — the processing step every asset passes through: prune, dedupe, resize, KTX2 textures, Draco/Meshopt compression.
- `meshoptimizer` (`zeux/meshoptimizer`) — geometry compression and vertex-cache optimization.
- No `.blend`, `.fbx`, or uncompressed `.gltf` in a shipped bundle. glTF/GLB, compressed, or it does not ship.

**Hugging Face image/text-to-3D candidates** — evaluation only, for greyboxing and
concept geometry. Nothing generative ships as final geometry without a modeller pass:

- Tencent **Hunyuan3D 2.1**
- Microsoft **TRELLIS** (image and text variants)
- Stability AI **Stable Fast 3D**
- Image-to-3D Spaces and reconstruction experiments

## 3 · Motion & authored choreography

| Library | Owns |
| --- | --- |
| GSAP + ScrollTrigger | Authored scroll sequences — pinning, scrubbing, snapping, responsive configs. The flagship's scroll spine. |
| Theatre.js | Visual timeline authoring for Three/R3F/HTML/SVG. Use when a sequence needs art direction rather than code. |
| Rive | Stateful interactive animation via its JS/WASM runtime. Icon-scale and badge-scale interactivity. |
| Motion | Component-level React transitions where CSS is not enough. |
| Lenis | Smooth scroll and WebGL scroll sync. Required whenever a canvas is scroll-driven. |
| Web Animations API | Imperative one-offs without a dependency. |
| CSS transitions | **Default.** Every state change in `css/` is CSS. Reach for a library only when CSS genuinely cannot express it. |
| Lottie | Limited pre-authored sequences only. Not a general animation strategy. |

Timing comes from tokens: UI states use `--dur-*` + `--ease-standard`; authored scenes use
`--scene-dur-beat / -move / -establish` + `--scene-ease-camera`. **No bounce, no overshoot,
no spring** — that rule holds in 3D. A camera move that oscillates is off-brand.

`--scene-pin-height` (300vh) is the default pinned-sequence length. Everything must be
reachable without scrolling: a pinned sequence may not be the only path to information.

## 4 · Shaders & advanced visual systems

Available techniques — custom GLSL/WGSL, Three node materials + TSL, SDFs, raymarching,
GPU particles, instanced geometry, procedural growth, volumetric fog, caustics, refraction
and transmission, Fresnel and iridescence, dissolve/reveal, depth-aware outlines,
data-reactive and audio-reactive materials, real-time post-processing, generative
typography, particle-to-object transformation, hybrid DOM/WebGL composition.

**The discipline, not the list, is the point.** These exist; that is not permission to
enable them together. Constraints:

- **One signature effect per surface.** A scene gets one thing nobody else has. The rest is restraint.
- **Post-processing budget: two passes.** Antialiasing does not count. Bloom *and* DOF *and* god rays *and* outlines is a smear, not depth.
- **Effects must be semantic.** Depth-aware outlines to separate a selected parcel: yes. Bloom because it looks expensive: no. Same rule that governs gradients, glass, and glow in the UI.
- **Warm and low-chroma.** Emissives use `--scene-emissive`; rim light is `--scene-rim` (brass); fog is `--scene-fog-*` (pine). No cyan glow, no purple haze.
- **Data-reactive over decorative.** A material that encodes confidence or staleness earns its cost. One that pulses for atmosphere does not.

## 5 · Graphs & living systems — Cockpit / Galaxy

| Library | When |
| --- | --- |
| Sigma.js + Graphology | Default 2D graph rendering. Graphology owns the data model regardless of renderer. |
| Cytoscape.js | Analysis-heavy graphs — pathfinding, layout algorithms, ontology inspection. |
| Cosmograph | Very large graphs (100k+ edges) needing GPU force layout. |
| React Force Graph / Three Force Graph | Fast prototypes, and the 3D Galaxy view. |
| D3 | Scales, axes, and non-graph data viz. Not the graph renderer. |
| Custom WebGL | Only after a named library has been measured and failed. |

Required behaviours: semantic zoom, temporal graph playback, ontology lenses, cluster
collapsing, selected-object isolation, progressive expansion, spatial/geographic overlays.
Node and edge encoding uses `--data-1` … `--data-6` **in order**. Never a rainbow ramp,
never more than six categories on screen — collapse instead.

## 6 · Maps, terrain & physical-world interfaces — DeedSonar / Field Scout

| Library | When |
| --- | --- |
| MapLibre GL | Default 2D basemap. Style it with `--map-*` tokens; never ship a stock style. |
| deck.gl | Data overlays on top of MapLibre — parcels, choropleths, arcs, point clouds. |
| CesiumJS | Genuine globe or 3D Tiles terrain. Heavy; needs justification. |
| kepler.gl | Internal exploration and analysis. Not a customer surface. |
| Turf.js | Client-side geometry — buffers, intersections, area. |
| PMTiles | Single-file tile hosting. The default for parcel tilesets and offline packages. |

Required capabilities: terrain meshes, satellite and parcel layers, 3D Tiles, point clouds,
slope and elevation models, time-aware layers, offline map packages, voice and directional
capture (Field Scout).

**Basemap discipline.** Land `--map-land`, water `--map-lake-900`-derived `--map-water`,
parcel lines at 10% warm black, fills in lake wash, flagged parcels in clay wash,
selection in `--lake-500`. The map is a Neuruh surface, not a Google-shaped hole in one.

> The DeedSonar kit's map pane is still a labelled placeholder. Naming the stack does not
> substitute for a tile provider and parcel geometry source — supply those and the pane
> renders against these tokens.

## 7 · Sound & presence — Neuruh.com / LARIC

| Library | When |
| --- | --- |
| Web Audio API | Positional audio, procedural cues, analyser-driven materials. |
| Tone.js | Anything musical or scheduled. Not needed for single cues. |

Rules — these are brand rules, not preferences:

- **Muted by default.** Always. Audio starts only from an explicit user gesture, via `SoundToggle`.
- **The silent route is first-class.** A visit with sound off must lose nothing but ambience. No information may live in audio alone.
- **Complete reduced-sensory route.** Reduced motion also means reduced sound: `SceneFrame.detectTier()` returning `static` implies no ambient audio.
- **Procedural confirmation cues, not sound effects.** Short, dry, pitched — a mechanism engaging. Never a chime, never a whoosh.
- **World-specific signatures.** Each product may have its own cue set; they share only the discipline. Share the foundation, never the face.
- **Optional voice** in LARIC; never required to complete a task.

## Performance budgets

Enforced per surface. A scene over budget is cut, not shipped and optimised later.

| Surface | Draw calls | Triangles | Texture memory | Bundle (spatial) | Target |
| --- | --- | --- | --- | --- | --- |
| Flagship hero | ≤ 120 | ≤ 500k | ≤ 48 MB | ≤ 600 KB gz | 60fps desktop, 30fps mobile, static route below |
| Product spatial view (Galaxy) | ≤ 200 | ≤ 300k | ≤ 32 MB | ≤ 450 KB gz | 60fps desktop, reduced route on mobile |
| Map + overlays | — | — | ≤ 64 MB tiles | ≤ 500 KB gz | 30fps pan/zoom, no dropped tiles |
| In-product object viewer | ≤ 60 | ≤ 150k | ≤ 16 MB | ≤ 250 KB gz | 60fps, static poster below |
| Operational console | **0** | — | — | **0** | No canvas. Blackbox is DOM. |

Also fixed: first meaningful paint never waits on a canvas (poster first, scene after),
scenes are lazy-loaded below the fold, and every scene is manually verified on a
mid-tier Android before it ships.

## Repository index

Three.js `mrdoob/three.js` · R3F `pmndrs/react-three-fiber` · Drei `pmndrs/drei` ·
gltfjsx `pmndrs/gltfjsx` · Postprocessing `pmndrs/postprocessing` + `pmndrs/react-postprocessing` ·
Rapier `pmndrs/react-three-rapier` · UI Kit `pmndrs/uikit` · XR `pmndrs/xr` ·
Mesh BVH `gkjohnson/three-mesh-bvh` · Rive `rive-app/rive-wasm` · Theatre.js `theatre-js/theatre` ·
GSAP `greensock/GSAP` · Lenis `darkroomengineering/lenis` · Motion `motiondivision/motion` ·
Spline `splinetool/react-spline` · Sigma.js `jacomyal/sigma.js` · Graphology `graphology/graphology` ·
Cytoscape `cytoscape/cytoscape.js` · deck.gl `visgl/deck.gl` · MapLibre `maplibre/maplibre-gl-js` ·
Cesium `CesiumGS/cesium` · kepler.gl `keplergl/kepler.gl` · Turf `Turfjs/turf` ·
PMTiles `protomaps/PMTiles` · glTF-Transform `donmccurdy/glTF-Transform` ·
meshoptimizer `zeux/meshoptimizer` · Tone.js `Tonejs/Tone.js`

*Repository paths recorded for reference. None were fetched or vendored into this project —
no spatial dependency is installed here.*
