(() => {
const { TopBar, IconButton, StatusDot, NavItem, Breadcrumbs, Tabs, Badge, Tag, Icon } = window.NeuruhDesignSystem_5cb7e4;

const LENSES = [
  { id: "domain", icon: "layers", label: "Domain", meta: "4" },
  { id: "health", icon: "activity", label: "Health", meta: "9" },
  { id: "stage", icon: "git-branch", label: "Deployment stage" },
  { id: "evidence", icon: "shield", label: "Evidence coverage" },
];

function GalaxyShell({ lens, onLens, era, onEra, collapsed, onCollapse, playing, onPlay, dim, onDim, children, inspector }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%", background: "var(--scene-void)" }}>
      <TopBar product="Galaxy"
        right={<>
          <Tabs value={dim} onChange={onDim} variant="enclosed" items={[{ id: "2d", label: "2D" }, { id: "3d", label: "3D" }]} />
          <StatusDot state="live" label="9 nodes" pulse />
          <IconButton icon="settings" size="sm" label="Settings" />
        </>}>
        <Breadcrumbs items={[{ label: "Neuruh Org", href: "#" }, { label: "Portfolio", href: "#" }, "Galaxy"]} />
      </TopBar>

      <div style={{ display: "flex", flex: 1, minHeight: 0 }}>
        <nav className="n-nav n-tex n-tex--grid" style={{ width: "var(--rail-sidebar)", flex: "none", padding: "0 8px 8px", borderRight: "1px solid var(--border-default)", background: "var(--bg-canvas)", overflow: "auto" }}>
          <div className="n-nav__group">Ontology lens</div>
          {LENSES.map((l) => (
            <NavItem key={l.id} icon={l.icon} label={l.label} meta={l.meta} active={lens === l.id} onClick={() => onLens(l.id)} />
          ))}
          <div className="n-nav__group">Clusters</div>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 6, padding: "2px 4px 10px" }}>
            {["Defense", "Real estate", "Enterprise", "Creator"].map((c) => (
              <Tag key={c} selected={collapsed.includes(c)} onClick={() => onCollapse(c)} style={{ cursor: "pointer" }}>{c}</Tag>
            ))}
          </div>
          <div className="n-nav__group">Legend</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 8, padding: "2px 6px 12px" }}>
            {[["--data-1", "Live · healthy"], ["--data-2", "Live · degraded"], ["--data-3", "Staging"], ["--data-4", "Blocked"], ["--data-5", "Planned"]].map(([v, l]) => (
              <div key={v} style={{ display: "flex", alignItems: "center", gap: 9 }}>
                <span style={{ width: 9, height: 9, borderRadius: 99, background: `var(${v})`, flex: "none" }} />
                <span style={{ font: "var(--type-body-sm)", color: "var(--text-muted)" }}>{l}</span>
              </div>
            ))}
          </div>
        </nav>

        <main style={{ flex: 1, minWidth: 0, position: "relative", display: "flex", flexDirection: "column" }}>
          <div style={{ flex: 1, minHeight: 0, position: "relative" }}>{children}</div>
          <div style={{ flex: "none", display: "flex", alignItems: "center", gap: 14, padding: "10px 16px", borderTop: "1px solid var(--border-default)", background: "var(--bg-canvas)" }}>
            <IconButton icon={playing ? "pause" : "play"} size="sm" label="Replay portfolio history" bordered onClick={onPlay} />
            <span className="n-label" style={{ flex: "none" }}>Era</span>
            <input type="range" min="2019" max="2026" step="1" value={era} onChange={(e) => onEra(Number(e.target.value))}
              style={{ flex: 1, accentColor: "var(--accent-solid)", height: 4 }} />
            <span className="n-numeric" style={{ font: "var(--type-data)", color: "var(--text-primary)", width: 44, textAlign: "right" }}>{era}</span>
          </div>
        </main>

        {inspector}
      </div>
    </div>
  );
}

Object.assign(window, { GalaxyShell, LENSES });
})();
