(() => {
const { SceneFrame, Badge, IconButton, EmptyState } = window.NeuruhDesignSystem_5cb7e4;

/* Canvas force simulation — SPECIFICATION, not a production renderer.
   See README: production routes to Sigma.js + Graphology. */

const NODES = [
  { id: "platform", label: "Execution platform", cluster: "Enterprise", r: 26, since: 2019, health: "healthy", stage: "live", evidence: 4 },
  { id: "deedsonar", label: "DeedSonar", cluster: "Real estate", r: 19, since: 2022, health: "healthy", stage: "live", evidence: 4 },
  { id: "fieldscout", label: "Field Scout", cluster: "Real estate", r: 14, since: 2024, health: "degraded", stage: "live", evidence: 3 },
  { id: "founder", label: "Founder Command", cluster: "Enterprise", r: 17, since: 2023, health: "healthy", stage: "live", evidence: 3 },
  { id: "galaxy", label: "Cockpit / Galaxy", cluster: "Enterprise", r: 15, since: 2025, health: "healthy", stage: "staging", evidence: 2 },
  { id: "adaptive", label: "Adaptive Intelligence", cluster: "Enterprise", r: 16, since: 2024, health: "degraded", stage: "staging", evidence: 2 },
  { id: "laric", label: "LARIC", cluster: "Defense", r: 15, since: 2025, health: "blocked", stage: "staging", evidence: 1 },
  { id: "fsp", label: "Find Sell Profit", cluster: "Creator", r: 13, since: 2023, health: "healthy", stage: "live", evidence: 3 },
  { id: "leadrecipe", label: "Lead Recipe OS", cluster: "Creator", r: 12, since: 2026, health: "planned", stage: "planned", evidence: 1 },
];

const EDGES = [
  ["platform", "deedsonar", 3], ["platform", "founder", 3], ["platform", "galaxy", 2],
  ["platform", "adaptive", 3], ["platform", "laric", 2], ["platform", "fsp", 2], ["platform", "leadrecipe", 1],
  ["deedsonar", "fieldscout", 3], ["deedsonar", "laric", 1], ["founder", "galaxy", 2],
  ["adaptive", "fsp", 1], ["fsp", "leadrecipe", 2], ["founder", "adaptive", 2],
];

const RAMP = { healthy: "--data-1", degraded: "--data-2", staging: "--data-3", blocked: "--data-4", planned: "--data-5" };
const CLUSTER_RAMP = { Enterprise: "--data-1", "Real estate": "--data-2", Creator: "--data-3", Defense: "--data-4" };
const STAGE_RAMP = { live: "--data-1", staging: "--data-3", planned: "--data-5" };

function colorFor(n, lens) {
  if (lens === "domain") return CLUSTER_RAMP[n.cluster] || "--data-5";
  if (lens === "stage") return STAGE_RAMP[n.stage] || "--data-5";
  if (lens === "evidence") return ["--data-4", "--data-4", "--data-3", "--data-2", "--data-1"][n.evidence] || "--data-5";
  return RAMP[n.health] || "--data-5";
}

function GalaxyGraph({ lens, era, collapsed, selected, onSelect }) {
  const ref = React.useRef(null);
  const wrapRef = React.useRef(null);
  const state = React.useRef({ nodes: [], edges: [], hover: null, css: {} });

  const visible = React.useMemo(() => {
    const shown = NODES.filter((n) => n.since <= era);
    const hidden = new Set();
    const proxies = [];
    collapsed.forEach((c) => {
      const members = shown.filter((n) => n.cluster === c && n.id !== "platform");
      if (members.length < 2) return;
      members.forEach((m) => hidden.add(m.id));
      proxies.push({
        id: "cluster:" + c, label: c, cluster: c, r: 22 + members.length * 2,
        since: Math.min(...members.map((m) => m.since)), health: members.some((m) => m.health === "blocked") ? "blocked" : members.some((m) => m.health === "degraded") ? "degraded" : "healthy",
        stage: "live", evidence: Math.round(members.reduce((a, m) => a + m.evidence, 0) / members.length),
        isCluster: true, count: members.length,
      });
    });
    const nodes = shown.filter((n) => !hidden.has(n.id)).concat(proxies);
    const idOf = (x) => (hidden.has(x) ? "cluster:" + NODES.find((n) => n.id === x).cluster : x);
    const seen = new Set();
    const edges = [];
    EDGES.forEach(([a, b, w]) => {
      const na = NODES.find((n) => n.id === a), nb = NODES.find((n) => n.id === b);
      if (na.since > era || nb.since > era) return;
      const A = idOf(a), B = idOf(b);
      if (A === B) return;
      const k = [A, B].sort().join("|");
      if (seen.has(k)) return;
      seen.add(k);
      edges.push([A, B, w]);
    });
    return { nodes, edges };
  }, [era, collapsed]);

  React.useEffect(() => {
    const cs = getComputedStyle(document.documentElement);
    const keys = ["--data-1", "--data-2", "--data-3", "--data-4", "--data-5", "--data-6", "--border-default", "--border-strong", "--text-primary", "--text-faint", "--accent-solid", "--scene-void", "--scene-haze"];
    const css = {};
    keys.forEach((k) => { css[k] = cs.getPropertyValue(k).trim(); });
    state.current.css = css;
  }, []);

  React.useEffect(() => {
    const prev = new Map(state.current.nodes.map((n) => [n.id, n]));
    state.current.nodes = visible.nodes.map((n) => {
      const p = prev.get(n.id);
      return { ...n, x: p ? p.x : 0.5 + (Math.random() - 0.5) * 0.4, y: p ? p.y : 0.5 + (Math.random() - 0.5) * 0.4, vx: 0, vy: 0 };
    });
    state.current.edges = visible.edges;
  }, [visible]);

  React.useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    let raf, alive = true;
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    function step() {
      const { nodes, edges, css } = state.current;
      const map = new Map(nodes.map((n) => [n.id, n]));
      // repulsion
      for (let i = 0; i < nodes.length; i++) {
        for (let j = i + 1; j < nodes.length; j++) {
          const a = nodes[i], b = nodes[j];
          let dx = b.x - a.x, dy = b.y - a.y;
          let d2 = dx * dx + dy * dy || 0.0001;
          const f = 0.00022 / d2;
          const d = Math.sqrt(d2);
          a.vx -= (dx / d) * f; a.vy -= (dy / d) * f;
          b.vx += (dx / d) * f; b.vy += (dy / d) * f;
        }
      }
      // springs
      edges.forEach(([A, B, w]) => {
        const a = map.get(A), b = map.get(B);
        if (!a || !b) return;
        const dx = b.x - a.x, dy = b.y - a.y;
        const d = Math.sqrt(dx * dx + dy * dy) || 0.0001;
        const target = 0.19 + (4 - w) * 0.045;
        const f = (d - target) * 0.014;
        a.vx += (dx / d) * f; a.vy += (dy / d) * f;
        b.vx -= (dx / d) * f; b.vy -= (dy / d) * f;
      });
      // centering + integrate
      nodes.forEach((n) => {
        n.vx += (0.5 - n.x) * 0.006; n.vy += (0.5 - n.y) * 0.006;
        n.vx *= 0.86; n.vy *= 0.86;
        n.x = Math.min(0.94, Math.max(0.06, n.x + n.vx));
        n.y = Math.min(0.92, Math.max(0.08, n.y + n.vy));
      });
    }

    function draw() {
      const { nodes, edges, css, hover } = state.current;
      const dpr = window.devicePixelRatio || 1;
      const W = canvas.clientWidth, H = canvas.clientHeight;
      if (canvas.width !== W * dpr || canvas.height !== H * dpr) { canvas.width = W * dpr; canvas.height = H * dpr; }
      const g = canvas.getContext("2d");
      g.setTransform(dpr, 0, 0, dpr, 0, 0);
      g.clearRect(0, 0, W, H);
      const map = new Map(nodes.map((n) => [n.id, n]));
      const neighbours = new Set();
      if (selected) {
        neighbours.add(selected);
        edges.forEach(([a, b]) => { if (a === selected) neighbours.add(b); if (b === selected) neighbours.add(a); });
      }
      const dim = (id) => selected && !neighbours.has(id);
      // edges
      edges.forEach(([A, B, w]) => {
        const a = map.get(A), b = map.get(B);
        if (!a || !b) return;
        const faded = dim(A) || dim(B);
        g.strokeStyle = faded ? css["--border-default"] : (selected ? css["--accent-solid"] : css["--border-strong"]);
        g.globalAlpha = faded ? 0.28 : selected ? 0.7 : 0.55;
        g.lineWidth = 0.6 + w * 0.5;
        g.beginPath();
        g.moveTo(a.x * W, a.y * H);
        g.lineTo(b.x * W, b.y * H);
        g.stroke();
      });
      g.globalAlpha = 1;
      // nodes
      const zoomedIn = W > 620;
      nodes.forEach((n) => {
        const faded = dim(n.id);
        const col = css[colorFor(n, lens)] || css["--data-5"];
        const x = n.x * W, y = n.y * H;
        g.globalAlpha = faded ? 0.3 : 1;
        if (n.id === selected) {
          g.beginPath(); g.arc(x, y, n.r + 7, 0, Math.PI * 2);
          g.strokeStyle = css["--accent-solid"]; g.lineWidth = 1.5; g.stroke();
        }
        g.beginPath(); g.arc(x, y, n.r, 0, Math.PI * 2);
        g.fillStyle = col; g.globalAlpha = faded ? 0.16 : 0.22; g.fill();
        g.globalAlpha = faded ? 0.4 : 1;
        g.strokeStyle = col; g.lineWidth = n.isCluster ? 2 : 1.4; g.stroke();
        if (n.isCluster) {
          g.beginPath(); g.arc(x, y, n.r - 5, 0, Math.PI * 2);
          g.setLineDash([2, 3]); g.lineWidth = 1; g.stroke(); g.setLineDash([]);
        }
        // semantic zoom: labels only when there is room
        if (zoomedIn || n.r > 18 || n.id === selected || hover === n.id) {
          g.globalAlpha = faded ? 0.35 : 1;
          g.fillStyle = n.id === selected || hover === n.id ? css["--text-primary"] : css["--text-faint"];
          g.font = `500 ${n.isCluster ? 12 : 11}px "JetBrains Mono", monospace`;
          g.textAlign = "center";
          g.fillText(n.isCluster ? `${n.label} · ${n.count}` : n.label, x, y + n.r + 15);
        }
      });
      g.globalAlpha = 1;
    }

    function loop() {
      if (!alive) return;
      if (!reduced) step();
      draw();
      raf = requestAnimationFrame(loop);
    }
    if (reduced) { for (let i = 0; i < 260; i++) step(); draw(); }
    else loop();
    return () => { alive = false; cancelAnimationFrame(raf); };
  }, [lens, selected, visible]);

  function hit(e) {
    const canvas = ref.current;
    const rect = canvas.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width, y = (e.clientY - rect.top) / rect.height;
    let best = null, bestD = Infinity;
    state.current.nodes.forEach((n) => {
      const dx = (n.x - x) * rect.width, dy = (n.y - y) * rect.height;
      const d = Math.sqrt(dx * dx + dy * dy);
      if (d < n.r + 8 && d < bestD) { best = n; bestD = d; }
    });
    return best;
  }

  return (
    <div ref={wrapRef} style={{ position: "absolute", inset: 0, background: "var(--scene-void)" }}>
      <div style={{ position: "absolute", inset: 0, background: "radial-gradient(90% 70% at 50% 55%, var(--scene-haze), transparent 70%)", pointerEvents: "none" }} />
      <canvas ref={ref} style={{ position: "absolute", inset: 0, width: "100%", height: "100%", cursor: "pointer" }}
        onClick={(e) => { const n = hit(e); onSelect(n ? n.id : null); }}
        onMouseMove={(e) => { const n = hit(e); state.current.hover = n ? n.id : null; e.currentTarget.style.cursor = n ? "pointer" : "default"; }}
      />
      <div style={{ position: "absolute", left: 16, top: 16, display: "flex", gap: 8, pointerEvents: "none" }}>
        <Badge tone="outline">{visible.nodes.length} nodes</Badge>
        <Badge tone="outline">{visible.edges.length} edges</Badge>
        {selected ? <Badge tone="accent">Isolated</Badge> : null}
      </div>
      <div style={{ position: "absolute", right: 16, bottom: 16, font: "var(--type-data-sm)", color: "var(--text-faint)", pointerEvents: "none" }}>
        Specification renderer · production routes to Sigma.js
      </div>
    </div>
  );
}

Object.assign(window, { GalaxyGraph, GALAXY_NODES: NODES, GALAXY_EDGES: EDGES });
})();
