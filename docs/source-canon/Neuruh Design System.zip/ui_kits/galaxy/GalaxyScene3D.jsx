(() => {
const { SceneFrame, Badge, EmptyState } = window.NeuruhDesignSystem_5cb7e4;

/* 3D Galaxy — the spatial lens on the same graph the 2D view renders.
   Three.js directly (nine nodes; R3F would be ceremony), force-directed in
   three dimensions, mounted inside SceneFrame so the WebGL requirement,
   reduced-motion route and poster fallback are handled once.
   Production routes to Three Force Graph per guidelines/spatial-stack.md;
   the layout math and the material language here are the specification. */

const THREE_URL = "https://unpkg.com/three@0.160.0/build/three.module.js";

/* three.js arrives as an ES module loaded once by the host page, which sets
   window.THREE. Babel-transpiled kit scripts cannot use dynamic import(). */
function waitForThree() {
  if (window.THREE) return Promise.resolve(window.THREE);
  return new Promise((resolve, reject) => {
    const t = setTimeout(() => reject(new Error("timeout")), 12000);
    window.addEventListener("three-ready", () => { clearTimeout(t); resolve(window.THREE); }, { once: true });
  });
}

function cssVar(name, fallback) {
  const v = getComputedStyle(document.documentElement).getPropertyValue(name).trim();
  return v || fallback;
}

function GalaxyScene3D({ lens, era, selected, onSelect, autorotate = true }) {
  const hostRef = React.useRef(null);
  const apiRef = React.useRef(null);
  const [ready, setReady] = React.useState(false);
  const [failed, setFailed] = React.useState(null);
  const [labels, setLabels] = React.useState([]);

  const RAMP = { healthy: "--data-1", degraded: "--data-2", staging: "--data-3", blocked: "--data-4", planned: "--data-5" };
  const CLUSTER_RAMP = { Enterprise: "--data-1", "Real estate": "--data-2", Creator: "--data-3", Defense: "--data-4" };
  const STAGE_RAMP = { live: "--data-1", staging: "--data-3", planned: "--data-5" };
  const colorKey = React.useCallback((n) => {
    if (lens === "domain") return CLUSTER_RAMP[n.cluster] || "--data-5";
    if (lens === "stage") return STAGE_RAMP[n.stage] || "--data-5";
    if (lens === "evidence") return ["--data-4", "--data-4", "--data-3", "--data-2", "--data-1"][n.evidence] || "--data-5";
    return RAMP[n.health] || "--data-5";
  }, [lens]);

  React.useEffect(() => {
    let alive = true, cleanup = null;
    (async () => {
      let THREE;
      try { THREE = await waitForThree(); }
      catch (e) { if (alive) setFailed("three.js could not be loaded from the CDN."); return; }
      if (!alive || !hostRef.current) return;

      const host = hostRef.current;
      const scene = new THREE.Scene();
      const camera = new THREE.PerspectiveCamera(42, 1, 0.1, 200);
      camera.position.set(0, 1.4, 26);
      const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
      renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
      renderer.setClearAlpha(0);
      host.appendChild(renderer.domElement);
      Object.assign(renderer.domElement.style, { position: "absolute", inset: 0, width: "100%", height: "100%", cursor: "grab" });

      /* Studio: one key, one cool fill, a warm rim. Nothing animated — the
         graph moves, the light does not. */
      scene.add(new THREE.AmbientLight(0xffffff, 0.55));
      const key = new THREE.DirectionalLight(0xfffdf8, 1.15); key.position.set(6, 9, 7); scene.add(key);
      const fill = new THREE.DirectionalLight(0x9fd4dc, 0.4); fill.position.set(-8, -2, 5); scene.add(fill);
      const rim = new THREE.DirectionalLight(0xc9a567, 0.5); rim.position.set(-3, 4, -8); scene.add(rim);

      const group = new THREE.Group();
      scene.add(group);

      const api = { THREE, scene, camera, renderer, group, nodes: [], edges: [], meshes: new Map(), lines: [], raf: 0, drag: null, rot: { x: -0.12, y: 0.4 }, spin: autorotate, selected: null, lens };
      apiRef.current = api;

      api.build = function build(era) {
        api.group.clear();
        api.meshes.clear();
        api.lines = [];
        const src = (window.GALAXY_NODES || []).filter((n) => n.since <= era);
        const ids = new Set(src.map((n) => n.id));
        api.nodes = src.map((n, i) => {
          const phi = Math.acos(1 - 2 * (i + 0.5) / src.length);
          const theta = Math.PI * (1 + Math.sqrt(5)) * i;
          const r = 4.4;
          return { ...n, x: r * Math.sin(phi) * Math.cos(theta), y: r * Math.cos(phi) * 0.7, z: r * Math.sin(phi) * Math.sin(theta), vx: 0, vy: 0, vz: 0 };
        });
        api.edges = (window.GALAXY_EDGES || []).filter(([a, b]) => ids.has(a) && ids.has(b));

        const geo = new THREE.IcosahedronGeometry(1, 3);
        api.nodes.forEach((n) => {
          const col = new THREE.Color(cssVar(colorKey(n), "#7cc0c8"));
          const mat = new THREE.MeshStandardMaterial({
            color: col, roughness: 0.42, metalness: 0.18,
            emissive: col.clone().multiplyScalar(0.22), transparent: true, opacity: 0.95,
          });
          const mesh = new THREE.Mesh(geo, mat);
          mesh.scale.setScalar(n.r / 30 + 0.24);
          mesh.userData.id = n.id;
          api.group.add(mesh);
          // Halo: a wire shell that reads as reach, not as decoration.
          const halo = new THREE.Mesh(geo, new THREE.MeshBasicMaterial({ color: col, wireframe: true, transparent: true, opacity: 0.16 }));
          halo.scale.setScalar(1.55);
          mesh.add(halo);
          api.meshes.set(n.id, mesh);
        });

        api.edges.forEach(([a, b, w]) => {
          const g = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(), new THREE.Vector3()]);
          const line = new THREE.Line(g, new THREE.LineBasicMaterial({
            color: new THREE.Color(cssVar("--border-strong", "#3a4442")), transparent: true, opacity: 0.18 + w * 0.12,
          }));
          line.userData = { a, b, w };
          api.group.add(line);
          api.lines.push(line);
        });
      };

      api.step = function step() {
        const N = api.nodes;
        for (let i = 0; i < N.length; i++) {
          for (let j = i + 1; j < N.length; j++) {
            const a = N[i], b = N[j];
            let dx = b.x - a.x, dy = b.y - a.y, dz = b.z - a.z;
            const d2 = dx * dx + dy * dy + dz * dz || 0.001;
            const d = Math.sqrt(d2);
            const f = 16 / d2;
            a.vx -= (dx / d) * f; a.vy -= (dy / d) * f; a.vz -= (dz / d) * f;
            b.vx += (dx / d) * f; b.vy += (dy / d) * f; b.vz += (dz / d) * f;
          }
        }
        const map = new Map(N.map((n) => [n.id, n]));
        api.edges.forEach(([A, B, w]) => {
          const a = map.get(A), b = map.get(B);
          if (!a || !b) return;
          const dx = b.x - a.x, dy = b.y - a.y, dz = b.z - a.z;
          const d = Math.sqrt(dx * dx + dy * dy + dz * dz) || 0.001;
          const target = 3.1 + (4 - w) * 0.7;
          const f = (d - target) * 0.012;
          a.vx += (dx / d) * f; a.vy += (dy / d) * f; a.vz += (dz / d) * f;
          b.vx -= (dx / d) * f; b.vy -= (dy / d) * f; b.vz -= (dz / d) * f;
        });
        N.forEach((n) => {
          const pull = n.id === "platform" ? 0.06 : 0.018;
          n.vx -= n.x * pull; n.vy -= n.y * pull * 1.6; n.vz -= n.z * pull;
          n.vx *= 0.84; n.vy *= 0.84; n.vz *= 0.84;
          n.x += n.vx; n.y += n.vy; n.z += n.vz;
        });
        // Soft containment: the cloud may not grow past the framed volume.
        let far = 0;
        N.forEach((n) => { far = Math.max(far, Math.hypot(n.x, n.y, n.z)); });
        if (far > 7.2) {
          const k = 7.2 / far;
          N.forEach((n) => { n.x *= k; n.y *= k; n.z *= k; });
        }
        N.forEach((n) => {
          const m = api.meshes.get(n.id);
          if (m) m.position.set(n.x, n.y, n.z);
        });
        api.lines.forEach((l) => {
          const a = map.get(l.userData.a), b = map.get(l.userData.b);
          if (!a || !b) return;
          l.geometry.setFromPoints([new THREE.Vector3(a.x, a.y, a.z), new THREE.Vector3(b.x, b.y, b.z)]);
        });
      };

      api.applySelection = function applySelection() {
        const sel = api.selected;
        const near = new Set();
        if (sel) {
          near.add(sel);
          api.edges.forEach(([a, b]) => { if (a === sel) near.add(b); if (b === sel) near.add(a); });
        }
        api.meshes.forEach((m, id) => {
          const dim = sel && !near.has(id);
          m.material.opacity = dim ? 0.16 : 0.95;
          m.material.emissiveIntensity = id === sel ? 1.6 : 1;
          m.children[0].material.opacity = dim ? 0.04 : id === sel ? 0.42 : 0.16;
        });
        api.lines.forEach((l) => {
          const on = !sel || (near.has(l.userData.a) && near.has(l.userData.b));
          l.material.opacity = on ? 0.18 + l.userData.w * 0.12 : 0.05;
          l.material.color.set(cssVar(on && sel ? "--accent-solid" : "--border-strong", "#3a4442"));
        });
      };

      api.recolor = function recolor() {
        api.meshes.forEach((m, id) => {
          const n = api.nodes.find((x) => x.id === id);
          if (!n) return;
          const col = new THREE.Color(cssVar(colorKey(n), "#7cc0c8"));
          m.material.color.copy(col);
          m.material.emissive.copy(col).multiplyScalar(0.22);
          m.children[0].material.color.copy(col);
        });
      };

      function resize() {
        const w = host.clientWidth, h = host.clientHeight;
        if (!w || !h) return;
        renderer.setSize(w, h, false);
        camera.aspect = w / h;
        camera.updateProjectionMatrix();
      }
      const ro = new ResizeObserver(resize);
      ro.observe(host);
      resize();

      /* Labels live in the DOM, not the scene — crisper, and they inherit the
         type tokens instead of re-implementing them in a texture. */
      function projectLabels() {
        const w = host.clientWidth, h = host.clientHeight;
        const v = new THREE.Vector3();
        const out = [];
        api.meshes.forEach((m, id) => {
          const n = api.nodes.find((x) => x.id === id);
          if (!n) return;
          v.setFromMatrixPosition(m.matrixWorld).project(camera);
          if (v.z > 1) return;
          out.push({ id, label: n.label, x: (v.x * 0.5 + 0.5) * w, y: (-v.y * 0.5 + 0.5) * h + m.scale.x * 26 + 10, z: v.z, dim: api.selected && api.selected !== id });
        });
        return out;
      }

      let frames = 0;
      const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
      function loop() {
        api.raf = requestAnimationFrame(loop);
        if (!reduced || frames < 240) api.step();
        if (api.spin && !api.drag && !reduced) api.rot.y += 0.0016;
        api.group.rotation.set(api.rot.x, api.rot.y, 0);
        renderer.render(scene, camera);
        if (++frames % 3 === 0) setLabels(projectLabels());
      }

      // Pointer: drag to orbit, click to isolate.
      let down = null;
      const el = renderer.domElement;
      const onDown = (e) => { down = { x: e.clientX, y: e.clientY, rx: api.rot.x, ry: api.rot.y, moved: false }; api.drag = true; el.style.cursor = "grabbing"; el.setPointerCapture(e.pointerId); };
      const onMove = (e) => {
        if (!down) return;
        const dx = e.clientX - down.x, dy = e.clientY - down.y;
        if (Math.abs(dx) + Math.abs(dy) > 4) down.moved = true;
        api.rot.y = down.ry + dx * 0.006;
        api.rot.x = Math.max(-1.1, Math.min(1.1, down.rx + dy * 0.005));
      };
      const onUp = (e) => {
        el.style.cursor = "grab";
        api.drag = false;
        if (down && !down.moved) {
          const rect = el.getBoundingClientRect();
          const ndc = new THREE.Vector2(((e.clientX - rect.left) / rect.width) * 2 - 1, -((e.clientY - rect.top) / rect.height) * 2 + 1);
          const rc = new THREE.Raycaster();
          rc.setFromCamera(ndc, camera);
          const hits = rc.intersectObjects([...api.meshes.values()], false);
          onSelect(hits.length ? hits[0].object.userData.id : null);
        }
        down = null;
      };
      const onWheel = (e) => { e.preventDefault(); camera.position.z = Math.max(13, Math.min(46, camera.position.z + e.deltaY * 0.02)); };
      el.addEventListener("pointerdown", onDown);
      el.addEventListener("pointermove", onMove);
      el.addEventListener("pointerup", onUp);
      el.addEventListener("wheel", onWheel, { passive: false });

      api.build(era);
      api.selected = selected;
      api.applySelection();
      loop();
      if (alive) setReady(true);

      cleanup = () => {
        cancelAnimationFrame(api.raf);
        ro.disconnect();
        el.removeEventListener("pointerdown", onDown);
        el.removeEventListener("pointermove", onMove);
        el.removeEventListener("pointerup", onUp);
        el.removeEventListener("wheel", onWheel);
        renderer.dispose();
        if (el.parentNode) el.parentNode.removeChild(el);
        apiRef.current = null;
      };
    })();
    return () => { alive = false; if (cleanup) cleanup(); };
  }, []);

  React.useEffect(() => { const a = apiRef.current; if (!a) return; a.build(era); a.selected = selected; a.applySelection(); }, [era]);
  React.useEffect(() => { const a = apiRef.current; if (!a) return; a.selected = selected; a.applySelection(); }, [selected]);
  React.useEffect(() => { const a = apiRef.current; if (!a) return; a.recolor(); a.applySelection(); }, [lens, colorKey]);
  React.useEffect(() => { const a = apiRef.current; if (a) a.spin = autorotate; }, [autorotate]);

  if (failed) {
    return (
      <div style={{ position: "absolute", inset: 0, display: "grid", placeItems: "center", background: "var(--scene-void)", padding: 32 }}>
        <EmptyState icon="triangle-alert" label="Spatial route unavailable" title="3D lens could not start">{failed} The 2D lens carries the same graph — switch lenses in the toolbar.</EmptyState>
      </div>
    );
  }

  return (
    <div style={{ position: "absolute", inset: 0, overflow: "hidden", background: "var(--scene-void)" }}>
      <div style={{ position: "absolute", inset: 0, background: "radial-gradient(85% 65% at 50% 50%, var(--scene-haze), transparent 72%)", pointerEvents: "none" }} />
      <div ref={hostRef} style={{ position: "absolute", inset: 0 }} />
      <div style={{ position: "absolute", inset: 0, pointerEvents: "none" }}>
        {labels.map((l) => (
          <span key={l.id} style={{
            position: "absolute", left: l.x, top: l.y, transform: "translateX(-50%)",
            font: "var(--type-data-sm)", whiteSpace: "nowrap",
            color: l.dim ? "var(--text-faint)" : "var(--text-primary)",
            opacity: l.dim ? 0.35 : 1, textShadow: "0 1px 3px rgba(8,10,10,0.85)",
          }}>{l.label}</span>
        ))}
      </div>
      <div style={{ position: "absolute", left: 16, top: 16, display: "flex", gap: 8, pointerEvents: "none" }}>
        <Badge tone="outline">3D lens</Badge>
        {selected ? <Badge tone="accent">Isolated</Badge> : null}
        {!ready ? <Badge tone="neutral">Starting…</Badge> : null}
      </div>
      <div style={{ position: "absolute", right: 16, bottom: 16, font: "var(--type-data-sm)", color: "var(--text-faint)", pointerEvents: "none" }}>
        Drag to orbit · scroll to dolly · click to isolate
      </div>
    </div>
  );
}

Object.assign(window, { GalaxyScene3D });
})();
