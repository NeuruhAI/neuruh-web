# Cockpit / Galaxy — Portfolio Spatial View

The conglomerate rendered as navigable space rather than a list of tabs. Galaxy is the
system's proof that the spatial layer and the evidence layer are the same brand — a graph
node still carries provenance and confidence.

## Screens

| File | Surface |
| --- | --- |
| `GalaxyShell.jsx` | Chrome: top bar, ontology-lens rail, timeline scrubber |
| `GalaxyGraph.jsx` | 2D lens — force-directed portfolio graph on canvas; semantic zoom, cluster collapse, selection isolation |
| `GalaxyScene3D.jsx` | 3D lens — the same graph laid out in three dimensions with three.js; orbit, dolly, click-to-isolate |
| `NodeInspector.jsx` | Selected node: health, dependencies, evidence, confidence |

## Implementation note — read before extending

The graph here is a **hand-rolled canvas force simulation**, deliberately kept to ~120
lines. It exists to specify the *visual and interaction language* — node encoding, edge
weight, semantic zoom thresholds, collapse behaviour, selection isolation, the
`--data-*` ramp in use — not to be the production renderer.

The 3D lens (`GalaxyScene3D.jsx`) is the same specification in three dimensions: a
Fibonacci-sphere seed, repulsion + spring integration with soft containment, one key /
one cool fill / one warm rim light, node spheres carrying the `--data-*` ramp with a
wireframe halo for reach, and DOM labels rather than texture labels so type tokens apply.
three.js loads as an ES module from the host page — Babel-transpiled kit scripts cannot
use dynamic `import()`.

Production routes to **Sigma.js + Graphology** (2D) or **Three Force Graph** (3D),
per `guidelines/spatial-stack.md`. Graphology owns the data model regardless of renderer.
Do not grow these files into an engine.

## Interactions wired in `index.html`

- Click a node to select and isolate it; its neighbourhood stays lit and the rest dims.
- Ontology lenses in the rail recolor the graph by a different dimension (domain, health,
  deployment stage, evidence coverage) using the same ordered ramp.
- The timeline scrubber replays portfolio state — nodes appear as they were commissioned.
- Cluster chips collapse a domain into one node and expand it again.
- `SceneFrame` wraps the canvas, so the reduced-motion route gets a static layout with no
  simulation running.

## Known gaps

- No Galaxy screenshots, source, or ontology schema were supplied. Node set, edge
  semantics, and health metrics are illustrative and drawn from the product roster in
  `SETUP_CLAUDE_DESIGN.md`.
- **Cluster collapse is 2D only.** The 3D lens renders the full node set; collapsing a
  domain into a proxy sphere needs a layout rule for the proxy's volume that has not been
  designed yet.
- **No postprocessing.** Bloom and depth-aware outlines are in the sanctioned stack and
  would suit the node halos, but they are not wired here — the surface must stay inside
  the 450 KB gz spatial budget until the real renderer lands.
