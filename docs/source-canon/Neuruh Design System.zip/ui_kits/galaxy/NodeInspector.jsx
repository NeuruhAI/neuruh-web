(() => {
const { IconButton, Badge, Button, Tabs, KeyValue, ConfidenceMeter, EvidenceChip, ProvenanceTrail, Stat, Sparkline, EmptyState, Icon } = window.NeuruhDesignSystem_5cb7e4;

const DETAIL = {
  platform: { domain: "Enterprise", stage: "Live", since: "2019", owner: "Core", budget: "—", uptime: "99.98%", trend: [8, 8, 9, 9, 9, 10, 10] },
  deedsonar: { domain: "Real estate", stage: "Live", since: "2022", owner: "RE pod", budget: "450 KB gz", uptime: "99.91%", trend: [4, 5, 6, 7, 8, 9, 11] },
  fieldscout: { domain: "Real estate", stage: "Live", since: "2024", owner: "RE pod", budget: "250 KB gz", uptime: "98.40%", trend: [6, 6, 5, 5, 4, 4, 3] },
  founder: { domain: "Enterprise", stage: "Live", since: "2023", owner: "Ops", budget: "450 KB gz", uptime: "99.86%", trend: [5, 6, 6, 7, 7, 8, 8] },
  galaxy: { domain: "Enterprise", stage: "Staging", since: "2025", owner: "Ops", budget: "450 KB gz", uptime: "—", trend: [1, 2, 3, 4, 5, 6, 8] },
  adaptive: { domain: "Enterprise", stage: "Staging", since: "2024", owner: "Core", budget: "600 KB gz", uptime: "—", trend: [7, 6, 6, 6, 5, 5, 5] },
  laric: { domain: "Defense", stage: "Staging", since: "2025", owner: "Legal", budget: "250 KB gz", uptime: "—", trend: [3, 3, 2, 2, 2, 1, 1] },
  fsp: { domain: "Creator", stage: "Live", since: "2023", owner: "Creator pod", budget: "250 KB gz", uptime: "99.72%", trend: [4, 5, 5, 6, 7, 7, 9] },
  leadrecipe: { domain: "Creator", stage: "Planned", since: "2026", owner: "Creator pod", budget: "—", uptime: "—", trend: [1, 1, 1, 2, 2, 2, 2] },
};

function NodeInspector({ id, onClose }) {
  const [tab, setTab] = React.useState("health");
  const node = (window.GALAXY_NODES || []).find((n) => n.id === id);
  const isCluster = id && id.startsWith("cluster:");
  const d = DETAIL[id];

  return (
    <aside style={{ width: "var(--rail-inspector)", flex: "none", borderLeft: "1px solid var(--border-default)", background: "var(--bg-canvas)", overflow: "auto" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10, height: "var(--bar-height)", padding: "0 12px 0 16px", borderBottom: "1px solid var(--border-default)" }}>
        <span className="n-label" style={{ flex: 1 }}>Node</span>
        <IconButton icon="x" size="sm" label="Close inspector" onClick={onClose} />
      </div>

      {!id ? (
        <EmptyState icon="crosshair" title="No node selected">Click any node to isolate its neighbourhood and read its health, dependencies, and evidence coverage.</EmptyState>
      ) : isCluster ? (
        <div style={{ padding: 16 }}>
          <Badge tone="accent">Collapsed cluster</Badge>
          <h2 style={{ font: "var(--type-h2)", letterSpacing: "var(--tracking-tight)", color: "var(--text-primary)", margin: "12px 0 6px" }}>{id.replace("cluster:", "")}</h2>
          <p style={{ font: "var(--type-body-sm)", color: "var(--text-muted)", margin: 0 }}>Expand this cluster from the rail to inspect member systems individually.</p>
        </div>
      ) : (
        <>
          <div className="n-tex n-tex--grid" style={{ padding: 16 }}>
            <div style={{ font: "var(--type-data)", color: "var(--text-accent)" }}>{id}</div>
            <h2 style={{ font: "var(--type-h2)", letterSpacing: "var(--tracking-tight)", color: "var(--text-primary)", margin: "6px 0 4px" }}>{node ? node.label : id}</h2>
            <div style={{ font: "var(--type-body-sm)", color: "var(--text-muted)" }}>{d ? `${d.domain} · commissioned ${d.since}` : ""}</div>
            <div style={{ display: "flex", gap: 8, marginTop: 14, flexWrap: "wrap" }}>
              <Badge tone={node && node.health === "healthy" ? "verified" : node && node.health === "blocked" ? "critical" : "caution"}>
                {node ? node.health : "unknown"}
              </Badge>
              <Badge tone="outline">{d ? d.stage : ""}</Badge>
            </div>
          </div>
          <hr className="n-rule" />
          <div style={{ padding: "0 16px" }}>
            <Tabs value={tab} onChange={setTab} items={[
              { id: "health", label: "Health" },
              { id: "deps", label: "Dependencies" },
              { id: "evidence", label: "Evidence" },
            ]} />
          </div>

          {tab === "health" ? (
            <div style={{ padding: "16px" }}>
              <div style={{ display: "flex", gap: 24, marginBottom: 18 }}>
                <Stat size="sm" label="Uptime 90d" value={d ? d.uptime : "—"} />
                <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                  <span className="n-label">Trend</span>
                  <Sparkline values={d ? d.trend : [1, 1]} tone={node && node.health === "healthy" ? "verified" : node && node.health === "blocked" ? "critical" : "caution"} />
                </div>
              </div>
              <KeyValue items={[
                { key: "Domain", value: d ? d.domain : "—" },
                { key: "Stage", value: d ? d.stage : "—" },
                { key: "Owner", value: d ? d.owner : "—" },
                { key: "Bundle budget", value: d ? d.budget : "—" },
                { key: "Commissioned", value: d ? d.since : "—" },
              ]} />
            </div>
          ) : tab === "deps" ? (
            <div style={{ padding: "12px 16px 20px", display: "flex", flexDirection: "column", gap: 2 }}>
              {(window.GALAXY_EDGES || []).filter(([a, b]) => a === id || b === id).map(([a, b, w]) => {
                const other = a === id ? b : a;
                const on = (window.GALAXY_NODES || []).find((n) => n.id === other);
                return (
                  <div key={other} style={{ display: "flex", alignItems: "center", gap: 12, minHeight: "var(--row-height)", borderBottom: "1px solid var(--border-subtle)" }}>
                    <Icon name="link-2" size={14} style={{ color: "var(--text-faint)", flex: "none" }} />
                    <span style={{ flex: 1, font: "var(--type-ui)", color: "var(--text-primary)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{on ? on.label : other}</span>
                    <span style={{ display: "flex", gap: 2 }}>
                      {[1, 2, 3].map((i) => (
                        <span key={i} style={{ width: 4, height: 10, borderRadius: 1, background: i <= w ? "var(--accent-solid)" : "var(--bg-surface-active)" }} />
                      ))}
                    </span>
                  </div>
                );
              })}
            </div>
          ) : (
            <div style={{ padding: "16px" }}>
              <ConfidenceMeter value={node ? node.evidence * 25 : 0} label="Evidence coverage"
                basis={node ? `${node.evidence} of 4 required source classes attached` : ""} />
              <div style={{ display: "flex", gap: 8, margin: "16px 0", flexWrap: "wrap" }}>
                <EvidenceChip state="verified" source="Deployment log" />
                <EvidenceChip state={node && node.evidence >= 3 ? "verified" : "unverified"} source="Telemetry" />
              </div>
              <ProvenanceTrail rows={[
                { source: "Deployment log", value: d ? `${d.stage} since ${d.since}` : "—", stamp: "07-31 09:14Z", state: "verified" },
                { source: "Telemetry", value: d ? `uptime ${d.uptime}` : "—", stamp: "07-31 09:12Z", state: node && node.evidence >= 3 ? "verified" : "unverified" },
                { source: "Asset manifest", value: d ? `budget ${d.budget}` : "—", stamp: "07-28 00:00Z", state: "verified" },
              ]} />
            </div>
          )}
        </>
      )}
    </aside>
  );
}

Object.assign(window, { NodeInspector });
})();
