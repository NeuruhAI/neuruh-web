(() => {
const { Icon, Badge, StatusDot, Wordmark } = window.NeuruhDesignSystem_5cb7e4;

const TABS = [
  { id: "targets", icon: "layers", label: "Targets", count: 6 },
  { id: "capture", icon: "scan-line", label: "Capture" },
  { id: "map", icon: "map-pin", label: "Map" },
  { id: "queue", icon: "refresh-cw", label: "Queue", count: 3 },
];

function ScoutShell({ tab, onTab, online, queued, title, children }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%", background: "var(--bg-sunken)", overflow: "hidden" }}>
      <header style={{ flex: "none", padding: "10px 16px 12px", background: "var(--bg-canvas)", borderBottom: "1px solid var(--border-default)" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <Wordmark size="sm" monogram product="Field Scout" />
          <span style={{ flex: 1 }} />
          <StatusDot state={online ? "live" : "caution"} label={online ? "Online" : "Offline"} pulse={online} />
        </div>
        <h1 style={{ font: "var(--type-h2)", letterSpacing: "var(--tracking-tight)", color: "var(--text-primary)", margin: "12px 0 0" }}>{title}</h1>
      </header>

      {!online ? (
        <div style={{ flex: "none", display: "flex", alignItems: "center", gap: 10, padding: "10px 16px", background: "var(--status-caution-wash)", borderBottom: "1px solid var(--border-default)" }}>
          <Icon name="triangle-alert" size={15} style={{ color: "var(--status-caution)", flex: "none" }} />
          <span style={{ font: "var(--type-body-sm)", color: "var(--status-caution)", flex: 1 }}>
            Working offline. {queued} capture{queued === 1 ? "" : "s"} queued locally.
          </span>
        </div>
      ) : null}

      <main style={{ flex: 1, minHeight: 0, overflow: "auto", WebkitOverflowScrolling: "touch" }}>{children}</main>

      <nav style={{ flex: "none", display: "grid", gridTemplateColumns: `repeat(${TABS.length}, 1fr)`, background: "var(--bg-canvas)", borderTop: "1px solid var(--border-default)", paddingBottom: 4 }}>
        {TABS.map((t) => {
          const active = tab === t.id;
          return (
            <button key={t.id} type="button" onClick={() => onTab(t.id)}
              style={{
                position: "relative", minHeight: 56, display: "flex", flexDirection: "column", alignItems: "center",
                justifyContent: "center", gap: 4, background: "none", border: 0, cursor: "pointer",
                color: active ? "var(--text-accent)" : "var(--text-faint)",
                transition: "color var(--dur-fast) var(--ease-standard)",
              }}>
              {active ? <span style={{ position: "absolute", top: 0, left: 12, right: 12, height: 2, background: "var(--accent-solid)" }} /> : null}
              <span style={{ position: "relative" }}>
                <Icon name={t.icon} size={20} />
                {t.count ? (
                  <span style={{ position: "absolute", top: -4, right: -9, minWidth: 15, height: 15, padding: "0 3px", display: "grid", placeItems: "center", borderRadius: 99, background: "var(--accent-solid)", font: "var(--type-data-sm)", fontSize: 9, color: "var(--text-on-accent)" }}>{t.count}</span>
                ) : null}
              </span>
              <span style={{ font: "var(--type-data-sm)", fontSize: 10, letterSpacing: "0.06em" }}>{t.label}</span>
            </button>
          );
        })}
      </nav>
    </div>
  );
}

Object.assign(window, { ScoutShell, SCOUT_TABS: TABS });
})();
