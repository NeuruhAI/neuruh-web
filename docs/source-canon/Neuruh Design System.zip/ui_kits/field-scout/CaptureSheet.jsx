(() => {
const { Icon, Badge, Button, Field, Select, Switch, EvidenceChip, KeyValue, Progress, EmptyState, SoundToggle } = window.NeuruhDesignSystem_5cb7e4;

function CaptureSheet({ id, onBack, onSubmit, online }) {
  const [shots, setShots] = React.useState(2);
  const [condition, setCondition] = React.useState("Fair");
  const [occupied, setOccupied] = React.useState(true);
  const [voice, setVoice] = React.useState(false);
  const target = (window.ASSIGNED || []).find((a) => a.id === id) || { addr: "3114 Nanticoke Rd", city: "Salisbury" };
  return (
    <div style={{ display: "flex", flexDirection: "column", minHeight: "100%" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "10px 12px", borderBottom: "1px solid var(--border-subtle)" }}>
        <Button size="lg" variant="ghost" icon="arrow-right" onClick={onBack} style={{ transform: "scaleX(-1)", minWidth: 44 }} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ font: "var(--type-data)", color: "var(--text-accent)" }}>{id}</div>
          <div style={{ font: "var(--type-body-sm)", color: "var(--text-muted)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{target.addr}</div>
        </div>
        <SoundToggle on={voice} onChange={setVoice} label="Voice note" />
      </div>

      <div style={{ padding: "16px 16px 8px" }}>
        <span className="n-label">Photo set · {shots} of 6</span>
        <Progress value={(shots / 6) * 100} tone={shots >= 4 ? "verified" : "caution"} style={{ marginTop: 8 }} />
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 8, marginTop: 12 }}>
          {["Front elevation", "Street view", "Rear", "Outbuilding", "Damage", "Boundary"].map((label, i) => {
            const taken = i < shots;
            return (
              <button key={label} type="button" onClick={() => setShots(Math.max(shots, i + 1))}
                className={taken ? "" : "n-hatch"}
                style={{
                  aspectRatio: "1", minHeight: 88, display: "flex", flexDirection: "column",
                  alignItems: "center", justifyContent: "center", gap: 6, cursor: "pointer",
                  background: taken ? "var(--bg-surface-raised)" : undefined,
                  border: `1px solid ${taken ? "var(--border-accent)" : "var(--border-default)"}`,
                  borderRadius: "var(--radius-3)", padding: 6,
                }}>
                <Icon name={taken ? "circle-check" : "scan-line"} size={17} style={{ color: taken ? "var(--status-verified)" : "var(--text-faint)" }} />
                <span style={{ font: "var(--type-data-sm)", fontSize: 9.5, letterSpacing: "0.06em", textTransform: "uppercase", color: taken ? "var(--text-muted)" : "var(--text-faint)", textAlign: "center", lineHeight: 1.25 }}>{label}</span>
              </button>
            );
          })}
        </div>
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 16, padding: "16px" }}>
        <Field label="Condition" htmlFor="cond">
          <Select id="cond" size="lg" value={condition} onChange={(e) => setCondition(e.target.value)}
            options={["Good", "Fair", "Poor", "Uninhabitable"]} />
        </Field>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", minHeight: 44, gap: 12 }}>
          <span style={{ font: "var(--type-body)", color: "var(--text-body)" }}>Appears occupied</span>
          <Switch checked={occupied} onChange={(e) => setOccupied(e.target.checked)} />
        </div>
      </div>

      <div style={{ margin: "0 16px", padding: "14px 16px", background: "var(--bg-inset)", border: "1px solid var(--border-default)", borderRadius: "var(--radius-3)" }}>
        <span className="n-label">Capture signature</span>
        <div style={{ marginTop: 10 }}>
          <KeyValue items={[
            { key: "GPS", value: "38.3607°N 75.5994°W" },
            { key: "Accuracy", value: "±3.2 m" },
            { key: "Heading", value: "214° SW" },
            { key: "Captured", value: "2026-07-31 14:08Z" },
            { key: "Device", value: "FS-0142" },
          ]} />
        </div>
        <div style={{ marginTop: 12 }}>
          <EvidenceChip state="verified" source="Field capture" id="FS-0142" />
        </div>
      </div>

      <div style={{ marginTop: "auto", padding: "16px", paddingTop: 20, position: "sticky", bottom: 0, background: "linear-gradient(to top, var(--bg-sunken) 60%, transparent)" }}>
        <Button variant="primary" size="lg" block icon={online ? "check" : "clock"} onClick={onSubmit}
          style={{ minHeight: 48 }}>
          {online ? "Sign and submit" : "Sign and queue"}
        </Button>
        <p style={{ font: "var(--type-body-sm)", color: "var(--text-faint)", textAlign: "center", margin: "10px 0 0" }}>
          {online ? "Uploads immediately and attaches to the record." : "Stored locally and reconciled when service returns."}
        </p>
      </div>
    </div>
  );
}

Object.assign(window, { CaptureSheet });
})();
