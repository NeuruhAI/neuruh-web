(() => {
const { Icon, Badge, Button, EvidenceChip, EmptyState, Card } = window.NeuruhDesignSystem_5cb7e4;

const ASSIGNED = [
  { id: "04-118-227", addr: "3114 Nanticoke Rd", city: "Salisbury", dist: "0.4 mi", state: "conflict", sync: "queued", task: "Verify occupancy" },
  { id: "04-118-231", addr: "3120 Nanticoke Rd", city: "Salisbury", dist: "0.4 mi", state: "clean", sync: "synced", task: "Photo set" },
  { id: "07-402-009", addr: "812 Bay St", city: "Berlin", dist: "11.2 mi", state: "lien", sync: "pending", task: "Condition report" },
  { id: "07-402-114", addr: "44 Commerce Way", city: "Berlin", dist: "11.8 mi", state: "clean", sync: "pending", task: "Boundary photos" },
  { id: "11-006-882", addr: "9 Tull Rd", city: "Princess Anne", dist: "24.6 mi", state: "conflict", sync: "pending", task: "Owner contact" },
  { id: "11-006-903", addr: "17 Tull Rd", city: "Princess Anne", dist: "24.7 mi", state: "probate", sync: "pending", task: "Verify occupancy" },
];

const FLAG = { clean: ["verified", "Clean"], conflict: ["critical", "Conflict"], lien: ["caution", "Lien"], probate: ["caution", "Probate"] };
const SYNC = { synced: ["verified", "circle-check", "Synced"], queued: ["caution", "clock", "Queued"], pending: ["neutral", "circle-alert", "Not captured"] };

function SweepList({ onOpen, filter }) {
  const rows = filter === "all" ? ASSIGNED : ASSIGNED.filter((r) => r.sync !== "synced");
  if (!rows.length) {
    return <EmptyState icon="circle-check" title="Route complete">Every assigned target has been captured and synced.</EmptyState>;
  }
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 10, padding: "14px 12px 24px" }}>
      {rows.map((r) => {
        const [tone, text] = FLAG[r.state];
        const [sTone, sIcon, sText] = SYNC[r.sync];
        return (
          <button key={r.id} type="button" onClick={() => onOpen(r.id)}
            style={{
              display: "flex", flexDirection: "column", gap: 10, textAlign: "left", width: "100%",
              minHeight: 88, padding: "14px 16px", cursor: "pointer",
              background: "var(--bg-surface)", backgroundImage: "var(--sheen-panel)",
              border: "1px solid var(--border-default)", borderLeft: `2px solid ${r.state === "clean" ? "transparent" : "var(--status-" + (tone === "critical" ? "critical" : "caution") + ")"}`,
              borderRadius: "var(--radius-3)", boxShadow: "var(--elevation-card)",
            }}>
            <div style={{ display: "flex", alignItems: "flex-start", gap: 12 }}>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ font: "var(--type-data)", color: "var(--text-accent)" }}>{r.id}</div>
                <div style={{ font: "var(--type-body)", color: "var(--text-primary)", marginTop: 4 }}>{r.addr}</div>
                <div style={{ font: "var(--type-body-sm)", color: "var(--text-faint)", marginTop: 2 }}>{r.city} · {r.dist}</div>
              </div>
              <Badge tone={tone}>{text}</Badge>
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 10, paddingTop: 10, borderTop: "1px solid var(--border-subtle)" }}>
              <Icon name="crosshair" size={13} style={{ color: "var(--text-faint)" }} />
              <span style={{ font: "var(--type-body-sm)", color: "var(--text-muted)", flex: 1 }}>{r.task}</span>
              <span style={{ display: "inline-flex", alignItems: "center", gap: 5, font: "var(--type-data-sm)", color: `var(--status-${sTone === "neutral" ? "inert" : sTone})` }}>
                <Icon name={sIcon} size={12} />
                {sText}
              </span>
            </div>
          </button>
        );
      })}
    </div>
  );
}

Object.assign(window, { SweepList, ASSIGNED });
})();
