# Field Scout — Mobile Capture

The on-site surface. Field Scout is the only Neuruh product used standing in a yard with
one hand and cellular service that comes and goes, so it is the design system's proof that
the language works at 44px touch targets on a 390pt screen.

## Screens

| File | Surface |
| --- | --- |
| `ScoutShell.jsx` | Mobile chrome: compact bar, offline banner, bottom tab bar (56px, 44px+ targets) |
| `SweepList.jsx` | Assigned targets — thumb-reachable cards, sync state per row |
| `CaptureSheet.jsx` | Capture flow — photo slots, condition form, GPS + signing, queue |

## What is different from desktop, and why

- **Touch targets are 44px minimum**, tab bar rows 56px. Desktop's 28px `sm` controls do
  not appear here at all.
- **One primary action per view**, pinned to the bottom of the thumb arc — not in a header.
- **Offline is a first-class state**, not an error. The banner reports queue depth; captures
  sign and queue locally and reconcile later. Nothing blocks on the network.
- **Evidence still applies.** A capture is signed with GPS, heading, device, and timestamp,
  and carries an `EvidenceChip` the moment it is taken. Ground truth is a source like any
  other.
- Density steps down: `density="loose"` rows, larger type, fewer columns. The mono system
  label survives — it is the strongest brand carrier at small sizes.

## Known gaps

- No Field Scout screenshots, source, or device specs were supplied. This is a
  reconstruction from the written brief ("mobile capture · voice and directional capture ·
  offline map packages") plus the token system.
- Camera, GPS, compass, and voice capture are represented, not implemented.
- The map package pane is an `EmptyState` — same blocker as DeedSonar: no tile provider.
