(() => {
const { TopBar, IconButton, StatusDot, NavItem, Breadcrumbs, Switch, Button } = window.NeuruhDesignSystem_5cb7e4;

const NAV = [
  { group: "Surveillance", items: [
    { id: "sweep", icon: "radar", label: "Sweep board", meta: "12" },
    { id: "stream", icon: "terminal", label: "Diagnostic stream", meta: "418" },
  ]},
  { group: "Sources", items: [
    { id: "feeds", icon: "database", label: "Feeds", meta: "9" },
    { id: "lineage", icon: "git-branch", label: "Lineage", meta: "318" },
  ]},
  { group: "Control", items: [
    { id: "policy", icon: "shield", label: "Policy" },
    { id: "audit", icon: "lock", label: "Audit log" },
  ]},
];

function ConsoleRail({ view, onView, collapsed }) {
  return (
    <nav className="n-nav" style={{
      width: collapsed ? "var(--rail-sidebar-collapsed)" : "var(--rail-sidebar)",
      flex: "none", padding: collapsed ? "8px 8px" : "0 8px 8px",
      borderRight: "1px solid var(--border-default)", background: "var(--bg-canvas)",
      overflow: "hidden", transition: "width var(--dur-base) var(--ease-standard)",
    }}>
      {NAV.map((g) => (
        <React.Fragment key={g.group}>
          {collapsed ? <div style={{ height: 16 }} /> : <div className="n-nav__group">{g.group}</div>}
          {g.items.map((it) => (
            <NavItem key={it.id} icon={it.icon} label={collapsed ? "" : it.label}
              meta={collapsed ? undefined : it.meta} active={view === it.id} onClick={() => onView(it.id)} />
          ))}
        </React.Fragment>
      ))}
      {!collapsed ? (
        <div style={{ marginTop: "auto", paddingTop: 20 }}>
          <div className="n-label" style={{ marginBottom: 8 }}>Build</div>
          <div style={{ font: "var(--type-data-sm)", color: "var(--text-faint)", lineHeight: 1.7 }}>
            blackbox 4.2.1<br />run 0x4E2<br />us-east-1b
          </div>
        </div>
      ) : null}
    </nav>
  );
}

function ConsoleShell({ view, onView, collapsed, onToggleRail, live, onLive, crumbs, children, inspector }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%", background: "var(--bg-sunken)" }}>
      <TopBar product="Blackbox"
        left={<IconButton icon="panel-left" size="sm" label="Toggle rail" pressed={collapsed} onClick={onToggleRail} />}
        right={<>
          <Switch label="Live" checked={live} onChange={(e) => onLive(e.target.checked)} />
          <StatusDot state={live ? "live" : "inert"} label={live ? "Streaming" : "Halted"} pulse={live} />
          <span style={{ width: 8 }} />
          <IconButton icon="bell" size="sm" label="Alerts" />
          <IconButton icon="settings" size="sm" label="Settings" />
        </>}>
        <Breadcrumbs items={crumbs} />
      </TopBar>
      <div style={{ display: "flex", flex: 1, minHeight: 0 }}>
        <ConsoleRail view={view} onView={onView} collapsed={collapsed} />
        <main style={{ flex: 1, minWidth: 0, overflow: "auto", padding: "20px 24px" }}>{children}</main>
        {inspector}
      </div>
    </div>
  );
}

Object.assign(window, { ConsoleShell, ConsoleRail });
})();
