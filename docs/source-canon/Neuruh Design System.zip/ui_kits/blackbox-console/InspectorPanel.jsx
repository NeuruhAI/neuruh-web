(() => {
const { ConfidenceMeter, ProvenanceTrail, EvidenceChip, Button, IconButton, Tabs, KeyValue } = window.NeuruhDesignSystem_5cb7e4;

const RECORDS = {
  "04-118-227": {
    owner: "MARTIN, R & K", county: "Wicomico, MD", conf: 86, assessed: "$284,100", acres: "0.41",
    coords: "38.3607°N 75.5994°W", built: "1974", deed: "DEED 2019-4412",
    rows: [
      { source: "SDAT", value: "MARTIN, R & K", stamp: "07-28 03:14Z", state: "verified" },
      { source: "Clerk of Court", value: "MARTIN, ROBERT A", stamp: "07-14 09:02Z", state: "conflict" },
      { source: "USPS NCOA", value: "MARTIN, ROBERT", stamp: "06-30 11:47Z", state: "unverified" },
      { source: "Tax roll 2025", value: "MARTIN, R & K", stamp: "01-12 00:00Z", state: "verified" },
    ],
  },
  "11-006-882": {
    owner: "REDDEN, A & J", county: "Somerset, MD", conf: 44, assessed: "$88,700", acres: "1.02",
    coords: "38.0114°N 75.8712°W", built: "1961", deed: "DEED 2004-0918",
    rows: [
      { source: "SDAT", value: "REDDEN, A & J", stamp: "07-28 03:12Z", state: "verified" },
      { source: "Clerk of Court", value: "REDDEN ESTATE", stamp: "05-02 14:20Z", state: "conflict" },
      { source: "MLS bridge", value: "unreachable", stamp: "—", state: "unverified" },
    ],
  },
};

function InspectorPanel({ id, onClose, onOpenProvenance }) {
  const r = RECORDS[id] || RECORDS["04-118-227"];
  const [tab, setTab] = React.useState("evidence");
  return (
    <aside style={{ width: "var(--rail-inspector)", flex: "none", borderLeft: "1px solid var(--border-default)", background: "var(--bg-canvas)", overflow: "auto" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10, height: "var(--bar-height)", padding: "0 12px 0 16px", borderBottom: "1px solid var(--border-default)" }}>
        <span className="n-label" style={{ flex: 1 }}>Inspector</span>
        <IconButton icon="external-link" size="sm" label="Open full record" />
        <IconButton icon="x" size="sm" label="Close inspector" onClick={onClose} />
      </div>
      <div className="n-tex n-tex--grid" style={{ padding: "16px" }}>
        <div style={{ font: "var(--type-data)", color: "var(--text-accent)" }}>{id}</div>
        <h2 style={{ font: "var(--type-h2)", letterSpacing: "var(--tracking-tight)", color: "var(--text-primary)", margin: "6px 0 4px" }}>{r.owner}</h2>
        <div style={{ font: "var(--type-body-sm)", color: "var(--text-muted)" }}>{r.county}</div>
        <div style={{ display: "flex", gap: 8, margin: "14px 0 0", flexWrap: "wrap" }}>
          <EvidenceChip state="verified" source="SDAT" id={id} onClick={onOpenProvenance} />
          <EvidenceChip state="conflict" source="2 disagree" onClick={onOpenProvenance} />
        </div>
      </div>
      <hr className="n-rule" />
      <div style={{ padding: "16px" }}>
        <ConfidenceMeter value={r.conf} basis={r.conf >= 80 ? "3 of 4 sources agree · 6h old" : "2 of 3 sources agree · MLS unreachable"} />
      </div>
      <hr className="n-rule" />
      <div style={{ padding: "0 16px" }}>
        <Tabs value={tab} onChange={setTab} items={[
          { id: "evidence", label: "Evidence", count: r.rows.length },
          { id: "attrs", label: "Attributes" },
        ]} />
      </div>
      {tab === "evidence" ? (
        <div style={{ padding: "12px 16px 20px" }}>
          <ProvenanceTrail rows={r.rows} />
          <Button size="sm" variant="secondary" iconAfter="chevron-right" onClick={onOpenProvenance} style={{ marginTop: 14 }}>Full lineage</Button>
        </div>
      ) : (
        <div style={{ padding: "12px 16px 20px" }}>
          <KeyValue items={[
            { key: "Assessed value", value: r.assessed },
            { key: "Acreage", value: r.acres },
            { key: "Coordinates", value: r.coords },
            { key: "Year built", value: r.built },
            { key: "Instrument", value: r.deed },
          ]} />
        </div>
      )}
    </aside>
  );
}

Object.assign(window, { InspectorPanel, RECORDS });
})();
