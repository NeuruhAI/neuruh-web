(() => {
const { Card, Tabs, Badge, IconButton, Input, Button, StatusDot, Stat } = window.NeuruhDesignSystem_5cb7e4;

const SEVERITY = { info: "neutral", warn: "caution", error: "critical", ok: "verified" };

const SEED = [
  { t: "03:14:22.418", sev: "warn", src: "resolver", msg: "owner mismatch parcel=04-118-227 sdat=\"MARTIN, R & K\" clerk=\"MARTIN, ROBERT A\"" },
  { t: "03:14:22.401", sev: "ok", src: "sdat", msg: "batch 0x4E2 ingested rows=1284 dur=912ms" },
  { t: "03:14:19.077", sev: "info", src: "geocode", msg: "resolved 38.3607,-75.5994 conf=0.94" },
  { t: "03:14:11.902", sev: "error", src: "mls-bridge", msg: "handshake timeout after 30000ms attempt=3" },
  { t: "03:13:58.640", sev: "warn", src: "ncoa", msg: "latency 14.2s exceeds budget 5.0s" },
  { t: "03:13:41.115", sev: "ok", src: "clerk", msg: "DEED 2019-4412 fetched pages=7 sha256=9f2c…a041" },
  { t: "03:12:07.883", sev: "error", src: "resolver", msg: "confidence floor breached parcel=11-006-882 conf=0.44 floor=0.50" },
  { t: "03:11:52.209", sev: "info", src: "policy", msg: "redaction applied field=owner_ssn actor=system" },
];

function DiagnosticStream({ live }) {
  const [filter, setFilter] = React.useState("all");
  const [rows, setRows] = React.useState(SEED);
  React.useEffect(() => {
    if (!live) return;
    const id = setInterval(() => {
      setRows((r) => [{
        t: new Date().toISOString().slice(11, 23) + "Z",
        sev: ["info", "ok", "warn"][Math.floor(Math.random() * 3)],
        src: ["sdat", "geocode", "resolver", "clerk"][Math.floor(Math.random() * 4)],
        msg: "heartbeat ok queue=" + Math.floor(Math.random() * 40) + " lag=" + (Math.random() * 2).toFixed(2) + "s",
      }, ...r].slice(0, 60));
    }, 2200);
    return () => clearInterval(id);
  }, [live]);
  const shown = filter === "all" ? rows : rows.filter((r) => r.sev === filter);
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 18, maxWidth: 1080 }}>
      <div>
        <span className="n-label">Append-only event log</span>
        <h1 style={{ font: "var(--type-h1)", letterSpacing: "var(--tracking-tight)", color: "var(--text-primary)", margin: "6px 0 0" }}>Diagnostic stream</h1>
      </div>
      <div style={{ display: "flex", gap: 32 }}>
        <Stat size="sm" label="Events 1h" value="418" />
        <Stat size="sm" label="Errors" value="6" />
        <Stat size="sm" label="Warnings" value="31" />
        <Stat size="sm" label="Retention" value="90d" />
      </div>
      <Card flushBody label="live tail" title="blackbox://stream/0x4E2"
        actions={<>
          <Input icon="search" placeholder="grep" style={{ width: 180 }} />
          <IconButton icon="copy" size="sm" label="Copy" bordered />
          <IconButton icon={live ? "pause" : "play"} size="sm" label="Pause stream" bordered />
        </>}>
        <div style={{ padding: "10px 16px", borderBottom: "1px solid var(--border-subtle)", display: "flex", alignItems: "center", gap: 14 }}>
          <Tabs variant="enclosed" value={filter} onChange={setFilter} items={[
            { id: "all", label: "All" }, { id: "error", label: "Errors" },
            { id: "warn", label: "Warnings" }, { id: "ok", label: "Success" },
          ]} />
          <span style={{ flex: 1 }} />
          <StatusDot state={live ? "live" : "inert"} label={live ? "Tailing" : "Paused"} pulse={live} />
        </div>
        <div style={{ background: "var(--bg-inset)", maxHeight: 380, overflow: "auto" }}>
          {shown.map((r, i) => (
            <div key={r.t + i} style={{ display: "grid", gridTemplateColumns: "116px 62px 92px 1fr", gap: 12, alignItems: "baseline", padding: "5px 16px", borderBottom: "1px solid var(--border-subtle)" }}>
              <span className="n-numeric" style={{ font: "var(--type-data-sm)", color: "var(--text-faint)" }}>{r.t}</span>
              <Badge tone={SEVERITY[r.sev]}>{r.sev}</Badge>
              <span style={{ font: "var(--type-data-sm)", color: "var(--text-accent)" }}>{r.src}</span>
              <span style={{ font: "var(--type-data-sm)", color: "var(--text-body)", wordBreak: "break-word" }}>{r.msg}</span>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

Object.assign(window, { DiagnosticStream });
})();
