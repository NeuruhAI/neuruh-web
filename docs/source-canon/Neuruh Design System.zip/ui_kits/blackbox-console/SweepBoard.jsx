(() => {
const { Card, Stat, Badge, Button, IconButton, Progress, Tabs, Tag, Input, StatusDot, DataTable, Sparkline, EmptyState } = window.NeuruhDesignSystem_5cb7e4;

const TARGETS = [
  { id: "04-118-227", label: "MARTIN, R & K", county: "Wicomico", conf: 86, state: "conflict", assessed: "$284,100", seen: "03:14:22Z", trend: [4, 6, 5, 8, 7, 9, 12] },
  { id: "04-118-231", label: "HOLLOWAY TRUST", county: "Wicomico", conf: 94, state: "verified", assessed: "$196,400", seen: "03:14:19Z", trend: [9, 8, 8, 7, 7, 6, 6] },
  { id: "07-402-009", label: "PARSONS, D", county: "Worcester", conf: 71, state: "unverified", assessed: "$412,900", seen: "03:13:58Z", trend: [6, 6, 7, 7, 8, 8, 9] },
  { id: "07-402-114", label: "CHESAPEAKE HOLDINGS LLC", county: "Worcester", conf: 91, state: "verified", assessed: "$1,140,000", seen: "03:13:41Z", trend: [3, 4, 6, 6, 9, 11, 14] },
  { id: "11-006-882", label: "REDDEN, A & J", county: "Somerset", conf: 44, state: "conflict", assessed: "$88,700", seen: "03:12:07Z", trend: [7, 6, 6, 5, 4, 4, 3] },
  { id: "11-006-903", label: "ESTATE OF W. TULL", county: "Somerset", conf: 63, state: "unverified", assessed: "$134,250", seen: "03:11:52Z", trend: [5, 5, 4, 5, 4, 4, 4] },
];

const FEEDS = [
  { name: "SDAT assessor", state: "verified", latency: "0.9s" },
  { name: "Clerk of Court", state: "verified", latency: "1.8s" },
  { name: "USPS NCOA", state: "caution", latency: "14.2s" },
  { name: "MLS bridge", state: "critical", latency: "—" },
];

function SweepBoard({ selected, onSelect, sweeping, onArm }) {
  const [range, setRange] = React.useState("24H");
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 18, maxWidth: 1080 }}>
      <div style={{ display: "flex", alignItems: "flex-end", gap: 16 }}>
        <div style={{ flex: 1 }}>
          <span className="n-label">Active sweep</span>
          <h1 style={{ font: "var(--type-h1)", letterSpacing: "var(--tracking-tight)", color: "var(--text-primary)", margin: "6px 0 0" }}>
            Lower Eastern Shore · 3 counties
          </h1>
        </div>
        <Tabs variant="enclosed" value={range} onChange={setRange} items={["24H", "7D", "30D", "FY"]} />
        <Button variant="command" icon="zap" onClick={onArm} disabled={sweeping}>
          {sweeping ? "Sweeping" : "Run sweep"}
        </Button>
      </div>

      {sweeping ? <Progress indeterminate /> : <hr className="n-rule" />}

      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 1, background: "var(--border-default)", border: "1px solid var(--border-default)", borderRadius: "var(--radius-3)", overflow: "hidden" }}>
        {[
          { label: "Parcels swept", value: "4,218", delta: "+312", dir: "up", foot: "last 24h" },
          { label: "Conflicts open", value: "27", delta: "−9", dir: "down", foot: "vs 7d" },
          { label: "Median confidence", value: "84%", foot: "9 sources" },
          { label: "Feed latency p95", value: "1.8s", delta: "+0.4s", dir: "up", foot: "degraded" },
        ].map((s) => (
          <div key={s.label} className="n-tex n-tex--grain" style={{ background: "var(--bg-surface)", backgroundImage: "var(--sheen-panel)", padding: "14px 16px" }}>
            <Stat label={s.label} value={s.value} delta={s.delta} deltaDirection={s.dir} foot={s.foot} />
          </div>
        ))}
      </div>

      <Card label="Targets" title="Ranked by conflict severity" flushBody
        actions={<>
          <Input icon="search" placeholder="Filter targets" style={{ width: 200 }} />
          <IconButton icon="funnel" size="sm" label="Filters" bordered />
          <IconButton icon="download" size="sm" label="Export" bordered />
        </>}>
        <div style={{ padding: "10px 16px", display: "flex", gap: 8, borderBottom: "1px solid var(--border-subtle)" }}>
          <Tag icon="map-pin" onRemove={() => {}}>3 counties</Tag>
          <Tag selected onRemove={() => {}}>Conflict ≥ 1</Tag>
          <Tag onRemove={() => {}}>Assessed &gt; $50k</Tag>
        </div>
        <DataTable
          density="tight"
          maxHeight={272}
          selectedKey={selected}
          onSelect={onSelect}
          flaggedKeys={TARGETS.filter((t) => t.state === "conflict").map((t) => t.id)}
          columns={[
            { key: "id", label: "Parcel", mono: true, sortable: true },
            { key: "label", label: "Owner of record", primary: true },
            { key: "county", label: "County" },
            { key: "assessed", label: "Assessed", align: "right", numeric: true, sortable: true },
            { key: "trend", label: "Sweep 7d", width: 96, render: (t) => (
              <Sparkline values={t.trend} width={80} height={16} area={false}
                tone={t.conf >= 80 ? "verified" : t.conf >= 50 ? "caution" : "critical"} />
            ) },
            { key: "conf", label: "Conf", align: "right", numeric: true, render: (t) => (
              <span style={{ color: t.conf >= 80 ? "var(--status-verified)" : t.conf >= 50 ? "var(--status-caution)" : "var(--status-critical)" }}>{t.conf}%</span>
            ) },
            { key: "seen", label: "Last seen", numeric: true },
            { key: "state", label: "", align: "right", render: (t) => (
              <Badge tone={t.state === "verified" ? "verified" : t.state === "conflict" ? "critical" : "caution"}>
                {t.state === "verified" ? "OK" : t.state === "conflict" ? "Conflict" : "Single src"}
              </Badge>
            ) },
          ]}
          rows={TARGETS}
          footer={<><span style={{ flex: 1 }}>Showing 6 of 4,218 · abbreviated for the kit</span><Button size="sm" variant="secondary">Next</Button></>}
        />
      </Card>

      <div style={{ display: "flex", gap: 18 }}>
        <Card style={{ flex: 1 }} label="Feed health" title="9 registered sources" flushBody>
          <div style={{ padding: "4px 16px 12px" }}>
            {FEEDS.map((f) => (
              <div key={f.name} style={{ display: "flex", alignItems: "center", gap: 12, height: "var(--row-height-tight)", borderBottom: "1px solid var(--border-subtle)" }}>
                <StatusDot state={f.state} />
                <span style={{ flex: 1, font: "var(--type-ui)", color: "var(--text-body)" }}>{f.name}</span>
                <span className="n-numeric" style={{ font: "var(--type-data-sm)", color: "var(--text-faint)" }}>{f.latency}</span>
              </div>
            ))}
          </div>
        </Card>
        <Card style={{ width: 300 }} variant="accent" label="Action required" title="MLS bridge unreachable">
          <p style={{ font: "var(--type-body-sm)", color: "var(--text-muted)", margin: "0 0 14px" }}>
            Last successful handshake 41 minutes ago. 118 targets are running on assessor data alone.
          </p>
          <div style={{ display: "flex", gap: 8 }}>
            <Button size="sm" variant="primary" icon="refresh-cw">Retry now</Button>
            <Button size="sm" variant="ghost">Mute 1h</Button>
          </div>
        </Card>
      </div>
    </div>
  );
}

Object.assign(window, { SweepBoard, TARGETS, FEEDS });
})();
