# Neuruh Blackbox — Diagnostic Console

The operational/diagnostic sub-system. The source package classifies Blackbox as
**one deliberate sub-system, not the universal Neuruh language** — the terminal
aesthetic lives here and nowhere else.

## Screens

| File | Surface |
| --- | --- |
| `ConsoleShell.jsx` | Chrome: 48px top bar, 248px collapsible nav rail, 340px inspector rail |
| `SweepBoard.jsx` | Default view — stat header, live target table, feed health |
| `DiagnosticStream.jsx` | Append-only mono event log with severity filtering |
| `InspectorPanel.jsx` | Provenance inspector for the selected target |

## Interactions wired in `index.html`

- Nav rail switches between Sweep board and Diagnostic stream; rail collapses to 56px.
- `Run sweep` arms a confirmation `Dialog`, then drives an indeterminate `Progress`
  for ~2.4s and resolves into a success `Toast`.
- Selecting a table row loads it into the inspector; the inspector's `EvidenceChip`s
  expand the full `ProvenanceTrail`.
- `Live` `StatusDot` pulses and the event stream appends while streaming is on;
  the `Switch` in the top bar halts it.

## Fidelity note

No Blackbox screenshots or source were supplied. This is a reconstruction from the
written brief (terminal/command-center, content density over decoration, SpaceX
mission control not SaaS dashboard) plus the token system — **not** a pixel
recreation of a shipped console. Treat spacing and copy as proposals until real
captures land.
