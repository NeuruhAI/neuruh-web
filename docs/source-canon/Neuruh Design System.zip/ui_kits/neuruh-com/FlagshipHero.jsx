(() => {
const { Button, Badge, StatusDot, SceneFrame, SoundToggle } = window.NeuruhDesignSystem_5cb7e4;

/* The hero is a spatial surface, so it is composed through SceneFrame rather
   than by dropping a canvas into the page. Until a real scene lands, the
   image-slot stands in as the poster and the tier badge shows which route
   the current device would take. */
function FlagshipHero() {
  const [sound, setSound] = React.useState(false);
  const [tier, setTier] = React.useState("static");
  React.useEffect(() => { setTier(SceneFrame.detectTier()); }, []);
  return (
    <section style={{ position: "relative", minHeight: "min(92vh, 860px)", display: "flex", alignItems: "flex-end", overflow: "hidden", background: "var(--scene-void)" }}>
      <div style={{ position: "absolute", top: 0, right: 0, bottom: 0, left: "40%" }}>
        <SceneFrame fill requires="webgpu" scrim={false}
          caption="Spatial index scene — R3F mounts here on the WebGL route.">
          <image-slot id="flagship-hero" shape="rect" fit="cover"
            placeholder="Spatial hero scene — Spline/Blender still or R3F capture"></image-slot>
        </SceneFrame>
        <div style={{ position: "absolute", inset: 0, pointerEvents: "none", background: "radial-gradient(120% 90% at 70% 100%, var(--scene-haze), transparent 68%)" }} />
      </div>
      <div style={{ position: "absolute", inset: 0, background: "linear-gradient(100deg, var(--scene-void) 0%, var(--scene-void) 32%, rgba(8,10,10,0.86) 47%, rgba(8,10,10,0.26) 72%, rgba(8,10,10,0.08) 100%)", pointerEvents: "none" }} />
      <div style={{ position: "absolute", inset: 0, background: "var(--scrim-protection)", pointerEvents: "none" }} />

      <div style={{ position: "absolute", left: "clamp(20px, 4vw, 56px)", top: 96, display: "flex", gap: 8, zIndex: 2 }}>
        <Badge tone="outline">Spatial index</Badge>
        <Badge tone="neutral">{tier} route</Badge>
      </div>
      <div style={{ position: "absolute", right: "clamp(20px, 4vw, 56px)", bottom: "clamp(48px, 7vh, 88px)", zIndex: 2 }}>
        <SoundToggle on={sound} onChange={setSound} label="Scene audio" bars={6} />
      </div>

      <div style={{ position: "relative", padding: "0 clamp(20px, 4vw, 56px) clamp(48px, 7vh, 88px)", maxWidth: 880, pointerEvents: "none" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 22 }}>
          <StatusDot state="live" label="9 systems deployed" pulse />
          <Badge tone="outline">Sovereign conglomerate</Badge>
        </div>
        <h1 style={{ font: "var(--type-cinema-1)", letterSpacing: "var(--tracking-cinema)", color: "var(--paper-000)", margin: 0, maxWidth: "15ch", textWrap: "balance" }}>
          Share the foundation. Never share the face.
        </h1>
        <p style={{ font: "var(--type-body-lg)", color: "var(--ink-100)", margin: "26px 0 0", maxWidth: "var(--measure-editorial)" }}>
          Nine products on one execution platform. Shared auth, telemetry, and evidence
          model. Zero shared identity. Every system defends its own metaphor.
        </p>
        <div style={{ display: "flex", gap: 12, marginTop: 34, pointerEvents: "auto", flexWrap: "wrap" }}>
          <Button size="lg" variant="primary" iconAfter="arrow-right">Request access</Button>
          <Button size="lg" variant="secondary" icon="play">See the platform</Button>
        </div>
      </div>
    </section>
  );
}

Object.assign(window, { FlagshipHero });
})();
