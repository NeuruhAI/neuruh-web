(() => {
const { Button, Badge, Icon, Wordmark, Seal } = window.NeuruhDesignSystem_5cb7e4;

const RULES = [
  { k: "01", t: "Central metaphor", d: "What the product is, before it is a screen." },
  { k: "02", t: "Signature interaction", d: "The one motion nobody else has." },
  { k: "03", t: "Evidence model", d: "How a claim proves itself." },
  { k: "04", t: "Performance budget", d: "The number the build is held to." },
];

function EditorialSection() {
  return (
    <>
      <section id="platform" className="reveal" style={{ borderTop: "1px solid var(--border-default)", display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(420px, 1fr))" }}>
        <div style={{ padding: "clamp(56px, 9vh, 104px) clamp(20px, 4vw, 56px)", display: "flex", flexDirection: "column", justifyContent: "center", gap: 24 }}>
          <span className="n-label">The core rule</span>
          <h2 style={{ font: "var(--type-cinema-3)", letterSpacing: "var(--tracking-cinema)", color: "var(--text-primary)", margin: 0, maxWidth: "24ch" }}>
            A shared foundation is infrastructure. A shared face is a liability.
          </h2>
          <p style={{ font: "var(--type-body-lg)", color: "var(--text-muted)", margin: 0, maxWidth: "var(--measure-editorial)" }}>
            Most platforms ship one design and rename it nine times. We ship one spine and
            make every product defend its own identity in writing before a pixel is drawn.
          </p>
          <div style={{ display: "grid", gap: 1, background: "var(--border-default)", marginTop: 12 }}>
            {RULES.map((r) => (
              <div key={r.k} style={{ background: "var(--bg-canvas)", display: "flex", gap: 18, padding: "16px 0" }}>
                <span className="n-numeric" style={{ font: "var(--type-data)", color: "var(--text-accent)", width: 28 }}>{r.k}</span>
                <div>
                  <div style={{ font: "var(--type-h4)", color: "var(--text-primary)" }}>{r.t}</div>
                  <div style={{ font: "var(--type-body-sm)", color: "var(--text-muted)", marginTop: 3 }}>{r.d}</div>
                </div>
              </div>
            ))}
          </div>
          <div><Button variant="secondary" iconAfter="arrow-right">Read the underwrite process</Button></div>
        </div>
        <div style={{ position: "relative", minHeight: 460, borderLeft: "1px solid var(--border-default)" }}>
          <image-slot id="flagship-editorial" shape="rect" fit="cover"
            placeholder="Editorial still — authored spatial scene or product capture"></image-slot>
        </div>
      </section>

      <section id="defense" className="reveal n-tex n-tex--contour" style={{ padding: "clamp(64px, 10vh, 120px) clamp(20px, 4vw, 56px)", borderTop: "1px solid var(--border-default)", background: "linear-gradient(180deg, var(--pine-900), var(--scene-void))" }}>
        <div style={{ maxWidth: "var(--page-max)", margin: "0 auto", display: "flex", gap: 48, flexWrap: "wrap", alignItems: "flex-end" }}>
          <div style={{ flex: 1, minWidth: 300 }}>
            <span className="n-label">Defense &amp; regulated environments</span>
            <h2 style={{ font: "var(--type-cinema-3)", letterSpacing: "var(--tracking-cinema)", color: "var(--text-primary)", margin: "12px 0 18px", maxWidth: "22ch" }}>
              Built to be audited, not admired.
            </h2>
            <p style={{ font: "var(--type-body)", color: "var(--text-muted)", margin: 0, maxWidth: "44ch" }}>
              Access control, audit logging, and redaction policy are v1 requirements across
              every system. Compliance posture is surfaced, not asserted.
            </p>
          </div>
          <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
            {["SOC 2 track", "ISO 27001 track", "Audit logging", "Data residency", "Reduced motion", "WCAG AA"].map((b) => (
              <Badge key={b} tone="outline">{b}</Badge>
            ))}
          </div>
        </div>
      </section>

      <footer id="company" style={{ padding: "clamp(48px, 7vh, 80px) clamp(20px, 4vw, 56px) 40px", borderTop: "1px solid var(--border-default)" }}>
        <div style={{ maxWidth: "var(--page-max)", margin: "0 auto", display: "flex", gap: 48, flexWrap: "wrap" }}>
          <div style={{ flex: 1, minWidth: 260 }}>
            <Wordmark size="lg" monogram />
            <p style={{ font: "var(--type-body-sm)", color: "var(--text-faint)", margin: "14px 0 0", maxWidth: "34ch" }}>
              Modular AI execution platform. Nine systems, one foundation, no shared face.
            </p>
          </div>
          {[["Products", ["DeedSonar", "Founder Command", "Field Scout", "LARIC"]],
            ["Platform", ["Evidence model", "Telemetry", "Deployment", "Access control"]],
            ["Company", ["Underwrite process", "Design system", "Careers", "Contact"]]].map(([h, items]) => (
            <div key={h} style={{ minWidth: 150 }}>
              <div className="n-label" style={{ marginBottom: 14 }}>{h}</div>
              <div style={{ display: "flex", flexDirection: "column", gap: 9 }}>
                {items.map((i) => <a key={i} href="#" style={{ font: "var(--type-body-sm)", color: "var(--text-muted)", textDecoration: "none" }}>{i}</a>)}
              </div>
            </div>
          ))}
        </div>
        <div style={{ maxWidth: "var(--page-max)", margin: "48px auto 0", paddingTop: 20, borderTop: "1px solid var(--border-subtle)", display: "flex", gap: 20, flexWrap: "wrap", font: "var(--type-data-sm)", color: "var(--text-faint)" }}>
          <span>© 2026 Neuruh</span><span>·</span><span>Mark set in Archivo — no logo file supplied</span>
        </div>
      </footer>
    </>
  );
}

Object.assign(window, { EditorialSection });
})();
