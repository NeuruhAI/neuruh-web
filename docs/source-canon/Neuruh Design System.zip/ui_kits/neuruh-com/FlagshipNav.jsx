(() => {
const { Button, IconButton, Wordmark } = window.NeuruhDesignSystem_5cb7e4;

const LINKS = ["Platform", "Products", "Defense", "Evidence", "Company"];

function FlagshipNav({ solid, sheet, onSheet }) {
  return (
    <>
      <header style={{
        position: "fixed", top: 0, left: 0, right: 0, zIndex: 50,
        display: "flex", alignItems: "center", gap: 28, height: 64, padding: "0 clamp(20px, 4vw, 56px)",
        background: solid ? "rgba(10,10,15,0.82)" : "transparent",
        backdropFilter: solid ? "blur(14px) saturate(140%)" : "none",
        borderBottom: solid ? "1px solid var(--border-default)" : "1px solid transparent",
        transition: "background var(--dur-slow) var(--ease-standard), border-color var(--dur-slow) var(--ease-standard)",
      }}>
        <Wordmark size="md" monogram={solid} tone="inverse" href="#" />
        <nav className="fs-links" style={{ display: "flex", gap: 22, flex: 1 }}>
          {LINKS.map((l) => (
            <a key={l} href={"#" + l.toLowerCase()} style={{ font: "var(--type-ui)", color: "var(--ink-100)", textDecoration: "none" }}>{l}</a>
          ))}
        </nav>
        <div className="fs-cta" style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <Button size="sm" variant="ghost">Sign in</Button>
          <Button size="sm" variant="primary" iconAfter="arrow-right">Request access</Button>
        </div>
        <span className="fs-burger" style={{ display: "none" }}>
          <IconButton icon={sheet ? "x" : "menu"} label="Menu" onClick={onSheet} />
        </span>
      </header>
      {sheet ? (
        <div style={{ position: "fixed", inset: "64px 0 auto", zIndex: 49, background: "var(--ink-900)", borderBottom: "1px solid var(--border-strong)", padding: "12px 20px 20px", display: "flex", flexDirection: "column", gap: 4 }}>
          {LINKS.map((l) => (
            <a key={l} href={"#" + l.toLowerCase()} onClick={onSheet} style={{ font: "var(--type-h3)", color: "var(--paper-050)", textDecoration: "none", padding: "10px 0", borderBottom: "1px solid var(--border-subtle)" }}>{l}</a>
          ))}
          <Button variant="primary" block iconAfter="arrow-right" style={{ marginTop: 12 }}>Request access</Button>
        </div>
      ) : null}
    </>
  );
}

Object.assign(window, { FlagshipNav });
})();
