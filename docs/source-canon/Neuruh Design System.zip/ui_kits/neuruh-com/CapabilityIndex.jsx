(() => {
const { Card, Badge, Button, Icon, Tag } = window.NeuruhDesignSystem_5cb7e4;

const PRODUCTS = [
  { name: "DeedSonar", domain: "Real estate intelligence", icon: "scan-line", thesis: "Title chains, liens, and owner conflicts resolved against nine public sources." },
  { name: "Founder Command", domain: "Operator cockpit", icon: "gauge", thesis: "One surface for every entity, deployment, and open decision." },
  { name: "Cockpit / Galaxy", domain: "Portfolio spatial view", icon: "globe", thesis: "The conglomerate rendered as navigable space, not a list of tabs." },
  { name: "Adaptive Intelligence", domain: "Recursive automation", icon: "cpu", thesis: "Workflows that revise themselves against measured outcomes." },
  { name: "Field Scout", domain: "Mobile capture", icon: "map-pin", thesis: "Ground truth captured on site, signed, and attached to the record." },
  { name: "LARIC", domain: "Legal & compliance", icon: "shield", thesis: "Contract and compliance posture, continuously assessed." },
  { name: "Find Sell Profit", domain: "Resale intelligence", icon: "trending-up", thesis: "Scan, price, and route inventory with live comp data." },
  { name: "Lead Recipe OS", domain: "Pipeline construction", icon: "funnel", thesis: "Repeatable acquisition sequences, versioned like code." },
];

function CapabilityIndex() {
  const [open, setOpen] = React.useState(null);
  return (
    <section id="products" className="reveal" style={{ padding: "clamp(64px, 10vh, 120px) clamp(20px, 4vw, 56px)", borderTop: "1px solid var(--border-default)" }}>
      <div style={{ maxWidth: "var(--page-max)", margin: "0 auto" }}>
        <span className="n-label">The index</span>
        <h2 style={{ font: "var(--type-cinema-2)", letterSpacing: "var(--tracking-cinema)", color: "var(--text-primary)", margin: "12px 0 18px", maxWidth: "20ch" }}>
          Nine systems. One spine.
        </h2>
        <p style={{ font: "var(--type-body-lg)", color: "var(--text-muted)", margin: "0 0 44px", maxWidth: "var(--measure-editorial)" }}>
          Each product independently defines its metaphor, signature interaction, motion
          language, and vocabulary. They share authentication, telemetry, and the evidence
          model — nothing else.
        </p>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))", gap: 14 }}>
          {PRODUCTS.map((p) => (
            <Card key={p.name} interactive variant="default"
              onMouseEnter={() => setOpen(p.name)} onMouseLeave={() => setOpen(null)}
              onFocus={() => setOpen(p.name)} onBlur={() => setOpen(null)} tabIndex={0}>
              <div style={{ display: "flex", alignItems: "flex-start", gap: 14 }}>
                <span style={{ width: 36, height: 36, flex: "none", display: "grid", placeItems: "center", background: "var(--bg-inset)", border: "1px solid var(--border-default)", borderRadius: "var(--radius-2)", color: "var(--text-accent)" }}>
                  <Icon name={p.icon} size={18} />
                </span>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ font: "var(--type-h3)", color: "var(--text-primary)", letterSpacing: "var(--tracking-tight)" }}>{p.name}</div>
                  <div className="n-label" style={{ marginTop: 5 }}>{p.domain}</div>
                </div>
                <Icon name="arrow-up-right" size={15} style={{ color: "var(--text-faint)" }} />
              </div>
              <div style={{
                overflow: "hidden", maxHeight: open === p.name ? 90 : 0, opacity: open === p.name ? 1 : 0,
                transition: "max-height var(--dur-slow) var(--ease-out), opacity var(--dur-base) var(--ease-standard)",
              }}>
                <p style={{ font: "var(--type-body-sm)", color: "var(--text-muted)", margin: "14px 0 0" }}>{p.thesis}</p>
              </div>
            </Card>
          ))}
        </div>
        <div style={{ display: "flex", gap: 8, marginTop: 28, flexWrap: "wrap" }}>
          <span className="n-label" style={{ alignSelf: "center", marginRight: 6 }}>Shared foundation</span>
          {["Authentication", "Permissions", "Data access", "Telemetry", "Testing", "Deployment", "Accessibility primitives"].map((t) => <Tag key={t}>{t}</Tag>)}
        </div>
      </div>
    </section>
  );
}

Object.assign(window, { CapabilityIndex, PRODUCTS });
})();
