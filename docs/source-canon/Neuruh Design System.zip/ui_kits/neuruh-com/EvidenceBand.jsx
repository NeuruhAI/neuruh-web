(() => {
const { Stat, EvidenceChip, Badge } = window.NeuruhDesignSystem_5cb7e4;

const NUMBERS = [
  { label: "Systems in production", value: "9", foot: "defense · real estate · enterprise · creator", src: "Internal registry" },
  { label: "GPT deployments", value: "60+", foot: "shipped to client environments", src: "Deployment log" },
  { label: "IP under management", value: "1TB+", foot: "documented, versioned, licensable", src: "Asset manifest" },
  { label: "Blue-green cutovers", value: "100%", foot: "zero-downtime releases to date", src: "Release record" },
];

function EvidenceBand() {
  return (
    <section id="evidence" className="reveal" style={{ padding: "clamp(64px, 10vh, 120px) clamp(20px, 4vw, 56px)", borderTop: "1px solid var(--border-default)", background: "var(--ink-900)" }}>
      <div style={{ maxWidth: "var(--page-max)", margin: "0 auto" }}>
        <div style={{ display: "flex", alignItems: "flex-end", gap: 24, marginBottom: 48, flexWrap: "wrap" }}>
          <div style={{ flex: 1, minWidth: 280 }}>
            <span className="n-label">Evidence</span>
            <h2 style={{ font: "var(--type-cinema-3)", letterSpacing: "var(--tracking-cinema)", color: "var(--text-primary)", margin: "10px 0 0", maxWidth: "22ch" }}>
              Every number carries its source.
            </h2>
          </div>
          <p style={{ font: "var(--type-body)", color: "var(--text-muted)", margin: 0, maxWidth: "38ch" }}>
            Evidence, authority, and lineage are brand-level properties, not a feature of
            one product. If a claim cannot be traced, it does not ship.
          </p>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: 1, background: "var(--border-default)" }}>
          {NUMBERS.map((n) => (
            <div key={n.label} className="n-tex n-tex--grain" style={{ background: "var(--ink-900)", padding: "28px 24px 24px", display: "flex", flexDirection: "column", gap: 16 }}>
              <Stat size="hero" label={n.label} value={n.value} foot={n.foot} />
              <div><EvidenceChip source={n.src} state="verified" /></div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

Object.assign(window, { EvidenceBand, NUMBERS });
})();
