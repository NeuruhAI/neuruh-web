# Neuruh.com — Flagship World

The cinematic surface. Per the source mandate, Neuruh.com is "not a normal SaaS landing
page and not another terminal dashboard" — it combines spatial storytelling with
immediate business clarity and sets the visual quality bar for every downstream product
**without forcing them to copy it**.

## Screens

| File | Surface |
| --- | --- |
| `FlagshipNav.jsx` | Fixed translucent nav that solidifies past the hero |
| `FlagshipHero.jsx` | Cinematic type over a spatial-scene slot, with a protection scrim |
| `CapabilityIndex.jsx` | The eight-product index — the "sovereign conglomerate" grid |
| `EvidenceBand.jsx` | Trust layer: real traction numbers with sources attached |
| `EditorialSection.jsx` | Long-form section on the Share-the-foundation rule + footer |

## What is cinematic here vs. operational

- Cinematic: `--type-cinema-*`, `--dur-cinematic` reveals, the protection scrim, full-bleed imagery.
- Operational and unchanged: the same `Button`, `Badge`, `Stat`, `EvidenceChip`, and `Tag`
  primitives the consoles use. The flagship earns its difference through scale and
  composition, not a second component set.

## Interactions wired in `index.html`

- Scroll past 80px solidifies the nav (backdrop blur + hairline).
- `IntersectionObserver` reveals each section once, translating 18px up over
  `--dur-cinematic`. Fully disabled under `prefers-reduced-motion`.
- Capability cards expand a one-line thesis on hover/focus.
- The mobile nav sheet toggles below 860px.

## Known gaps

- **Spatial scene.** The hero and section imagery are `<image-slot>` placeholders.
  The source package specifies the 3D pipeline (Spline/Blender → Three.js/R3F) but ships
  no scenes or renders. Drop stills in, or hand the hero to a specialist environment
  as the routing table instructs.
- **Copy.** Headlines are written to the documented Neuruh voice, not lifted from a
  live site — treat them as proposals.
