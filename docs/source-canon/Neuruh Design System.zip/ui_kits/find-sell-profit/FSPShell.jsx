(() => {
const { TopBar, NavItem, Breadcrumbs, Wordmark, Button, IconButton, Input, StatusDot, Badge } = window.NeuruhDesignSystem_5cb7e4;

const NAV = [
  { group: "Scan", items: [["scan", "scan-line", "New scan", null], ["queue", "radar", "Queue", "3"]] },
  { group: "Portfolio", items: [["board", "layers", "Inventory", "148"], ["sold", "trending-up", "Sold", null], ["stalled", "circle-alert", "Stalled", "12"]] },
  { group: "Account", items: [["usage", "gauge", "Usage", null], ["settings", "settings", "Settings", null]] },
];

/**
 * FSP runs on the light spine — it is an all-day working tool, same rule as
 * DeedSonar. The scanner's live agent pipeline is the one dark island.
 */
function FSPShell({ view, onView, crumbs, credits, children }) {
  return (
    <div data-surface="light" style={{ display: "flex", flexDirection: "column", height: "100%", background: "var(--bg-sunken)" }}>
      <TopBar product="Find Sell Profit" monogram
        left={<IconButton icon="panel-left" label="Toggle rail" />}
        right={<>
          <Badge tone="accent" icon="zap">{credits} scans left</Badge>
          <Input icon="search" placeholder="SKU, UPC, title" style={{ width: 220 }} />
          <IconButton icon="bell" label="Alerts" />
        </>}>
        <Breadcrumbs items={crumbs} />
      </TopBar>

      <div style={{ flex: 1, display: "flex", minHeight: 0 }}>
        <nav className="n-nav" style={{ width: "var(--rail-sidebar)", flex: "none", padding: "0 8px 8px", borderRight: "1px solid var(--border-default)", background: "var(--bg-surface)", overflow: "auto" }}>
          <div style={{ padding: "12px 4px 8px" }}>
            <Button variant="command" icon="scan-line" block onClick={() => onView("scan")}>Scan an item</Button>
          </div>
          {NAV.map((g) => (
            <React.Fragment key={g.group}>
              <div className="n-nav__group">{g.group}</div>
              {g.items.map(([id, icon, label, meta]) => (
                <NavItem key={id} icon={icon} label={label} meta={meta}
                  active={view === id} onClick={() => onView(id)} />
              ))}
            </React.Fragment>
          ))}
          <div style={{ marginTop: 16, padding: "10px 12px", border: "1px solid var(--border-default)", borderRadius: "var(--radius-3)", background: "var(--bg-inset)", display: "flex", flexDirection: "column", gap: 6 }}>
            <span className="n-label">Plan</span>
            <span style={{ font: "var(--type-ui)", color: "var(--text-primary)" }}>Operator · monthly</span>
            <a href="#" style={{ font: "var(--type-data-sm)" }}>Manage billing</a>
          </div>
        </nav>

        <main style={{ flex: 1, minWidth: 0, overflow: "auto", background: "var(--bg-canvas)" }}>{children}</main>
      </div>
    </div>
  );
}

Object.assign(window, { FSPShell });
})();
