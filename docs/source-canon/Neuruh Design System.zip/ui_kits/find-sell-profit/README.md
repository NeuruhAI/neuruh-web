# Find Sell Profit — UI kit

Resale intelligence. A seven-agent scanner decides whether an item is worth buying,
and held inventory is tracked until it sells. Built from the FSP/ResellOS technical
context (Next.js · Firebase · Stripe · Groq); the agent roster below is that
pipeline's real order.

**Light spine.** FSP is an all-day working tool — same rule as DeedSonar. The one
exception is the scanner itself: live machine work runs inside a nested
`[data-surface="dark"]` island so it reads as telemetry, not as a document. This is
the kit that exercises bidirectional theme nesting.

## Screens

- **Scanner** (`ScanPipeline.jsx`) — the seven agents in pipeline order, each one
  reporting *what it decided* and *what it decided it from*. The verdict panel stays
  empty until all seven report: FSP never shows a number before the evidence that
  produced it. Run the scan from the console to watch it fill.
- **Inventory** (`OpportunityBoard.jsx`) — held units with cost, ask, net, 90-day
  median sparkline, days held, and confidence. Stalled units (over 21 days) are
  flagged rows, not a separate table.

## The seven agents

Product identification · Market research · Price comparison · Profit calculation ·
Condition assessment · Platform recommendation · Listing optimization.

## Known gaps

- **Queue, Sold, Stalled, Usage, Settings** are `EmptyState`s labelled *not specified
  in source package*. The source defines the scanner and the held-inventory model;
  everything past those two screens would be invention.
- **Figures are illustrative**, drawn to be internally consistent (cost + fees + ship
  = net) rather than pulled from a live account. Swap in real comps before this kit
  is shown to anyone outside the team.
- **Stripe plan state** is a static plate in the rail. Billing, credit metering, and
  the upgrade path are not modelled.
