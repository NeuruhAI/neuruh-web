(() => {
const { Card, DataTable, Badge, Button, Stat, Sparkline, Tabs, Tag, EmptyState } = window.NeuruhDesignSystem_5cb7e4;

const ROWS = [
  { sku: "FSP-1042", item: "Sony WH-1000XM4", cost: 62, ask: 148, net: 61, age: 3, conf: 0.86, state: "Listed", trend: [131,138,134,142,151,147,144,155,149,146,152,148] },
  { sku: "FSP-1039", item: "Dyson V8 Animal", cost: 95, ask: 219, net: 88, age: 11, conf: 0.79, state: "Listed", trend: [204,211,208,215,222,219,214,221,218,216,220,219] },
  { sku: "FSP-1031", item: "Nintendo Switch OLED", cost: 178, ask: 244, net: 39, age: 26, conf: 0.62, state: "Stalled", trend: [268,261,257,252,249,251,246,244,241,243,240,244] },
  { sku: "FSP-1028", item: "Patagonia Nano Puff · M", cost: 24, ask: 92, net: 51, age: 5, conf: 0.91, state: "Listed", trend: [84,86,88,87,90,92,91,93,92,94,92,92] },
  { sku: "FSP-1019", item: "KitchenAid Artisan 5qt", cost: 110, ask: 232, net: 79, age: 41, conf: 0.55, state: "Stalled", trend: [259,254,248,244,239,241,236,234,236,233,231,232] },
  { sku: "FSP-1007", item: "Canon EF 50mm f/1.8", cost: 41, ask: 96, net: 38, age: 2, conf: 0.88, state: "Listed", trend: [92,94,93,95,97,96,95,98,96,97,95,96] },
];

const money = (n) => "$" + n.toFixed(0);

function OpportunityBoard({ selected, onSelect }) {
  const [tab, setTab] = React.useState("all");
  const rows = tab === "stalled" ? ROWS.filter((r) => r.state === "Stalled") : ROWS;

  const columns = [
    { key: "sku", label: "SKU", mono: true, width: 96 },
    { key: "item", label: "Item", primary: true, sortable: true },
    { key: "cost", label: "Cost", numeric: true, render: (r) => money(r.cost) },
    { key: "ask", label: "Ask", numeric: true, render: (r) => money(r.ask) },
    { key: "net", label: "Net", numeric: true, sortable: true, render: (r) => (
      <span style={{ color: r.net >= 50 ? "var(--status-verified)" : "var(--text-body)", fontWeight: 600 }}>{money(r.net)}</span>
    ) },
    { key: "trend", label: "90-day median", width: 120, render: (r) => (
      <Sparkline values={r.trend} width={104} height={22} tone={r.trend[11] >= r.trend[0] ? "verified" : "caution"} />
    ) },
    { key: "age", label: "Days", numeric: true, render: (r) => (
      <span style={{ color: r.age > 21 ? "var(--status-caution)" : "var(--text-body)" }}>{r.age}</span>
    ) },
    { key: "conf", label: "Conf.", numeric: true, render: (r) => Math.round(r.conf * 100) + "%" },
    { key: "state", label: "State", render: (r) => (
      <Badge tone={r.state === "Stalled" ? "caution" : "neutral"}>{r.state}</Badge>
    ) },
  ];

  return (
    <div style={{ padding: 24, display: "flex", flexDirection: "column", gap: 20 }}>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 16 }}>
        <Card variant="inset"><Stat label="Capital deployed" value="$8,412" foot="148 units held" /></Card>
        <Card variant="inset"><Stat label="Projected net" value="$4,190" delta="+12%" deltaDirection="up" foot="at current asks" /></Card>
        <Card variant="inset"><Stat label="Median days held" value="14" foot="target ≤ 21" /></Card>
        <Card variant="inset"><Stat label="Stalled capital" value="$1,908" delta="12 units" deltaDirection="flat" foot="over 21 days" /></Card>
      </div>

      <Card label="Inventory" title="Held units" flushBody
        actions={<>
          <Tabs value={tab} onChange={setTab} items={[{ id: "all", label: "All", count: ROWS.length }, { id: "stalled", label: "Stalled", count: 2 }]} />
          <Button variant="secondary" icon="download" size="sm">Export</Button>
        </>}
        footer={<span style={{ font: "var(--type-data-sm)", color: "var(--text-faint)" }}>Comps refreshed 14 minutes ago · eBay, Mercari, Poshmark</span>}>
        {rows.length ? (
          <DataTable columns={columns} rows={rows} rowKey="sku" density="default"
            selectedKey={selected} onSelect={onSelect}
            flaggedKeys={ROWS.filter((r) => r.state === "Stalled").map((r) => r.sku)} />
        ) : <EmptyState icon="layers" title="Nothing stalled">Every held unit is inside the 21-day target.</EmptyState>}
      </Card>
    </div>
  );
}

Object.assign(window, { OpportunityBoard });
})();
