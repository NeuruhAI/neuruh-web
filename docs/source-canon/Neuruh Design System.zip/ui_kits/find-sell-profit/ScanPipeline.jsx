(() => {
const { Card, Badge, Button, Icon, Progress, StatusDot, Stat, ConfidenceMeter, EvidenceChip, KeyValue, EmptyState, Sparkline } = window.NeuruhDesignSystem_5cb7e4;

/* The seven agents, in pipeline order. Each one states what it decided and
   what it decided it from — an agent that reports only a verdict is a
   black box, and FSP sells the opposite. */
const AGENTS = [
  { id: "identify", icon: "scan-line", name: "Product identification", says: "Sony WH-1000XM4 · black · 2020", basis: "UPC 027242920200 · image match 0.94" },
  { id: "market", icon: "globe", name: "Market research", says: "412 comps in 90 days", basis: "eBay sold · Mercari · Poshmark" },
  { id: "price", icon: "trending-up", name: "Price comparison", says: "Median sold $148", basis: "IQR $131–$164 · n=412" },
  { id: "profit", icon: "gauge", name: "Profit calculation", says: "$61 net at $148", basis: "cost $62 · fees $19 · ship $6" },
  { id: "condition", icon: "eye", name: "Condition assessment", says: "Used — good", basis: "3 photos · earpad wear flagged" },
  { id: "platform", icon: "signal", name: "Platform recommendation", says: "eBay auction, 7-day", basis: "sell-through 71% vs 44%" },
  { id: "listing", icon: "file-text", name: "Listing optimization", says: "Title + 9 item specifics", basis: "top-quartile comp structure" },
];

function AgentRow({ agent, state }) {
  const tone = state === "done" ? "verified" : state === "running" ? "live" : "inert";
  return (
    <div style={{ display: "flex", gap: 12, alignItems: "flex-start", padding: "11px 14px", borderBottom: "1px solid var(--border-subtle)", opacity: state === "idle" ? 0.45 : 1, transition: "opacity var(--dur-fast) var(--ease-standard)" }}>
      <StatusDot state={tone} pulse={state === "running"} />
      <Icon name={agent.icon} size={16} style={{ color: state === "done" ? "var(--text-accent)" : "var(--text-faint)", marginTop: 1 }} />
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ font: "var(--type-ui)", color: "var(--text-primary)" }}>{agent.name}</div>
        {state === "done" ? (
          <div style={{ display: "flex", flexWrap: "wrap", gap: "2px 10px", marginTop: 3 }}>
            <span style={{ font: "var(--type-data)", color: "var(--text-body)" }}>{agent.says}</span>
            <span style={{ font: "var(--type-data-sm)", color: "var(--text-faint)" }}>{agent.basis}</span>
          </div>
        ) : (
          <div style={{ font: "var(--type-data-sm)", color: "var(--text-faint)", marginTop: 3 }}>
            {state === "running" ? "working…" : "queued"}
          </div>
        )}
      </div>
    </div>
  );
}

function ScanPipeline({ running, step, onRun, onReset }) {
  const done = step >= AGENTS.length;
  return (
    <div style={{ padding: 24, display: "grid", gridTemplateColumns: "1.35fr 1fr", gap: 20, alignItems: "start" }}>

      {/* The one dark island on a light surface: live machine work reads as
          telemetry, not as a document. */}
      <div data-surface="dark" style={{ borderRadius: "var(--radius-4)", border: "1px solid var(--border-default)", overflow: "hidden", boxShadow: "var(--elevation-card)" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "12px 14px", borderBottom: "1px solid var(--border-default)", background: "var(--bg-surface)" }}>
          <span className="n-label">Scanner · 7 agents</span>
          <div style={{ flex: 1 }}></div>
          {running ? <Badge tone="accent">Agent {Math.min(step + 1, AGENTS.length)} of {AGENTS.length}</Badge>
            : done ? <Badge tone="verified" icon="check">Complete</Badge>
            : <Badge tone="neutral">Idle</Badge>}
        </div>
        {running || done ? <Progress value={Math.round((Math.min(step, AGENTS.length) / AGENTS.length) * 100)} /> : null}
        <div style={{ background: "var(--bg-canvas)" }}>
          {AGENTS.map((a, i) => (
            <AgentRow key={a.id} agent={a} state={i < step ? "done" : i === step && running ? "running" : "idle"} />
          ))}
        </div>
        <div style={{ display: "flex", gap: 10, padding: 14, background: "var(--bg-surface)" }}>
          {done
            ? <><Button variant="secondary" icon="refresh-cw" onClick={onReset}>Scan another</Button><Button variant="primary" icon="plus">Add to inventory</Button></>
            : <Button variant="command" icon="zap" onClick={onRun} disabled={running}>{running ? "Scanning…" : "Run scan"}</Button>}
        </div>
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
        {done ? (
          <>
            <Card label="Verdict" title="Buy at or below $86">
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 14 }}>
                <Stat label="Net profit" value="$61" delta="+98%" deltaDirection="up" foot="return on $62 cost" />
                <Stat label="Days to sell" value="9" foot="median, this platform" />
              </div>
              <ConfidenceMeter value={86} label="Confidence" basis="412 comps · 90-day window · 3 platforms agree" />
              <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginTop: 14 }}>
                <EvidenceChip state="verified" source="eBay sold" id="412 comps" />
                <EvidenceChip state="verified" source="Mercari" id="88 comps" />
                <EvidenceChip state="conflict" source="Poshmark" id="median $171" />
              </div>
            </Card>

            <Card label="Price history" title="Median sold, 12 weeks">
              <Sparkline values={[131, 138, 134, 142, 151, 147, 144, 155, 149, 146, 152, 148]} width={300} height={56} area dot baseline />
              <div style={{ display: "flex", justifyContent: "space-between", marginTop: 8, font: "var(--type-data-sm)", color: "var(--text-faint)" }}>
                <span>12 wk ago</span><span>$131 → $148</span><span>now</span>
              </div>
            </Card>

            <Card label="Listing draft" title="Ready to publish">
              <KeyValue layout="rows" items={[
                { key: "Title", value: "Sony WH-1000XM4 Wireless Noise Cancelling Headphones — Black" },
                { key: "Format", value: "Auction · 7 day · $0.99 start" },
                { key: "Ship", value: "Calculated · 2 lb · from 21804" },
                { key: "Specifics", value: "9 of 9 filled" },
              ]} />
            </Card>
          </>
        ) : (
          <Card label="Verdict" title="Nothing scanned yet">
            <EmptyState icon="crosshair" title="Run a scan">
              The verdict panel fills in only after all seven agents report. FSP never shows a number before the evidence that produced it.
            </EmptyState>
          </Card>
        )}
      </div>
    </div>
  );
}

Object.assign(window, { ScanPipeline, AGENTS });
})();
