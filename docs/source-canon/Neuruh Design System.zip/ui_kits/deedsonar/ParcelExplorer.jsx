(() => {
const { Card, Tag, Select, Button, IconButton, Badge, Stat, Tabs, Input, DataTable, EmptyState } = window.NeuruhDesignSystem_5cb7e4;

const RESULTS = [
  { id: "04-118-227", owner: "Martin, R & K", addr: "3114 Nanticoke Rd", city: "Salisbury", assessed: "$284,100", acres: "0.41", last: "2019", flag: "conflict" },
  { id: "04-118-231", owner: "Holloway Trust", addr: "3120 Nanticoke Rd", city: "Salisbury", assessed: "$196,400", acres: "0.33", last: "2011", flag: "clean" },
  { id: "07-402-009", owner: "Parsons, D", addr: "812 Bay St", city: "Berlin", assessed: "$412,900", acres: "0.62", last: "2022", flag: "lien" },
  { id: "07-402-114", owner: "Chesapeake Holdings LLC", addr: "44 Commerce Way", city: "Berlin", assessed: "$1,140,000", acres: "2.10", last: "2024", flag: "clean" },
  { id: "11-006-882", owner: "Redden, A & J", addr: "9 Tull Rd", city: "Princess Anne", assessed: "$88,700", acres: "1.02", last: "2004", flag: "conflict" },
  { id: "11-006-903", owner: "Estate of W. Tull", addr: "17 Tull Rd", city: "Princess Anne", assessed: "$134,250", acres: "0.88", last: "1998", flag: "probate" },
];

const FLAG = { clean: ["verified", "Clean"], conflict: ["critical", "Owner conflict"], lien: ["caution", "Lien"], probate: ["caution", "Probate"] };

function ParcelExplorer({ onOpen }) {
  const [filters, setFilters] = React.useState(["Lower Eastern Shore", "Assessed $50k–$1.5M", "Last conveyance > 3y"]);
  const [layout, setLayout] = React.useState("split");
  return (
    <div style={{ display: "flex", flexDirection: "column", minHeight: "100%" }}>
      <div style={{ padding: "18px 24px 0" }}>
        <span className="n-label">Parcel explorer</span>
        <div style={{ display: "flex", alignItems: "flex-end", gap: 16, marginTop: 6 }}>
          <h1 style={{ font: "var(--type-h1)", letterSpacing: "var(--tracking-tight)", color: "var(--text-primary)", margin: 0, flex: 1, whiteSpace: "nowrap" }}>
            4,218 parcels match
          </h1>
          <Select options={["Sort: Conflict severity", "Sort: Assessed value", "Sort: Last conveyance"]} />
          <Tabs variant="enclosed" value={layout} onChange={setLayout} items={[{ id: "split", label: "Split" }, { id: "table", label: "Table" }]} />
          <Button variant="primary" icon="file-text">Generate report</Button>
        </div>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", padding: "16px 0" }}>
          {filters.map((f) => (
            <Tag key={f} icon="funnel" onRemove={() => setFilters(filters.filter((x) => x !== f))}>{f}</Tag>
          ))}
          <Button size="sm" variant="ghost" icon="plus">Add filter</Button>
        </div>
      </div>

      <div style={{ display: "flex", gap: 18, padding: "0 24px 24px", flex: 1, minHeight: 0 }}>
        {layout === "split" ? (
          <Card style={{ width: 420, flex: "none", alignSelf: "flex-start", position: "sticky", top: 0 }} flushBody label="Map surface" title="Wicomico · Worcester · Somerset"
            actions={<><IconButton icon="layers" size="sm" label="Layers" /><IconButton icon="crosshair" size="sm" label="Recenter" /></>}>
            <div className="n-tex n-tex--grid" style={{ height: 400, background: "var(--bg-inset)", borderTop: "1px solid var(--border-default)" }}>
              <EmptyState variant="unavailable" icon="map-pin" label="Awaiting tile provider" title="Basemap not connected"
                actions={<Button size="sm" variant="secondary" icon="link-2">Connect source</Button>}>
                No tile provider, map style, or parcel-geometry source was specified in the design package. Styling targets are ready in <code style={{ font: "var(--type-data-sm)" }}>--map-*</code>.
              </EmptyState>
            </div>
            <div style={{ display: "flex", gap: 24, padding: "14px 16px", borderTop: "1px solid var(--border-default)" }}>
              <Stat size="sm" label="In view" value="4,218" />
              <Stat size="sm" label="Flagged" value="27" />
              <Stat size="sm" label="Median" value="$214k" />
            </div>
          </Card>
        ) : null}

        <Card style={{ flex: 1, minWidth: 0 }} flushBody label="Results" title="Ranked by title risk"
          actions={<><Input icon="search" placeholder="Filter results" style={{ width: 180 }} /><IconButton icon="download" size="sm" label="Export CSV" /></>}>
          <DataTable
            density="loose"
            maxHeight={392}
            onSelect={onOpen}
            flaggedKeys={RESULTS.filter((r) => r.flag !== "clean").map((r) => r.id)}
            columns={[
              { key: "id", label: "Parcel", mono: true, sortable: true },
              { key: "owner", label: "Owner of record", primary: true },
              { key: "addr", label: "Situs", render: (r) => (
                <>{r.addr}<span style={{ color: "var(--text-faint)" }}> · {r.city}</span></>
              ) },
              { key: "assessed", label: "Assessed", align: "right", numeric: true, sortable: true },
              { key: "acres", label: "Acres", align: "right", numeric: true },
              { key: "last", label: "Last conveyance", numeric: true, sortable: true },
              { key: "flag", label: "Title status", render: (r) => {
                const [tone, text] = FLAG[r.flag];
                return <Badge tone={tone}>{text}</Badge>;
              } },
            ]}
            rows={RESULTS}
            footer={<>
              <span style={{ flex: 1 }}>Showing 6 of 4,218 · abbreviated for the kit</span>
              <Button size="sm" variant="secondary">Previous</Button>
              <Button size="sm" variant="secondary">Next</Button>
            </>}
          />
        </Card>
      </div>
    </div>
  );
}

Object.assign(window, { ParcelExplorer, RESULTS });
})();
