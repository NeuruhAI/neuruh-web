(() => {
const { Card, Tabs, Badge, Button, EvidenceChip, ConfidenceMeter, Stat, EmptyState, DataTable } = window.NeuruhDesignSystem_5cb7e4;

const CHAIN = [
  { year: "2019", instr: "DEED 2019-4412", from: "Whaley, T", to: "Martin, R & K", price: "$212,000", state: "conflict" },
  { year: "2004", instr: "DEED 2004-0918", from: "Whaley Family Trust", to: "Whaley, T", price: "—", state: "verified" },
  { year: "1996", instr: "DEED 1996-2210", from: "Nanticoke Land Co", to: "Whaley Family Trust", price: "$84,500", state: "verified" },
  { year: "1981", instr: "DEED 1981-0774", from: "Bounds, E", to: "Nanticoke Land Co", price: "$31,000", state: "verified" },
  { year: "1974", instr: "PLAT 1974-014", from: "—", to: "Bounds, E", price: "—", state: "unverified" },
];

const LIENS = [
  { type: "Judgment", holder: "Peninsula Regional", amount: "$14,208", filed: "2021-06-14", state: "critical" },
  { type: "Tax", holder: "Wicomico County", amount: "$1,940", filed: "2025-01-12", state: "caution" },
];

function TitleChain({ id, onBack, onProvenance }) {
  const [tab, setTab] = React.useState("chain");
  return (
    <div style={{ padding: "18px 24px 32px", display: "flex", flexDirection: "column", gap: 18, maxWidth: 1120 }}>
      <div style={{ display: "flex", alignItems: "flex-start", gap: 16 }}>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <Button size="sm" variant="ghost" icon="arrow-right" onClick={onBack} style={{ transform: "scaleX(-1)" }} />
            <span className="n-label">Record · {id}</span>
          </div>
          <h1 style={{ font: "var(--type-h1)", letterSpacing: "var(--tracking-tight)", color: "var(--text-primary)", margin: "6px 0 6px" }}>Martin, R &amp; K</h1>
          <div style={{ font: "var(--type-body)", color: "var(--text-muted)" }}>3114 Nanticoke Rd, Salisbury, MD 21801 · Wicomico County</div>
          <div style={{ display: "flex", gap: 8, marginTop: 12, flexWrap: "wrap" }}>
            <EvidenceChip state="verified" source="SDAT" id={id} onClick={onProvenance} />
            <EvidenceChip state="conflict" source="Owner name disputed" onClick={onProvenance} />
            <Badge tone="critical">1 judgment</Badge>
            <Badge tone="caution">Tax lien</Badge>
          </div>
        </div>
        <Card style={{ width: 236, flex: "none" }}>
          <ConfidenceMeter value={86} basis="3 of 4 sources agree · 6h old" />
        </Card>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 14 }}>
        {[["Assessed value", "$284,100"], ["Acreage", "0.41"], ["Year built", "1974"], ["Conveyances", "5"]].map(([l, v]) => (
          <Card key={l} className="n-tex n-tex--paper"><Stat label={l} value={v} /></Card>
        ))}
      </div>

      <Card flushBody label="Record" title={<Tabs value={tab} onChange={setTab} items={[
        { id: "chain", label: "Title chain", count: CHAIN.length },
        { id: "liens", label: "Liens", count: LIENS.length },
        { id: "tax", label: "Tax history" },
      ]} />}>
        {tab === "chain" ? (
          <div style={{ padding: "6px 0 0" }}>
            {CHAIN.map((c, i) => (
              <div key={c.instr} style={{ display: "grid", gridTemplateColumns: "72px 1fr 200px 120px 140px", alignItems: "center", gap: 16, padding: "14px 20px", borderBottom: i < CHAIN.length - 1 ? "1px solid var(--border-subtle)" : "none", background: c.state === "conflict" ? "var(--status-critical-wash)" : "transparent" }}>
                <span className="n-numeric" style={{ font: "var(--type-h3)", fontFamily: "var(--font-mono)", color: "var(--text-primary)" }}>{c.year}</span>
                <div>
                  <div style={{ font: "var(--type-ui)", color: "var(--text-primary)" }}>{c.from} <span style={{ color: "var(--text-faint)" }}>→</span> {c.to}</div>
                  <div style={{ font: "var(--type-data-sm)", color: "var(--text-faint)", marginTop: 3 }}>{c.instr}</div>
                </div>
                <div><EvidenceChip state={c.state} source="Clerk of Court" id={c.instr.split(" ")[1]} onClick={onProvenance} /></div>
                <span className="n-numeric" style={{ font: "var(--type-data)", color: "var(--text-body)", textAlign: "right" }}>{c.price}</span>
                <div style={{ textAlign: "right" }}>
                  {c.state === "conflict" ? <Badge tone="critical">Name mismatch</Badge> : c.state === "unverified" ? <Badge tone="caution">Plat only</Badge> : <Badge tone="verified">Recorded</Badge>}
                </div>
              </div>
            ))}
          </div>
        ) : tab === "liens" ? (
          <div>
            {LIENS.map((l) => (
              <div key={l.holder} style={{ display: "grid", gridTemplateColumns: "110px 1fr 130px 130px", alignItems: "center", gap: 16, padding: "16px 20px", borderBottom: "1px solid var(--border-subtle)" }}>
                <Badge tone={l.state}>{l.type}</Badge>
                <span style={{ font: "var(--type-ui)", color: "var(--text-primary)" }}>{l.holder}</span>
                <span className="n-numeric" style={{ font: "var(--type-data)", color: "var(--text-primary)", textAlign: "right" }}>{l.amount}</span>
                <span className="n-numeric" style={{ font: "var(--type-data-sm)", color: "var(--text-faint)", textAlign: "right" }}>{l.filed}</span>
              </div>
            ))}
            <div style={{ padding: "16px 20px", font: "var(--type-body-sm)", color: "var(--text-muted)" }}>
              Encumbrance total <span className="n-numeric" style={{ font: "var(--type-data)", color: "var(--text-primary)" }}>$16,148</span> · 5.7% of assessed value
            </div>
          </div>
        ) : (
          <EmptyState variant="unavailable" hatched icon="file-text"
            label="Not specified in source package" title="No tax-history layout">
            Left intentionally blank rather than invented. Supply the layout and this panel renders against the same tokens.
          </EmptyState>
        )}
      </Card>
    </div>
  );
}

Object.assign(window, { TitleChain, CHAIN, LIENS });
})();
