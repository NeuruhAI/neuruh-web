# DeedSonar — Title & Parcel Intelligence

The light-spine operational product. Included specifically to demonstrate the source
package's constraint **"do not make dark mode mandatory everywhere"** — DeedSonar is
an all-day working tool for title researchers and acquisitions teams, so it runs on
`[data-surface="light"]` with the same tokens and the same components.

## Screens

| File | Surface |
| --- | --- |
| `DeedSonarShell.jsx` | Light chrome: top bar, 248px rail, saved-search list |
| `ParcelExplorer.jsx` | Default view — filter bar, map surface, result table |
| `TitleChain.jsx` | Record detail — conveyance chain, liens, confidence, provenance |

## Interactions wired in `index.html`

- Rail switches Explorer ↔ a selected record; clicking any result row opens `TitleChain`.
- Filter `Tag`s are removable and update the visible result count.
- `Tabs` switch the record between Title chain / Liens / Tax history.
- `EvidenceChip` on any conveyance opens the provenance `Dialog`.
- `Generate report` shows the queued `Toast`.

## Known gaps

- **Map tiles.** The map pane is a labelled placeholder. No basemap provider, style, or
  parcel-geometry source was specified in the source package — dropping in a guessed
  tile style would be an invention. Supply the provider and we will render it.
- No DeedSonar screenshots or code were supplied; layout is derived from the written
  product description plus the token/component system.
