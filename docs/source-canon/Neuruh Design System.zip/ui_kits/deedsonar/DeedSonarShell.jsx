(() => {
const { TopBar, IconButton, NavItem, Breadcrumbs, Input, Button, StatusDot } = window.NeuruhDesignSystem_5cb7e4;

function DeedSonarShell({ view, onView, crumbs, saved, children }) {
  return (
    <div data-surface="light" style={{ display: "flex", flexDirection: "column", height: "100%", background: "var(--bg-sunken)" }}>
      <TopBar product="DeedSonar"
        right={<>
          <StatusDot state="verified" label="SDAT current" />
          <span style={{ width: 4 }} />
          <Button size="sm" variant="secondary" icon="download">Report</Button>
          <IconButton icon="bell" size="sm" label="Alerts" />
          <span style={{ width: 26, height: 26, borderRadius: "var(--radius-pill)", background: "var(--ink-800)", color: "var(--paper-050)", display: "grid", placeItems: "center", font: "var(--type-data-sm)" }}>JB</span>
        </>}>
        <Breadcrumbs items={crumbs} />
      </TopBar>
      <div style={{ display: "flex", flex: 1, minHeight: 0 }}>
        <nav className="n-nav" style={{ width: "var(--rail-sidebar)", flex: "none", padding: "0 8px 8px", borderRight: "1px solid var(--border-default)", background: "var(--bg-surface)", overflow: "auto" }}>
          <div style={{ padding: "10px 4px 4px" }}>
            <Input icon="search" placeholder="Parcel, owner, deed" />
          </div>
          <div className="n-nav__group">Research</div>
          <NavItem icon="scan-line" label="Parcel explorer" meta="4.2k" active={view === "explore"} onClick={() => onView("explore")} />
          <NavItem icon="git-branch" label="Title chains" meta="318" active={view === "record"} onClick={() => onView("record")} />
          <NavItem icon="triangle-alert" label="Clouds & liens" meta="27" />
          <NavItem icon="file-text" label="Reports" meta="14" />
          <div className="n-nav__group">Saved searches</div>
          {saved.map((s) => (
            <NavItem key={s.label} icon="funnel" label={s.label} meta={s.count} />
          ))}
          <div className="n-nav__group">Jurisdictions</div>
          {[["Wicomico, MD", "1,842"], ["Worcester, MD", "1,506"], ["Somerset, MD", "870"]].map(([l, c]) => (
            <NavItem key={l} icon="map-pin" label={l} meta={c} />
          ))}
        </nav>
        <main style={{ flex: 1, minWidth: 0, overflow: "auto" }}>{children}</main>
      </div>
    </div>
  );
}

Object.assign(window, { DeedSonarShell });
})();
