(() => {
const { TopBar, IconButton, StatusDot, NavItem, Breadcrumbs, Input, Switch, Badge, Icon, Dialog } = window.NeuruhDesignSystem_5cb7e4;

const ENTITIES = [
  { id: "all", icon: "layers", label: "All entities", meta: "9" },
  { id: "neuruh", icon: "building-2", label: "Neuruh Org", meta: "4" },
  { id: "deedsonar", icon: "scan-line", label: "DeedSonar LLC", meta: "3" },
  { id: "fsp", icon: "trending-up", label: "Find Sell Profit", meta: "2" },
];

function CommandPalette({ open, onClose, onRun }) {
  const [q, setQ] = React.useState("");
  const ACTIONS = [
    { id: "sweep", icon: "zap", label: "Run full sweep", hint: "DeedSonar" },
    { id: "deploy", icon: "git-branch", label: "Promote staging → production", hint: "Galaxy" },
    { id: "report", icon: "file-text", label: "Generate title opinion", hint: "DeedSonar" },
    { id: "invite", icon: "users", label: "Invite operator", hint: "Neuruh Org" },
    { id: "budget", icon: "gauge", label: "Review performance budgets", hint: "All systems" },
    { id: "audit", icon: "lock", label: "Open audit log", hint: "Compliance" },
  ];
  const shown = q ? ACTIONS.filter((a) => (a.label + a.hint).toLowerCase().includes(q.toLowerCase())) : ACTIONS;
  React.useEffect(() => { if (open) setQ(""); }, [open]);
  if (!open) return null;
  return (
    <div className="n-dialog__scrim" style={{ alignItems: "flex-start", paddingTop: "12vh" }} onClick={onClose}>
      <div className="n-dialog" style={{ maxWidth: 560, padding: 0 }} onClick={(e) => e.stopPropagation()} role="dialog" aria-modal="true">
        <div style={{ padding: 12, borderBottom: "1px solid var(--border-default)" }}>
          <Input icon="terminal" size="lg" autoFocus placeholder="Run a command or jump to an entity" value={q}
            onChange={(e) => setQ(e.target.value)} style={{ width: "100%" }} />
        </div>
        <div style={{ maxHeight: 320, overflow: "auto", padding: 6 }}>
          {shown.length ? shown.map((a) => (
            <button key={a.id} type="button" className="n-navitem" onClick={() => { onRun(a); onClose(); }}>
              <Icon name={a.icon} size={16} />
              <span className="n-navitem__label">{a.label}</span>
              <span className="n-navitem__meta">{a.hint}</span>
            </button>
          )) : (
            <div style={{ padding: "28px 16px", textAlign: "center", font: "var(--type-body-sm)", color: "var(--text-faint)" }}>
              No command matches "{q}".
            </div>
          )}
        </div>
        <div style={{ display: "flex", gap: 14, padding: "10px 14px", borderTop: "1px solid var(--border-default)", font: "var(--type-data-sm)", color: "var(--text-faint)" }}>
          <span>↵ run</span><span>↑↓ navigate</span><span>esc close</span>
        </div>
      </div>
    </div>
  );
}

function CommandShell({ entity, onEntity, live, onLive, onPalette, children, drawer }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%", background: "var(--bg-sunken)" }}>
      <TopBar product="Founder Command" monogram
        right={<>
          <Switch label="Live" checked={live} onChange={(e) => onLive(e.target.checked)} />
          <StatusDot state={live ? "live" : "inert"} label={live ? "Tailing" : "Paused"} pulse={live} />
          <span style={{ width: 6 }} />
          <button type="button" onClick={onPalette}
            style={{ display: "inline-flex", alignItems: "center", gap: 8, height: 28, padding: "0 10px", background: "var(--bg-inset)", border: "1px solid var(--border-default)", borderRadius: "var(--radius-2)", cursor: "pointer", font: "var(--type-data-sm)", color: "var(--text-faint)" }}>
            <Icon name="terminal" size={13} />⌘K
          </button>
          <IconButton icon="bell" size="sm" label="Alerts" />
        </>}>
        <Breadcrumbs items={[{ label: "Neuruh Org", href: "#" }, { label: "Command", href: "#" }, "Today"]} />
      </TopBar>
      <div style={{ display: "flex", flex: 1, minHeight: 0 }}>
        <nav className="n-nav" style={{ width: "var(--rail-sidebar)", flex: "none", padding: "0 8px 8px", borderRight: "1px solid var(--border-default)", background: "var(--bg-canvas)", overflow: "auto" }}>
          <div className="n-nav__group">Entities</div>
          {ENTITIES.map((e) => (
            <NavItem key={e.id} icon={e.icon} label={e.label} meta={e.meta} active={entity === e.id} onClick={() => onEntity(e.id)} />
          ))}
          <div className="n-nav__group">Views</div>
          <NavItem icon="crosshair" label="Decisions" meta="5" active />
          <NavItem icon="git-branch" label="Deployments" meta="12" />
          <NavItem icon="gauge" label="Budgets" />
          <NavItem icon="lock" label="Audit log" />
          <div style={{ marginTop: 20, padding: "0 4px" }}>
            <div className="n-label" style={{ marginBottom: 8 }}>Cost of delay</div>
            <div style={{ font: "700 1.125rem/1 var(--font-mono)", color: "var(--status-caution)", fontVariantNumeric: "tabular-nums" }}>$18.4k / wk</div>
            <div style={{ font: "var(--type-body-sm)", color: "var(--text-faint)", marginTop: 6 }}>across 5 open decisions</div>
          </div>
        </nav>
        <main style={{ flex: 1, minWidth: 0, overflow: "auto", padding: "20px 24px" }}>{children}</main>
        {drawer}
      </div>
    </div>
  );
}

Object.assign(window, { CommandShell, CommandPalette, ENTITIES });
})();
