# Founder Command — Operator Cockpit

One surface for every entity, deployment, and open decision. Founder Command is the
system's densest screen: it is the view an operator leaves open all day, so it optimises
for scanning and for closing decisions, not for exploration.

## Screens

| File | Surface |
| --- | --- |
| `CommandShell.jsx` | Chrome: top bar, entity rail, global command palette (⌘K) |
| `CommandBoard.jsx` | Default view — decision queue, entity health, deployment stream, budget posture |
| `DecisionDrawer.jsx` | A single open decision: context, evidence, options, commit |

## Interactions wired in `index.html`

- ⌘K / Ctrl-K opens the command palette; typing filters actions and entities live.
- Any decision row opens `DecisionDrawer`; committing or deferring removes it from the
  queue and fires a `Toast`.
- The entity rail filters the whole board.
- Deployment stream tails live while the `Switch` is on.

## Why the decision queue leads

The brief describes an operator cockpit, and the failure mode of a cockpit is a wall of
metrics nobody acts on. So the first thing on screen is the list of things awaiting a
human, each with its evidence attached and its cost of delay stated. Metrics come second.

## Known gaps

- No Founder Command screenshots, source, or entity schema were supplied. Entities,
  decision types, and metrics are illustrative, from the roster in `SETUP_CLAUDE_DESIGN.md`.
- The command palette is a filtered list, not a real command registry.
