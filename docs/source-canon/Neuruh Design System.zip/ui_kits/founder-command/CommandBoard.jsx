(() => {
const { Card, Stat, Badge, Button, IconButton, DataTable, Sparkline, StatusDot, EvidenceChip, Tabs, EmptyState, Progress, KeyValue } = window.NeuruhDesignSystem_5cb7e4;

const DECISIONS = [
  { id: "D-104", title: "Promote Galaxy to production", entity: "Neuruh Org", cost: "$6,200", age: "3d", tone: "critical", state: "Blocking release", conf: 78 },
  { id: "D-103", title: "Replace MLS bridge provider", entity: "DeedSonar LLC", cost: "$4,800", age: "5d", tone: "critical", state: "Feed down 41m", conf: 64 },
  { id: "D-101", title: "Approve LARIC compliance scope", entity: "Neuruh Org", cost: "$3,900", age: "8d", tone: "caution", state: "Awaiting counsel", conf: 52 },
  { id: "D-099", title: "Field Scout offline package size", entity: "DeedSonar LLC", cost: "$2,100", age: "11d", tone: "caution", state: "Over budget", conf: 81 },
  { id: "D-097", title: "Creator pod hiring plan", entity: "Find Sell Profit", cost: "$1,400", age: "14d", tone: "neutral", state: "Deferred once", conf: 70 },
];

const DEPLOYS = [
  { t: "14:08", sys: "deedsonar", env: "production", state: "ok", note: "blue-green cutover complete · 0 downtime" },
  { t: "13:41", sys: "galaxy", env: "staging", state: "ok", note: "build 0x9F2 · 412 KB gz · under budget" },
  { t: "12:19", sys: "fieldscout", env: "production", state: "warn", note: "bundle 268 KB gz · exceeds 250 KB budget" },
  { t: "11:02", sys: "laric", env: "staging", state: "error", note: "blocked · compliance scope unapproved" },
  { t: "09:47", sys: "adaptive", env: "staging", state: "ok", note: "build 0x9F1 · 588 KB gz" },
];

const SEV = { ok: "verified", warn: "caution", error: "critical" };

function CommandBoard({ onOpen, live, entity }) {
  const [range, setRange] = React.useState("7D");
  const rows = entity === "all" ? DECISIONS : DECISIONS.filter((d) =>
    (entity === "neuruh" && d.entity === "Neuruh Org") ||
    (entity === "deedsonar" && d.entity === "DeedSonar LLC") ||
    (entity === "fsp" && d.entity === "Find Sell Profit"));

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 18, maxWidth: 1120 }}>
      <div style={{ display: "flex", alignItems: "flex-end", gap: 16 }}>
        <div style={{ flex: 1 }}>
          <span className="n-label">Operator cockpit · Thursday 31 July</span>
          <h1 style={{ font: "var(--type-h1)", letterSpacing: "var(--tracking-tight)", color: "var(--text-primary)", margin: "6px 0 0" }}>
            {rows.length} decision{rows.length === 1 ? "" : "s"} awaiting you
          </h1>
        </div>
        <Tabs variant="enclosed" value={range} onChange={setRange} items={["24H", "7D", "30D", "FY"]} />
        <Button variant="command" icon="zap">Open standup</Button>
      </div>

      <Card variant="accent" flushBody label="Decision queue" title="Ranked by cost of delay"
        actions={<IconButton icon="funnel" size="sm" label="Filters" bordered />}>
        {rows.length ? (
          <DataTable density="loose" onSelect={onOpen}
            flaggedKeys={rows.filter((d) => d.tone === "critical").map((d) => d.id)}
            columns={[
              { key: "id", label: "Ref", mono: true, width: 76 },
              { key: "title", label: "Decision", primary: true },
              { key: "entity", label: "Entity" },
              { key: "state", label: "Status", render: (d) => <Badge tone={d.tone}>{d.state}</Badge> },
              { key: "cost", label: "Cost / wk", align: "right", numeric: true, sortable: true },
              { key: "age", label: "Open", align: "right", numeric: true },
            ]}
            rows={rows}
            footer={<><span style={{ flex: 1 }}>Total cost of delay <span className="n-numeric" style={{ font: "var(--type-data)", color: "var(--status-caution)" }}>$18.4k / wk</span></span><Button size="sm" variant="secondary">Export</Button></>} />
        ) : (
          <EmptyState icon="circle-check" title="Nothing awaiting you">No open decisions for this entity. The queue is the point — keep it empty.</EmptyState>
        )}
      </Card>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 1, background: "var(--border-default)", border: "1px solid var(--border-default)", borderRadius: "var(--radius-3)", overflow: "hidden" }}>
        {[
          { label: "Systems live", value: "6", foot: "of 9 commissioned", trend: [4, 4, 5, 5, 6, 6, 6], tone: "verified" },
          { label: "Deploys 7d", value: "12", delta: "+4", dir: "up", foot: "0 rollbacks", trend: [1, 2, 2, 3, 2, 4, 3], tone: "accent" },
          { label: "Budgets breached", value: "1", foot: "Field Scout bundle", trend: [0, 0, 0, 1, 1, 1, 1], tone: "caution" },
          { label: "Evidence coverage", value: "74%", delta: "+6%", dir: "up", foot: "median across systems", trend: [5, 5, 6, 6, 7, 7, 8], tone: "verified" },
        ].map((s) => (
          <div key={s.label} className="n-tex n-tex--grain" style={{ background: "var(--bg-surface)", backgroundImage: "var(--sheen-panel)", padding: "14px 16px", display: "flex", flexDirection: "column", gap: 10 }}>
            <Stat label={s.label} value={s.value} delta={s.delta} deltaDirection={s.dir} foot={s.foot} />
            <Sparkline values={s.trend} tone={s.tone} width={120} height={20} area={false} />
          </div>
        ))}
      </div>

      <div style={{ display: "flex", gap: 18, alignItems: "flex-start" }}>
        <Card style={{ flex: 1 }} flushBody label="Deployment stream" title="All entities"
          actions={<StatusDot state={live ? "live" : "inert"} label={live ? "Tailing" : "Paused"} pulse={live} />}>
          <div style={{ background: "var(--bg-inset)" }}>
            {DEPLOYS.map((d, i) => (
              <div key={d.t + i} style={{ display: "grid", gridTemplateColumns: "58px 92px 88px 1fr", gap: 12, alignItems: "baseline", padding: "9px 16px", borderBottom: i < DEPLOYS.length - 1 ? "1px solid var(--border-subtle)" : 0 }}>
                <span className="n-numeric" style={{ font: "var(--type-data-sm)", color: "var(--text-faint)" }}>{d.t}</span>
                <span style={{ font: "var(--type-data-sm)", color: "var(--text-accent)" }}>{d.sys}</span>
                <Badge tone={SEV[d.state]}>{d.env}</Badge>
                <span style={{ font: "var(--type-data-sm)", color: "var(--text-body)" }}>{d.note}</span>
              </div>
            ))}
          </div>
        </Card>

        <Card style={{ width: 300 }} label="Budget posture" title="Bundle vs ceiling">
          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            {[["Flagship hero", 82, "verified"], ["Galaxy", 92, "caution"], ["Field Scout", 107, "critical"], ["DeedSonar", 64, "verified"]].map(([l, v, t]) => (
              <div key={l} style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                <div style={{ display: "flex", justifyContent: "space-between", gap: 12 }}>
                  <span style={{ font: "var(--type-body-sm)", color: "var(--text-body)" }}>{l}</span>
                  <span className="n-numeric" style={{ font: "var(--type-data-sm)", color: `var(--status-${t})` }}>{v}%</span>
                </div>
                <Progress value={Math.min(100, v)} tone={t} />
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}

Object.assign(window, { CommandBoard, DECISIONS });
})();
