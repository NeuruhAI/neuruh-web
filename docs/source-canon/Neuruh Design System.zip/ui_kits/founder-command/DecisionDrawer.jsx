(() => {
const { IconButton, Badge, Button, Tabs, KeyValue, ConfidenceMeter, EvidenceChip, ProvenanceTrail, Radio, Field, Input, Stat } = window.NeuruhDesignSystem_5cb7e4;

const CONTEXT = {
  "D-104": { body: "Galaxy has been in staging for 34 days. Build 0x9F2 is 412 KB gz against a 450 KB ceiling and has passed every gate except a manual accessibility review. Holding it blocks the Q3 operator rollout.", options: ["Promote now, review post-release", "Hold for accessibility review", "Promote to limited cohort"], rows: [
    { source: "Deployment log", value: "staging 34d · build 0x9F2", stamp: "07-31 13:41Z", state: "verified" },
    { source: "Budget check", value: "412 KB gz / 450 KB", stamp: "07-31 13:41Z", state: "verified" },
    { source: "A11y review", value: "not started", stamp: "—", state: "unverified" },
  ] },
  "D-103": { body: "The MLS bridge has been unreachable for 41 minutes and has failed 3 handshake attempts. 118 DeedSonar targets are running on assessor data alone, which drops their confidence below the 50% floor.", options: ["Switch to backup provider", "Retry with extended timeout", "Suspend affected targets"], rows: [
    { source: "Feed monitor", value: "unreachable 41m · 3 attempts", stamp: "07-31 14:02Z", state: "verified" },
    { source: "Resolver", value: "118 targets below floor", stamp: "07-31 14:02Z", state: "verified" },
    { source: "MLS bridge SLA", value: "99.5% contractual", stamp: "07-01 00:00Z", state: "verified" },
  ] },
};

const FALLBACK = { body: "PLACEHOLDER — no decision context was supplied for this reference. Every decision in this queue should state what is known, what is unknown, and what the delay costs.", options: ["Commit", "Defer one week", "Delegate"], rows: [] };

function DecisionDrawer({ id, onClose, onCommit }) {
  const d = (window.DECISIONS || []).find((x) => x.id === id);
  const c = CONTEXT[id] || FALLBACK;
  const [choice, setChoice] = React.useState(0);
  const [tab, setTab] = React.useState("context");
  React.useEffect(() => { setChoice(0); setTab("context"); }, [id]);
  if (!d) return null;

  return (
    <aside style={{ width: 420, flex: "none", borderLeft: "1px solid var(--border-default)", background: "var(--bg-canvas)", overflow: "auto", display: "flex", flexDirection: "column" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10, height: "var(--bar-height)", padding: "0 12px 0 16px", borderBottom: "1px solid var(--border-default)", flex: "none" }}>
        <span className="n-label" style={{ flex: 1 }}>Decision {d.id}</span>
        <IconButton icon="external-link" size="sm" label="Open full record" />
        <IconButton icon="x" size="sm" label="Close" onClick={onClose} />
      </div>

      <div style={{ padding: 16 }}>
        <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
          <Badge tone={d.tone}>{d.state}</Badge>
          <Badge tone="outline">{d.entity}</Badge>
        </div>
        <h2 style={{ font: "var(--type-h2)", letterSpacing: "var(--tracking-tight)", color: "var(--text-primary)", margin: 0 }}>{d.title}</h2>
        <div style={{ display: "flex", gap: 28, marginTop: 16 }}>
          <Stat size="sm" label="Cost of delay" value={d.cost + " / wk"} />
          <Stat size="sm" label="Open" value={d.age} />
        </div>
      </div>

      <hr className="n-rule" />
      <div style={{ padding: "0 16px" }}>
        <Tabs value={tab} onChange={setTab} items={[
          { id: "context", label: "Context" },
          { id: "evidence", label: "Evidence", count: c.rows.length },
        ]} />
      </div>

      {tab === "context" ? (
        <div style={{ padding: "16px" }}>
          <p style={{ font: "var(--type-body)", color: "var(--text-body)", margin: 0 }}>{c.body}</p>
          <div style={{ marginTop: 20 }}>
            <span className="n-label">Options</span>
            <div style={{ display: "flex", flexDirection: "column", gap: 12, marginTop: 12 }}>
              {c.options.map((o, i) => (
                <Radio key={o} name={"opt-" + id} label={o} checked={choice === i} onChange={() => setChoice(i)} />
              ))}
            </div>
          </div>
          <div style={{ marginTop: 20 }}>
            <Field label="Rationale" hint="Recorded in the audit log with your identity.">
              <Input placeholder="One sentence on why" />
            </Field>
          </div>
        </div>
      ) : (
        <div style={{ padding: "16px" }}>
          <ConfidenceMeter value={d.conf} basis={`${c.rows.filter((r) => r.state === "verified").length} of ${c.rows.length || 1} sources verified`} />
          <div style={{ display: "flex", gap: 8, margin: "16px 0", flexWrap: "wrap" }}>
            {c.rows.map((r) => <EvidenceChip key={r.source} state={r.state} source={r.source} />)}
          </div>
          {c.rows.length ? <ProvenanceTrail rows={c.rows} /> : (
            <p style={{ font: "var(--type-body-sm)", color: "var(--text-faint)", margin: 0 }}>No sources attached. A decision without evidence should not be in this queue.</p>
          )}
        </div>
      )}

      <div style={{ marginTop: "auto", display: "flex", gap: 8, padding: 16, borderTop: "1px solid var(--border-default)", flex: "none" }}>
        <Button variant="secondary" onClick={() => onCommit(d, "deferred")}>Defer</Button>
        <span style={{ flex: 1 }} />
        <Button variant="primary" icon="check" onClick={() => onCommit(d, "committed", c.options[choice])}>Commit</Button>
      </div>
    </aside>
  );
}

Object.assign(window, { DecisionDrawer });
})();
