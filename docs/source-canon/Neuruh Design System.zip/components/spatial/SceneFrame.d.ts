/**
 * The sanctioned container for any spatial / WebGL / graph / map canvas.
 * Never mount a Three.js, R3F, deck.gl, MapLibre, Cesium, or Sigma canvas
 * directly into a screen — wrap it so capability detection, reduced-motion,
 * poster fallback, and scene framing are handled once.
 */
export type SceneTier = "static" | "reduced" | "webgl" | "webgpu";

export interface SceneFrameProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Framing ratio: cinema 21:9, hero 16:9, object 1:1. Ignored when `fill`. */
  aspect?: "cinema" | "hero" | "object";
  /** Absolutely fill the nearest positioned ancestor instead of using an aspect ratio. */
  fill?: boolean;
  /** Poster still shown beneath the canvas and used as the static fallback. */
  poster?: string;
  posterAlt?: string;
  /** Minimum tier the scene needs. Below it, the poster or notice renders instead. */
  requires?: SceneTier;
  /** Outline badge naming the scene, e.g. "Spatial index". */
  label?: string;
  /** One line explaining what the fallback is standing in for. */
  caption?: string;
  /** Bottom-up protection scrim. Leave on whenever text sits over the scene. */
  scrim?: boolean;
  /** Bottom-right controls — sound toggle, pause, quality. */
  controls?: React.ReactNode;
  /** Content composited over the scene, bottom-aligned. */
  overlay?: React.ReactNode;
  /** The canvas itself. Only mounted when the tier requirement is met. */
  children?: React.ReactNode;
}
export function SceneFrame(props: SceneFrameProps): JSX.Element;
export namespace SceneFrame {
  /** Reports the highest route this device and user preference allow. */
  function detectTier(): SceneTier;
  /** Ordered tiers, weakest first. */
  const TIERS: SceneTier[];
}
