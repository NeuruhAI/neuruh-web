/**
 * Audio control for a spatial scene. Audio in this system is muted by default
 * and may only start from an explicit user gesture — there is no autoplay route.
 */
export interface SoundToggleProps extends React.HTMLAttributes<HTMLSpanElement> {
  on?: boolean;
  onChange?: (on: boolean) => void;
  /** Accessible name suffix, e.g. "Scene audio". */
  label?: string;
  /** Meter bar count. 4 is the default; 6 for a prominent hero. */
  bars?: number;
}
export function SoundToggle(props: SoundToggleProps): JSX.Element;
