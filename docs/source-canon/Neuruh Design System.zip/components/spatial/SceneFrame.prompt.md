Wraps every spatial canvas — Three.js / R3F, deck.gl, MapLibre, Cesium, Sigma, Spline. Never mount one of those directly into a screen.

```jsx
<SceneFrame aspect="cinema" requires="webgl" label="Spatial index"
  poster="assets/scenes/index-poster.jpg"
  caption="Portfolio rendered as navigable space."
  controls={<SoundToggle />}
  overlay={<h2 style={{ font: "var(--type-cinema-2)" }}>Nine systems. One spine.</h2>}>
  <Canvas>{/* R3F scene */}</Canvas>
</SceneFrame>
```

`SceneFrame.detectTier()` returns `static` | `reduced` | `webgl` | `webgpu`, and resolves to `static` under `prefers-reduced-motion`, Save-Data, or no WebGL context. Children mount only when the tier meets `requires` — so the reduced-sensory route is the default path, not an afterthought. Always supply a `poster`; the built-in notice is a development affordance, not a shippable fallback. See `guidelines/spatial-stack.md` for library routing and performance budgets.
