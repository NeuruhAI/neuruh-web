import React from "react";
import { Icon } from "./../core/Icon.jsx";

/** Audio is muted by default and must be user-initiated. */
export function SoundToggle({ on = false, onChange, label = "Scene audio", bars = 4, className = "", ...rest }) {
  const [t, setT] = React.useState(0);
  React.useEffect(() => {
    if (!on) return;
    const id = setInterval(() => setT((v) => v + 1), 160);
    return () => clearInterval(id);
  }, [on]);
  return (
    <span className={`n-sound ${className}`.trim()} {...rest}>
      <button type="button" className="n-iconbtn n-iconbtn--sm n-iconbtn--bordered"
        aria-pressed={on} aria-label={on ? "Mute " + label : "Unmute " + label}
        onClick={() => onChange && onChange(!on)}>
        <Icon name={on ? "volume-2" : "volume-x"} size={14} />
      </button>
      <span className="n-sound__meter" aria-hidden="true">
        {Array.from({ length: bars }, (_, i) => (
          <span key={i} className="n-sound__bar"
            style={{ height: on ? 3 + ((Math.sin(t * 0.9 + i) + 1) / 2) * 9 : 2, opacity: on ? 1 : 0.32 }} />
        ))}
      </span>
    </span>
  );
}
