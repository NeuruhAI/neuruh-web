import React from "react";
import { Icon } from "./../core/Icon.jsx";
import { Badge } from "./../core/Badge.jsx";

/**
 * The only sanctioned container for a spatial / WebGL surface.
 * Detects capability, honours reduced motion, and falls back to a poster
 * rather than shipping a blank canvas.
 */
function detectSceneTier() {
  if (typeof window === "undefined") return "static";
  const reduced = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  if (reduced) return "static";
  const saveData = navigator.connection && navigator.connection.saveData;
  if (saveData) return "static";
  const cores = navigator.hardwareConcurrency || 4;
  const mem = navigator.deviceMemory ?? 8;
  if (typeof navigator !== "undefined" && navigator.gpu) {
    return cores >= 8 ? "webgpu" : "webgl";
  }
  try {
    const c = document.createElement("canvas");
    const gl = c.getContext("webgl2") || c.getContext("webgl");
    if (!gl) return "static";
  } catch (e) {
    return "static";
  }
  if (cores <= 4 || mem <= 4) return "reduced";
  return "webgl";
}

const ORDER = { static: 0, reduced: 1, webgl: 2, webgpu: 3 };

export function SceneFrame({
  aspect = "hero",
  fill = false,
  poster,
  posterAlt = "",
  requires = "webgl",
  label,
  caption,
  scrim = true,
  controls,
  overlay,
  children,
  className = "",
  ...rest
}) {
  const [tier, setTier] = React.useState("static");
  React.useEffect(() => { setTier(detectSceneTier()); }, []);
  const live = ORDER[tier] >= ORDER[requires];
  const cls = ["n-scene", fill ? "n-scene--fill" : `n-scene--${aspect}`, className].filter(Boolean).join(" ");
  return (
    <div className={cls} data-scene-tier={tier} {...rest}>
      {poster ? <img className="n-scene__poster" src={poster} alt={posterAlt} /> : null}
      {live ? <div className="n-scene__canvas">{children}</div> : null}
      {!live && !poster ? (
        <div className="n-scene__notice">
          <Icon name="layers" size={20} style={{ color: "var(--text-faint)" }} />
          <span className="n-label">{tier === "static" ? "Static route" : "Reduced route"}</span>
          <p>{caption || "This surface has a spatial scene. It is not rendered on this device or under reduced-motion settings — supply a poster still for the fallback."}</p>
        </div>
      ) : null}
      {scrim ? <span className="n-scene__scrim" /> : null}
      {label ? (
        <div className="n-scene__badge">
          <Badge tone="outline">{label}</Badge>
          {!live ? <Badge tone="neutral">{tier}</Badge> : null}
        </div>
      ) : null}
      {overlay ? <div className="n-scene__overlay">{overlay}</div> : null}
      {controls ? <div className="n-scene__controls">{controls}</div> : null}
    </div>
  );
}

/** Highest route this device and user preference allow: static | reduced | webgl | webgpu. */
SceneFrame.detectTier = detectSceneTier;

/** Ordered tiers, weakest first — for comparing a detected tier against a requirement. */
SceneFrame.TIERS = ["static", "reduced", "webgl", "webgpu"];
