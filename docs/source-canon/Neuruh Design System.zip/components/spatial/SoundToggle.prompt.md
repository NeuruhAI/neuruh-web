The only sanctioned way to start audio. Muted by default, user-initiated, always dismissible.

```jsx
<SoundToggle on={sound} onChange={setSound} label="Scene audio" />
```

Pass it to `SceneFrame`'s `controls` slot. The meter animates only while `on`, so a muted page has no running timer. Never autoplay, never bury the control, never make a silent visit a degraded experience — the silent route is a first-class route.
