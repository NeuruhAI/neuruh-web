/** Single-line text input on a sunken well. */
export interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  /** Leading icon name. */
  icon?: string;
  size?: "md" | "lg";
  /** Mono face — use for IDs, coordinates, hashes, any machine value. */
  mono?: boolean;
  invalid?: boolean;
}
export function Input(props: InputProps): JSX.Element;
