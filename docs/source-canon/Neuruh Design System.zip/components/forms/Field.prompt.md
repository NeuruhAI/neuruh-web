Every form control gets a `Field` — the mono uppercase label is a core brand signature.

```jsx
<Field label="Parcel ID" hint="County assessor format" htmlFor="parcel">
  <Input id="parcel" mono placeholder="04-118-227" />
</Field>
```

`error` replaces `hint` when present; pair it with `invalid` on the control.
