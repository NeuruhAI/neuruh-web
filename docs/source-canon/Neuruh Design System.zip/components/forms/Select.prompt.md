Single-choice picker. Native element underneath — keyboard and mobile behavior come free.

```jsx
<Select options={["All counties", "Wicomico", "Worcester"]} />
<Select options={[{ value: "30", label: "Last 30 days" }]} defaultValue="30" />
```

Above roughly 8 options, use a search `Input` with a filtered list instead.
