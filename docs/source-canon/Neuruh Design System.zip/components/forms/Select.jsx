import React from "react";
import { Icon } from "./../core/Icon.jsx";

/** Native select with Neuruh chrome. */
export function Select({ options = [], size = "md", invalid = false, className = "", ...rest }) {
  const cls = ["n-input", "n-select", size === "lg" ? "n-input--lg" : "", invalid ? "n-input--invalid" : "", className]
    .filter(Boolean)
    .join(" ");
  return (
    <span className="n-selectwrap">
      <select className={cls} aria-invalid={invalid || undefined} {...rest}>
        {options.map((o) => {
          const value = typeof o === "string" ? o : o.value;
          const label = typeof o === "string" ? o : o.label;
          return <option key={value} value={value}>{label}</option>;
        })}
      </select>
      <span className="n-selectwrap__caret"><Icon name="chevron-down" size={14} /></span>
    </span>
  );
}
