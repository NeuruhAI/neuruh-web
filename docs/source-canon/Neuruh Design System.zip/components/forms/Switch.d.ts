/** Toggle for settings that take effect the moment they change. */
export interface SwitchProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: React.ReactNode;
}
export function Switch(props: SwitchProps): JSX.Element;
