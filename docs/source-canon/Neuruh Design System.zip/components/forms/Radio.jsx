import React from "react";

export function Radio({ label, checked, disabled, className = "", ...rest }) {
  const cls = ["n-check", "n-check--radio", checked ? "n-check--checked" : "", disabled ? "n-check--disabled" : "", className]
    .filter(Boolean)
    .join(" ");
  return (
    <label className={cls} style={{ position: "relative" }}>
      <input type="radio" checked={checked} disabled={disabled} {...rest} />
      <span className="n-check__box" />
      {label ? <span>{label}</span> : null}
    </label>
  );
}
