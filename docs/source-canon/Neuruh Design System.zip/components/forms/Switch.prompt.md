A setting that applies immediately — live feeds, alerting, reduced motion.

```jsx
<Switch label="Live telemetry" checked={live} onChange={e => setLive(e.target.checked)} />
```

The thumb slides 16px in 120ms with no overshoot. If the change needs a Save button, use `Checkbox`.
