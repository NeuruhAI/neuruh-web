import React from "react";

/** Label + control + hint/error wrapper. */
export function Field({ label, hint, error, htmlFor, children, className = "", ...rest }) {
  return (
    <div className={`n-field ${className}`.trim()} {...rest}>
      {label ? <label className="n-field__label" htmlFor={htmlFor}>{label}</label> : null}
      {children}
      {error ? <span className="n-field__error">{error}</span> : hint ? <span className="n-field__hint">{hint}</span> : null}
    </div>
  );
}
