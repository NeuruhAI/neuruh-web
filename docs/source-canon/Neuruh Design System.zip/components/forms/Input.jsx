import React from "react";
import { Icon } from "./../core/Icon.jsx";

/** Text input. Pass `icon` for a leading glyph, `mono` for identifiers. */
export function Input({ icon, size = "md", mono = false, invalid = false, className = "", ...rest }) {
  const cls = [
    "n-input",
    size === "lg" ? "n-input--lg" : "",
    mono ? "n-input--mono" : "",
    invalid ? "n-input--invalid" : "",
    className,
  ]
    .filter(Boolean)
    .join(" ");
  const field = <input className={cls} aria-invalid={invalid || undefined} {...rest} />;
  if (!icon) return <span className="n-inputwrap">{field}</span>;
  return (
    <span className="n-inputwrap n-inputwrap--icon">
      <span className="n-inputwrap__icon"><Icon name={icon} size={14} /></span>
      {field}
    </span>
  );
}
