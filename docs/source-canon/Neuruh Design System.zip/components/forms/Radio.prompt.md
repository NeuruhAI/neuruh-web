Exclusive choice among 2–4 visible options; share a `name` across the group.

```jsx
<Radio name="scope" label="Parcel" checked={s==="parcel"} onChange={()=>setS("parcel")} />
<Radio name="scope" label="Block" checked={s==="block"} onChange={()=>setS("block")} />
```

Beyond 4 options use `Select`.
