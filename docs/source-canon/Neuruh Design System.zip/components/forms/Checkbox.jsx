import React from "react";
import { Icon } from "./../core/Icon.jsx";

export function Checkbox({ label, checked, disabled, className = "", ...rest }) {
  const cls = ["n-check", checked ? "n-check--checked" : "", disabled ? "n-check--disabled" : "", className]
    .filter(Boolean)
    .join(" ");
  return (
    <label className={cls} style={{ position: "relative" }}>
      <input type="checkbox" checked={checked} disabled={disabled} {...rest} />
      <span className="n-check__box"><Icon name="check" size={11} strokeWidth={2.5} /></span>
      {label ? <span>{label}</span> : null}
    </label>
  );
}
