Text entry. Inputs sit on the sunken well (`--bg-inset`) so they read as recessed against panels.

```jsx
<Input icon="search" placeholder="Search parcels, owners, deeds" />
<Input mono defaultValue="04-118-227" />
<Input invalid defaultValue="bad@" />
```

Set `mono` for any machine-generated value. Focus is a 2px signal ring with a canvas-colored gap — never a glow.
