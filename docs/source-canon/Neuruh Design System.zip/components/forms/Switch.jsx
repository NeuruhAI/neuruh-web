import React from "react";

/** Immediate-effect toggle. */
export function Switch({ label, checked, disabled, className = "", ...rest }) {
  const cls = ["n-switch", checked ? "n-switch--on" : "", disabled ? "n-switch--disabled" : "", className]
    .filter(Boolean)
    .join(" ");
  return (
    <label className={cls} style={{ position: "relative" }}>
      <input type="checkbox" role="switch" checked={checked} disabled={disabled} {...rest} />
      <span className="n-switch__track"><span className="n-switch__thumb" /></span>
      {label ? <span>{label}</span> : null}
    </label>
  );
}
