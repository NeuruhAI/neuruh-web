/** Square multi-select control. 2px radius, signal fill when checked. */
export interface CheckboxProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: React.ReactNode;
}
export function Checkbox(props: CheckboxProps): JSX.Element;
