/** Native select styled to match Input. */
export interface SelectOption { value: string; label: string }
export interface SelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  /** Plain strings or {value,label} pairs. */
  options?: Array<string | SelectOption>;
  size?: "md" | "lg";
  invalid?: boolean;
}
export function Select(props: SelectProps): JSX.Element;
