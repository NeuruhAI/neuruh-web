Multi-select and standalone booleans that only take effect on submit.

```jsx
<Checkbox label="Include tax-delinquent parcels" checked={on} onChange={e => set(e.target.checked)} />
```

For a setting that applies immediately, use `Switch` instead.
