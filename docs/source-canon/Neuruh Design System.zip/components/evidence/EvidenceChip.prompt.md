Attaches a source to a claim. Any number a Neuruh product asserts should carry one.

```jsx
<EvidenceChip state="verified" source="SDAT" id="04-118-227" href="#record" />
<EvidenceChip state="conflict" source="2 sources disagree" onClick={openInspector} />
```

Clickable chips open the provenance inspector. `conflict` is not an error state — it is an invitation to inspect.
