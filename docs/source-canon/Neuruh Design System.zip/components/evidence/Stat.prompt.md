One number, stated plainly. Numbers in this system are always mono and tabular so columns align and digits do not shimmer on update.

```jsx
<Stat label="Parcels swept" value="4,218" delta="+312" deltaDirection="up" foot="last 24h" />
<Stat size="hero" label="Recovery" value="$1.4M" foot="12 closings · FY26" />
```

`size="hero"` is for flagship and pitch frames only. Never invent a number — flag it as a placeholder instead.
