import React from "react";
import { Icon } from "./../core/Icon.jsx";

const GLYPH = { verified: "circle-check", unverified: "triangle-alert", conflict: "circle-alert", neutral: "database" };

/** Ordered list of every source that produced a value. */
export function ProvenanceTrail({ rows = [], className = "", ...rest }) {
  return (
    <div className={`n-provenance ${className}`.trim()} {...rest}>
      {rows.map((r, i) => (
        <div className="n-provenance__row" key={r.source + i}>
          <span className="n-provenance__mark" style={r.state === "conflict" ? { color: "var(--status-critical)" } : r.state === "verified" ? { color: "var(--status-verified)" } : r.state === "unverified" ? { color: "var(--status-caution)" } : undefined}>
            <Icon name={GLYPH[r.state || "neutral"]} size={13} />
          </span>
          <span className="n-provenance__source">{r.source}</span>
          <span className="n-provenance__value">{r.value}</span>
          <span className="n-provenance__stamp">{r.stamp}</span>
        </div>
      ))}
    </div>
  );
}
