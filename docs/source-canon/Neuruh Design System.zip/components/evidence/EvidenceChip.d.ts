/** Inline citation attached to a claim or value. */
export interface EvidenceChipProps {
  /** verified = corroborated. unverified = single uncorroborated source. conflict = sources disagree. */
  state?: "verified" | "unverified" | "conflict" | "neutral";
  /** Short source name, e.g. "SDAT" or "County Clerk". */
  source: string;
  /** Record locator shown in tabular mono. */
  id?: string;
  href?: string;
  onClick?: () => void;
  className?: string;
}
export function EvidenceChip(props: EvidenceChipProps): JSX.Element;
