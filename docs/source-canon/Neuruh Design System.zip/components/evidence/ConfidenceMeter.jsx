import React from "react";

/** Ten-tick confidence readout. */
export function ConfidenceMeter({ value = 0, label = "Confidence", basis, className = "", ...rest }) {
  const pct = Math.max(0, Math.min(100, value));
  const band = pct >= 80 ? "high" : pct >= 50 ? "medium" : "low";
  const on = Math.round(pct / 10);
  return (
    <div className={`n-confidence n-confidence--${band} ${className}`.trim()} {...rest}>
      <div className="n-confidence__head">
        <span className="n-confidence__label">{label}</span>
        <span className="n-confidence__value">{pct}%</span>
      </div>
      <div className="n-confidence__ticks">
        {Array.from({ length: 10 }, (_, i) => (
          <span key={i} className={`n-confidence__tick ${i < on ? "n-confidence__tick--on" : ""}`.trim()} />
        ))}
      </div>
      {basis ? <span className="n-confidence__basis">{basis}</span> : null}
    </div>
  );
}
