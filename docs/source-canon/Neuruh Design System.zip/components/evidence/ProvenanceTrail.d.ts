/** The inspector body: every source, what it said, and when. */
export interface ProvenanceRow {
  /** Source system name. */
  source: string;
  /** What that source reported. */
  value: React.ReactNode;
  /** Retrieval timestamp, mono tabular. */
  stamp?: string;
  state?: "verified" | "unverified" | "conflict" | "neutral";
}
export interface ProvenanceTrailProps extends React.HTMLAttributes<HTMLDivElement> {
  rows?: ProvenanceRow[];
}
export function ProvenanceTrail(props: ProvenanceTrailProps): JSX.Element;
