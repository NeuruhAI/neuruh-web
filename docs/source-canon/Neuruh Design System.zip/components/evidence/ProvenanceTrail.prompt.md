The body of the provenance inspector — resolves an `EvidenceChip` into the full lineage.

```jsx
<ProvenanceTrail rows={[
  { source: "SDAT", value: "MARTIN, R & K", stamp: "2026-07-28 03:14Z", state: "verified" },
  { source: "Clerk of Court", value: "MARTIN, ROBERT A", stamp: "2026-07-14 09:02Z", state: "conflict" },
]} />
```

Order newest-authoritative first. Always show the timestamp — staleness is part of the evidence.
