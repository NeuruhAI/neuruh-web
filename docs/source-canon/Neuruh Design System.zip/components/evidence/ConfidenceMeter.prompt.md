Quantifies how much to trust a machine output. Ticks are discrete on purpose — a continuous bar implies precision the model does not have.

```jsx
<ConfidenceMeter value={86} basis="4 of 4 sources agree · refreshed 6h ago" />
```

Always pair with `basis`. A confidence score with no stated basis is decoration.
