import React from "react";
import { Icon } from "./../core/Icon.jsx";

/** Single mono numeral with label and optional delta. */
export function Stat({ label, value, delta, deltaDirection = "flat", foot, size = "md", className = "", ...rest }) {
  const cls = ["n-stat", size !== "md" ? `n-stat--${size}` : "", className].filter(Boolean).join(" ");
  return (
    <div className={cls} {...rest}>
      {label ? <span className="n-stat__label">{label}</span> : null}
      <span className="n-stat__value">{value}</span>
      {delta || foot ? (
        <span className="n-stat__foot">
          {delta ? (
            <span className={`n-stat__delta n-stat__delta--${deltaDirection}`}>
              <Icon name={deltaDirection === "down" ? "trending-up" : "trending-up"} size={12} style={deltaDirection === "down" ? { transform: "scaleY(-1)" } : undefined} />
              {delta}
            </span>
          ) : null}
          {foot ? <span>{foot}</span> : null}
        </span>
      ) : null}
    </div>
  );
}
