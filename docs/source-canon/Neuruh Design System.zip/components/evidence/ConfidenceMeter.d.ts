/** Discrete ten-tick confidence readout. Bands: ≥80 verified green, ≥50 caution amber, below critical red. */
export interface ConfidenceMeterProps extends React.HTMLAttributes<HTMLDivElement> {
  /** 0–100. */
  value?: number;
  label?: string;
  /** One line naming what the score is computed from. */
  basis?: string;
}
export function ConfidenceMeter(props: ConfidenceMeterProps): JSX.Element;
