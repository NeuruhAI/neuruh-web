import React from "react";
import { Icon } from "./../core/Icon.jsx";

const GLYPH = { verified: "circle-check", unverified: "triangle-alert", conflict: "circle-alert", neutral: "link-2" };

/** Inline citation: which source backs this value. */
export function EvidenceChip({ state = "neutral", source, id, href, onClick, className = "", ...rest }) {
  const Tag = href ? "a" : onClick ? "button" : "span";
  const cls = ["n-evidence", state !== "neutral" ? `n-evidence--${state}` : "", className].filter(Boolean).join(" ");
  return (
    <Tag className={cls} href={href} onClick={onClick} type={onClick && !href ? "button" : undefined} {...rest}>
      <span className="n-evidence__mark"><Icon name={GLYPH[state]} size={11} /></span>
      <span>{source}</span>
      {id ? <span className="n-evidence__id">{id}</span> : null}
    </Tag>
  );
}
