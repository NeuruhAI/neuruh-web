/** A single number that carries a decision. Mono, tabular, large. */
export interface StatProps extends React.HTMLAttributes<HTMLDivElement> {
  label?: string;
  value: React.ReactNode;
  /** Change value, e.g. "+12.4%". */
  delta?: string;
  deltaDirection?: "up" | "down" | "flat";
  /** Trailing context — period, source, sample size. */
  foot?: React.ReactNode;
  /** hero = flagship-scale numeral. sm = inline in dense tables. */
  size?: "hero" | "md" | "sm";
}
export function Stat(props: StatProps): JSX.Element;
