/** Mono path trail — reinforces lineage, a brand-level trust property. */
export interface Crumb { label: string; href?: string }
export interface BreadcrumbsProps extends React.HTMLAttributes<HTMLElement> {
  items?: Array<string | Crumb>;
}
export function Breadcrumbs(props: BreadcrumbsProps): JSX.Element;
