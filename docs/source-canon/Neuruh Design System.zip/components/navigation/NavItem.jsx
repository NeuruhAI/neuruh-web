import React from "react";
import { Icon } from "./../core/Icon.jsx";

/** Sidebar row. */
export function NavItem({ icon, label, meta, active = false, href, className = "", ...rest }) {
  const cls = ["n-navitem", active ? "n-navitem--active" : "", className].filter(Boolean).join(" ");
  const inner = (
    <>
      {icon ? <Icon name={icon} size={16} /> : null}
      <span className="n-navitem__label">{label}</span>
      {meta != null ? <span className="n-navitem__meta">{meta}</span> : null}
    </>
  );
  if (href) return <a className={cls} href={href} aria-current={active ? "page" : undefined} {...rest}>{inner}</a>;
  return <button type="button" className={cls} aria-current={active ? "page" : undefined} {...rest}>{inner}</button>;
}
