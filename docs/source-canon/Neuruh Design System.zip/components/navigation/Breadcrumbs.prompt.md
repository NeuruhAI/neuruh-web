Shows lineage — which dataset, jurisdiction, and record the view belongs to.

```jsx
<Breadcrumbs items={[
  { label: "MD", href: "#" },
  { label: "Wicomico", href: "#" },
  "04-118-227",
]} />
```

Mono, slash-separated, last item is the current record and is not a link.
