The 48px chrome bar every operational surface starts with.

```jsx
<TopBar product="DeedSonar" left={<IconButton icon="panel-left" label="Toggle rail" />}
  right={<><StatusDot state="live" label="Live" pulse /><IconButton icon="settings" label="Settings" /></>}>
  <Breadcrumbs items={["MD","Wicomico","04-118-227"]} />
</TopBar>
```

The mark renders through `Wordmark`; pass `monogram` for the plate treatment. No logo file was supplied, so type stands in everywhere artwork would go — changing `Wordmark` updates every bar at once.
