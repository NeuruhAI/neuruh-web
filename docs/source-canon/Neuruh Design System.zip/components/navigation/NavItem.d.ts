/** One row in a sidebar rail. Active state is a 2px left signal bar plus wash. */
export interface NavItemProps {
  icon?: string;
  label: React.ReactNode;
  /** Right-aligned mono count or shortcut. */
  meta?: React.ReactNode;
  active?: boolean;
  href?: string;
  className?: string;
  onClick?: () => void;
}
export function NavItem(props: NavItemProps): JSX.Element;
