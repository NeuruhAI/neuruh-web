/** Product chrome bar: mark, product name, then view controls and account. Renders the mark via `Wordmark`. */
export interface TopBarProps extends React.HTMLAttributes<HTMLElement> {
  /** Sub-brand name shown after the wordmark, e.g. "DeedSonar". */
  product?: string;
  /** Show the N monogram plate beside the wordmark. */
  monogram?: boolean;
  /** Slot before the wordmark — sidebar toggle. */
  left?: React.ReactNode;
  /** Center slot — breadcrumbs or search. */
  children?: React.ReactNode;
  right?: React.ReactNode;
}
export function TopBar(props: TopBarProps): JSX.Element;
