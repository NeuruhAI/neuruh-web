import React from "react";
import { Icon } from "./../core/Icon.jsx";

/** Horizontal view switcher. Controlled via `value`/`onChange`. */
export function Tabs({ items = [], value, onChange, variant = "underline", className = "", ...rest }) {
  return (
    <div
      className={["n-tabs", variant === "enclosed" ? "n-tabs--enclosed" : "", className].filter(Boolean).join(" ")}
      role="tablist"
      {...rest}
    >
      {items.map((it) => {
        const id = typeof it === "string" ? it : it.id;
        const label = typeof it === "string" ? it : it.label;
        const active = id === value;
        return (
          <button
            key={id}
            type="button"
            role="tab"
            aria-selected={active}
            className={`n-tab ${active ? "n-tab--active" : ""}`.trim()}
            onClick={() => onChange && onChange(id)}
          >
            {it.icon ? <Icon name={it.icon} size={14} /> : null}
            {label}
            {it.count != null ? <span className="n-tab__count">{it.count}</span> : null}
          </button>
        );
      })}
    </div>
  );
}
