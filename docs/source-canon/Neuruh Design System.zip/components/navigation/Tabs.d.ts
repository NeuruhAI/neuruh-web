/** Horizontal view switcher. */
export interface TabItem { id: string; label: string; icon?: string; count?: number }
export interface TabsProps extends React.HTMLAttributes<HTMLDivElement> {
  items?: Array<string | TabItem>;
  value?: string;
  onChange?: (id: string) => void;
  /** underline = page-level sections. enclosed = compact segmented control inside a panel. */
  variant?: "underline" | "enclosed";
}
export function Tabs(props: TabsProps): JSX.Element;
