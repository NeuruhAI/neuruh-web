The sidebar row. Group them under `.n-nav__group` mono headings.

```jsx
<nav className="n-nav">
  <div className="n-nav__group">Surveillance</div>
  <NavItem icon="radar" label="Live sweep" meta="12" active />
  <NavItem icon="layers" label="Parcels" meta="4.2k" />
</nav>
```

Active is a left signal bar, not a filled pill. 40px rows on desktop.
