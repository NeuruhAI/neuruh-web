import React from "react";

/** Mono trail showing where the current record sits. */
export function Breadcrumbs({ items = [], className = "", ...rest }) {
  return (
    <nav className={`n-crumbs ${className}`.trim()} aria-label="Breadcrumb" {...rest}>
      {items.map((it, i) => {
        const label = typeof it === "string" ? it : it.label;
        const href = typeof it === "string" ? undefined : it.href;
        const last = i === items.length - 1;
        return (
          <React.Fragment key={label}>
            {i > 0 ? <span className="n-crumbs__sep">/</span> : null}
            {last || !href ? <span className="n-crumbs__current">{label}</span> : <a href={href}>{label}</a>}
          </React.Fragment>
        );
      })}
    </nav>
  );
}
