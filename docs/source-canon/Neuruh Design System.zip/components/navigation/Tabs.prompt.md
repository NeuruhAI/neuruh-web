Switches between peer views of the same object.

```jsx
<Tabs value={tab} onChange={setTab} items={[
  { id: "chain", label: "Title chain", count: 6 },
  { id: "liens", label: "Liens", count: 2 },
]} />
<Tabs variant="enclosed" value={range} onChange={setRange} items={["24H","7D","30D"]} />
```

`underline` for page sections (2px signal rule); `enclosed` for in-panel segmented controls.
