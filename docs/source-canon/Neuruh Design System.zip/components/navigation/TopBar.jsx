import React from "react";
import { Wordmark } from "./../brand/Wordmark.jsx";

/** 48px product chrome bar. The mark renders through Wordmark — no logo file exists. */
export function TopBar({ product, monogram = false, left, children, right, className = "", ...rest }) {
  return (
    <header className={`n-topbar ${className}`.trim()} {...rest}>
      <div className="n-topbar__brand">
        {left}
        <Wordmark size="sm" monogram={monogram} product={product} href="#" />
      </div>
      {children}
      <span className="n-topbar__spacer" />
      {right ? <div style={{ display: "flex", alignItems: "center", gap: "var(--space-3)" }}>{right}</div> : null}
    </header>
  );
}
