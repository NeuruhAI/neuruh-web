import React from "react";
import { IconButton } from "./../core/IconButton.jsx";

/** Modal. Renders nothing when `open` is false. */
export function Dialog({ open = false, title, description, footer, onClose, width, children, className = "", ...rest }) {
  if (!open) return null;
  return (
    <div className="n-dialog__scrim" onClick={onClose}>
      <div
        className={`n-dialog ${className}`.trim()}
        role="dialog"
        aria-modal="true"
        style={width ? { maxWidth: width } : undefined}
        onClick={(e) => e.stopPropagation()}
        {...rest}
      >
        <div className="n-dialog__header">
          <div style={{ flex: 1, minWidth: 0 }}>
            {title ? <h2 className="n-dialog__title">{title}</h2> : null}
            {description ? <p className="n-dialog__desc">{description}</p> : null}
          </div>
          {onClose ? <IconButton icon="x" size="sm" label="Close" onClick={onClose} /> : null}
        </div>
        {children ? <div className="n-dialog__body">{children}</div> : null}
        {footer ? <div className="n-dialog__footer">{footer}</div> : null}
      </div>
    </div>
  );
}
