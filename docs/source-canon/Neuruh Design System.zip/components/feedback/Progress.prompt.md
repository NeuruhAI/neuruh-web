Shows work in flight or a quantity against a ceiling (budget, quota, match strength).

```jsx
<Progress value={68} />
<Progress indeterminate />
<Progress value={92} tone="caution" />
```

4px, pill ends, no label built in — pair it with a `Stat` or a mono percentage.
