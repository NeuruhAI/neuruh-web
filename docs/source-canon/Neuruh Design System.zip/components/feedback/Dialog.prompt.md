Blocks the view for a decision — confirmations, armed actions, provenance detail.

```jsx
<Dialog open={open} onClose={close} title="Arm outreach sequence"
  description="47 owners will receive the first touch within 15 minutes."
  footer={<><Button onClick={close}>Cancel</Button><Button variant="primary">Arm</Button></>}>
  …
</Dialog>
```

Scrim click closes. Rises 6px over 180ms. Do not nest dialogs.
