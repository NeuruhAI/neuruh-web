/** Hover/focus label for icon-only controls and truncated machine values. */
export interface TooltipProps extends React.HTMLAttributes<HTMLSpanElement> {
  content: React.ReactNode;
  side?: "top" | "bottom" | "left" | "right";
  children?: React.ReactNode;
}
export function Tooltip(props: TooltipProps): JSX.Element;
