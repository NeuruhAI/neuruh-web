/** 4px progress bar. Omit `value` and set `indeterminate` for unknown duration. */
export interface ProgressProps extends React.HTMLAttributes<HTMLDivElement> {
  /** 0–100. */
  value?: number;
  tone?: "accent" | "verified" | "caution" | "critical";
  indeterminate?: boolean;
}
export function Progress(props: ProgressProps): JSX.Element;
