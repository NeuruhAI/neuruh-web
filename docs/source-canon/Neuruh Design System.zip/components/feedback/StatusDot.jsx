import React from "react";

/** Machine state indicator: dot + uppercase mono label. */
export function StatusDot({ state = "inert", label, pulse = false, className = "", ...rest }) {
  const cls = ["n-status", `n-status--${state}`, pulse ? "n-status--pulse" : "", className].filter(Boolean).join(" ");
  return (
    <span className={cls} {...rest}>
      <span className="n-status__dot" />
      {label ? <span>{label}</span> : null}
    </span>
  );
}
