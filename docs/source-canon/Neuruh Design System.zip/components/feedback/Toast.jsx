import React from "react";
import { Icon } from "./../core/Icon.jsx";
import { IconButton } from "./../core/IconButton.jsx";

const GLYPH = { info: "circle-alert", success: "circle-check", caution: "triangle-alert", critical: "circle-alert" };

/** Transient notification. */
export function Toast({ tone = "info", title, message, onDismiss, className = "", ...rest }) {
  return (
    <div className={`n-toast n-toast--${tone} ${className}`.trim()} role="status" {...rest}>
      <span className="n-toast__icon"><Icon name={GLYPH[tone]} size={16} /></span>
      <div style={{ flex: 1, minWidth: 0 }}>
        {title ? <div className="n-toast__title">{title}</div> : null}
        {message ? <div className="n-toast__msg">{message}</div> : null}
      </div>
      {onDismiss ? <IconButton icon="x" size="sm" label="Dismiss" onClick={onDismiss} /> : null}
    </div>
  );
}
