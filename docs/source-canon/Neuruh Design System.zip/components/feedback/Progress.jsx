import React from "react";

/** Determinate or indeterminate 4px bar. */
export function Progress({ value = 0, tone = "accent", indeterminate = false, className = "", ...rest }) {
  const cls = [
    "n-progress",
    tone !== "accent" ? `n-progress--${tone}` : "",
    indeterminate ? "n-progress--indeterminate" : "",
    className,
  ]
    .filter(Boolean)
    .join(" ");
  const pct = Math.max(0, Math.min(100, value));
  return (
    <div
      className={cls}
      role="progressbar"
      aria-valuenow={indeterminate ? undefined : pct}
      aria-valuemin={0}
      aria-valuemax={100}
      {...rest}
    >
      <div className="n-progress__fill" style={indeterminate ? undefined : { width: `${pct}%` }} />
    </div>
  );
}
