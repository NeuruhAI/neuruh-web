/** Machine state indicator. */
export interface StatusDotProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** live carries the only sanctioned glow in the system. */
  state?: "live" | "verified" | "caution" | "critical" | "inert";
  label?: string;
  /** Slow opacity pulse — only for genuinely streaming state. */
  pulse?: boolean;
}
export function StatusDot(props: StatusDotProps): JSX.Element;
