Confirms something happened out of band. Stack bottom-right, max three, auto-dismiss non-critical after ~6s.

```jsx
<Toast tone="success" title="Export queued" message="14 parcels · CSV" onDismiss={close} />
<Toast tone="critical" title="Assessor feed unreachable" message="Retrying in 30s" />
```

Critical toasts never auto-dismiss. The tone is carried by a 2px left border, not a filled background.
