Reports what a system is doing right now. The `live` state is the one place a glow is permitted, because it is semantic.

```jsx
<StatusDot state="live" label="Streaming" pulse />
<StatusDot state="critical" label="Feed down" />
```

Never use `pulse` decoratively — a pulsing dot means data is moving.
