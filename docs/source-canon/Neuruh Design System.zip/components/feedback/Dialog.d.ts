/** Modal for decisions that must not be lost behind navigation. */
export interface DialogProps extends React.HTMLAttributes<HTMLDivElement> {
  open?: boolean;
  title?: React.ReactNode;
  description?: React.ReactNode;
  /** Footer actions — primary last, right-aligned. */
  footer?: React.ReactNode;
  onClose?: () => void;
  /** Overrides the 520px max width. */
  width?: number | string;
  children?: React.ReactNode;
}
export function Dialog(props: DialogProps): JSX.Element | null;
