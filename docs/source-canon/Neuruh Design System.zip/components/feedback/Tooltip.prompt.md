Names an icon-only control or expands a truncated machine value. Never hides information a user needs to act.

```jsx
<Tooltip content="Last synced 03:14:22Z" side="bottom">
  <IconButton icon="clock" label="Sync status" />
</Tooltip>
```

Single line, mono, no wrapping. Opens on hover and on keyboard focus.
