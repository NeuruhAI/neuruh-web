import React from "react";

/** Hover/focus label. Mono, single line. */
export function Tooltip({ content, side = "top", children, className = "", ...rest }) {
  const [open, setOpen] = React.useState(false);
  return (
    <span
      className={`n-tooltip ${className}`.trim()}
      onMouseEnter={() => setOpen(true)}
      onMouseLeave={() => setOpen(false)}
      onFocus={() => setOpen(true)}
      onBlur={() => setOpen(false)}
      {...rest}
    >
      {children}
      {open && content ? <span className={`n-tooltip__bubble n-tooltip__bubble--${side}`} role="tooltip">{content}</span> : null}
    </span>
  );
}
