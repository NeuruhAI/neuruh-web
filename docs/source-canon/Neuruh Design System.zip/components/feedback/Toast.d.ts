/** Transient notification with a 2px tone bar on the leading edge. */
export interface ToastProps extends React.HTMLAttributes<HTMLDivElement> {
  tone?: "info" | "success" | "caution" | "critical";
  title?: React.ReactNode;
  message?: React.ReactNode;
  /** Supplying a handler renders the dismiss button. */
  onDismiss?: () => void;
}
export function Toast(props: ToastProps): JSX.Element;
