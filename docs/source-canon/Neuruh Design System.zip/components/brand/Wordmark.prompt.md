Renders the Neuruh mark. Use it anywhere the brand appears — never type "Neuruh" as literal text in a header.

```jsx
<Wordmark size="md" product="DeedSonar" href="/" />
<Wordmark monogram size="lg" />
<Seal eyebrow="Investor brief · FY26" size={84} />
```

There is **no logo file** in this design system; the mark is Archivo 800 at -0.055em, and the monogram is an `N` in a brushed plate with a brass leading rule. This component is the one place to swap when real artwork lands. `tone="inverse"` forces light-on-dark over imagery; `tone="auto"` follows the surface.
