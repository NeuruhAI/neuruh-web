import React from "react";

const WORD = { sm: 15, md: 21, lg: 34, xl: 56, display: 112 };
const GLYPH = { sm: 22, md: 28, lg: 40, xl: 60, display: 112 };

/**
 * The Neuruh mark. Typographic by design — no logo artwork was supplied.
 * Swap the glyph content here when real artwork arrives; the lockup geometry
 * is what the rest of the system depends on.
 */
export function Wordmark({
  size = "md",
  monogram = false,
  product,
  stacked = false,
  divided = true,
  tone = "auto",
  href,
  className = "",
  ...rest
}) {
  const cls = [
    "n-mark",
    tone === "inverse" ? "n-mark--inverse" : tone === "onlight" ? "n-mark--onlight" : "",
    stacked ? "n-mark--stacked" : "",
    divided && product && !stacked ? "n-mark--divided" : "",
    className,
  ]
    .filter(Boolean)
    .join(" ");
  const w = WORD[size] || WORD.md;
  const g = GLYPH[size] || GLYPH.md;
  const body = (
    <>
      {monogram ? (
        <span className="n-mark__glyph" style={{ width: g, fontSize: g * 0.62 }} aria-hidden="true"><span>N</span></span>
      ) : null}
      {monogram && !product ? null : (
        <span className="n-mark__lockup">
          <span className="n-mark__word" style={{ fontSize: w }}>Neuruh</span>
          {product && stacked ? <span className="n-mark__product">{product}</span> : null}
        </span>
      )}
      {product && !stacked ? <span className="n-mark__product">{product}</span> : null}
    </>
  );
  if (href) return <a className={cls} href={href} aria-label={product ? `Neuruh ${product}` : "Neuruh"} {...rest}>{body}</a>;
  return <span className={cls} {...rest}>{body}</span>;
}

/** Display lockup for deck covers, report title pages, and certificates. */
export function Seal({ eyebrow = "Neuruh Org", size = 72, className = "", ...rest }) {
  return (
    <span className={`n-seal ${className}`.trim()} {...rest}>
      <span className="n-seal__word" style={{ fontSize: size }}>Neuruh</span>
      {eyebrow ? <span className="n-seal__rule">{eyebrow}</span> : null}
    </span>
  );
}
