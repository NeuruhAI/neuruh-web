/**
 * The Neuruh brand mark, set in type.
 *
 * NOTE: no logo artwork exists in the source package. This component is the
 * sanctioned stand-in and the single place to change when artwork arrives —
 * every surface should render the mark through it rather than typing "Neuruh".
 */
export interface WordmarkProps {
  /** sm 15px · md 21px · lg 34px · xl 56px · display 112px (wordmark cap height). */
  size?: "sm" | "md" | "lg" | "xl" | "display";
  /** Show the N monogram plate. With `monogram` and no `product`, renders the plate alone. */
  monogram?: boolean;
  /** Sub-brand name, e.g. "DeedSonar". Rendered as a mono system label. */
  product?: string;
  /** Stack the product name below the wordmark instead of beside it. */
  stacked?: boolean;
  /** Hairline divider between wordmark and product name. Ignored when stacked. */
  divided?: boolean;
  /** auto follows the surface. inverse forces light-on-dark. onlight forces dark ink. */
  tone?: "auto" | "inverse" | "onlight";
  href?: string;
  className?: string;
}
export function Wordmark(props: WordmarkProps): JSX.Element;

/** Display lockup for deck covers, report title pages, and certificates. */
export interface SealProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** Rule-flanked label under the wordmark. */
  eyebrow?: string;
  /** Wordmark font size in px. */
  size?: number;
}
export function Seal(props: SealProps): JSX.Element;
