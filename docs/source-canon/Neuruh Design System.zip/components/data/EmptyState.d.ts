/**
 * Shown when a surface has no content — no results, no coverage, or content
 * the source material never specified. Never leave a blank panel.
 */
export interface EmptyStateProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Icon name, or null for no mark. */
  icon?: string | null;
  /** Mono uppercase eyebrow — e.g. "Not specified in source package". */
  label?: string;
  title?: React.ReactNode;
  /** One or two sentences saying what would be here and what unblocks it. */
  children?: React.ReactNode;
  actions?: React.ReactNode;
  /** unavailable = out of coverage / no data available, rather than merely empty. */
  variant?: "default" | "unavailable";
  /** Diagonal hatch fill — reserved for genuinely unavailable regions. */
  hatched?: boolean;
}
export function EmptyState(props: EmptyStateProps): JSX.Element;
