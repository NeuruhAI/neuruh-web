Every panel that can be empty needs one. This is also the sanctioned way to mark a gap in source material — honest blanks over invented content is a brand rule.

```jsx
<EmptyState icon="funnel" title="No parcels match" actions={<Button size="sm" variant="secondary">Clear filters</Button>}>
  Three filters are active. Widen the assessed-value range or drop the conveyance-age filter.
</EmptyState>

<EmptyState variant="unavailable" hatched icon="map-pin"
  label="Not specified in source package" title="No tax-history layout">
  Left intentionally blank rather than invented. Supply the layout and this panel renders.
</EmptyState>
```

Always say what unblocks it. `hatched` is for genuinely unavailable or out-of-coverage regions — not for a filtered-to-zero result.
