import React from "react";
import { Icon } from "./../core/Icon.jsx";

/**
 * The state a surface shows when it has nothing — including, deliberately,
 * "this was not specified in the source material". Honest gaps over invented
 * content is a brand rule, so it needs a first-class component.
 */
export function EmptyState({
  icon = "layers",
  label,
  title,
  children,
  actions,
  variant = "default",
  hatched = false,
  className = "",
  ...rest
}) {
  const cls = [
    "n-empty",
    variant !== "default" ? `n-empty--${variant}` : "",
    hatched ? "n-hatch" : "",
    hatched && variant === "unavailable" ? "n-hatch--caution" : "",
    className,
  ]
    .filter(Boolean)
    .join(" ");
  return (
    <div className={cls} {...rest}>
      {icon ? <span className="n-empty__mark"><Icon name={icon} size={18} /></span> : null}
      {label ? <span className="n-label">{label}</span> : null}
      {title ? <h3 className="n-empty__title">{title}</h3> : null}
      {children ? <p className="n-empty__body">{children}</p> : null}
      {actions ? <div className="n-empty__actions">{actions}</div> : null}
    </div>
  );
}
