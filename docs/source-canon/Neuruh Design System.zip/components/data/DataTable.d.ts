/** One column definition. Formatting is declared here, never inline per cell. */
export interface DataColumn<Row = any> {
  /** Property read from the row, and the sort identifier. */
  key: string;
  label: React.ReactNode;
  align?: "left" | "right" | "center";
  /** Mono tabular figures. Set on every numeric column. */
  numeric?: boolean;
  /** Brightest text — the column a scanner reads first. One per table. */
  primary?: boolean;
  /** Mono accent treatment for identifiers (parcel IDs, run IDs, hashes). */
  mono?: boolean;
  sortable?: boolean;
  width?: number | string;
  /** Custom cell renderer — use for Badges, EvidenceChips, Sparklines. */
  render?: (row: Row) => React.ReactNode;
}

/** The operational workhorse. Rows are sticky-header scrollable by default. */
export interface DataTableProps<Row = any> extends React.TableHTMLAttributes<HTMLTableElement> {
  columns?: DataColumn<Row>[];
  rows?: Row[];
  /** Property used as the React key and selection identifier. Default "id". */
  rowKey?: string;
  /** tight 32px · default 40px · loose 52px. Operational tables run tight. */
  density?: "tight" | "default" | "loose";
  selectedKey?: string | number;
  /** Rows to mark with a critical leading bar — conflicts, liens, breaches. */
  flaggedKeys?: Array<string | number>;
  /** Supplying a handler makes rows interactive. */
  onSelect?: (key: string | number, row: Row) => void;
  sort?: { key: string; dir: "asc" | "desc" };
  onSort?: (key: string) => void;
  /** Footer strip — counts and pagination. Stays pinned outside the scroller. */
  footer?: React.ReactNode;
  /**
   * Caps the table body's height and gives the scroller vertical scroll, which
   * is what makes the sticky header work. Omit and the page scrolls instead —
   * headers then scroll away with it. Set this whenever a table is long enough
   * that the header matters.
   */
  maxHeight?: number | string;
}
export function DataTable<Row = any>(props: DataTableProps<Row>): JSX.Element;
