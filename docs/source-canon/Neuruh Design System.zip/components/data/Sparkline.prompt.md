Inline trend, sized for a table cell or beside a `Stat`.

```jsx
<Stat label="Feed latency" value="1.8s" foot={<Sparkline values={latency} tone="caution" width={72} height={18} area={false} />} />
```

It is a shape, not a chart — no axes, no tooltip, no legend. Tone carries meaning: `caution` for a metric drifting out of budget, `metal` for a non-semantic reference series. Fewer than two values renders nothing rather than a flat line that implies stability.
