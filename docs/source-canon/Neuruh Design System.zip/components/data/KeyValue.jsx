import React from "react";

/** Attribute list. Mono uppercase keys, tabular values. */
export function KeyValue({ items = [], layout = "rows", className = "", ...rest }) {
  const cls = ["n-kv", layout === "columns" ? "n-kv--columns" : layout === "stacked" ? "n-kv--stacked" : "", className]
    .filter(Boolean)
    .join(" ");
  return (
    <dl className={cls} {...rest}>
      {items.map((it, i) => (
        <div className="n-kv__row" key={(it.key || "") + i}>
          <dt className="n-kv__key">{it.key}</dt>
          <dd className="n-kv__val" style={{ margin: 0 }}>{it.value}</dd>
        </div>
      ))}
    </dl>
  );
}
