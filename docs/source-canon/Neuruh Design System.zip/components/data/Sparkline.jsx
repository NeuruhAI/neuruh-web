import React from "react";

/** Inline trend. No axes, no gridlines, no tooltip — a shape, not a chart. */
export function Sparkline({
  values = [],
  width = 92,
  height = 24,
  tone = "accent",
  area = true,
  dot = true,
  baseline = false,
  className = "",
  ...rest
}) {
  if (values.length < 2) return null;
  const min = Math.min(...values);
  const max = Math.max(...values);
  const span = max - min || 1;
  const pad = 2;
  const px = (i) => pad + (i / (values.length - 1)) * (width - pad * 2);
  const py = (v) => height - pad - ((v - min) / span) * (height - pad * 2);
  const line = values.map((v, i) => `${i ? "L" : "M"}${px(i).toFixed(1)},${py(v).toFixed(1)}`).join(" ");
  const fill = `${line} L${px(values.length - 1).toFixed(1)},${height} L${px(0).toFixed(1)},${height} Z`;
  const midY = py(min + span / 2).toFixed(1);
  return (
    <svg
      className={["n-spark", tone !== "accent" ? `n-spark--${tone}` : "", className].filter(Boolean).join(" ")}
      width={width}
      height={height}
      viewBox={`0 0 ${width} ${height}`}
      role="img"
      aria-hidden="true"
      {...rest}
    >
      {baseline ? <line className="n-spark__baseline" x1={0} y1={midY} x2={width} y2={midY} /> : null}
      {area ? <path className="n-spark__area" d={fill} /> : null}
      <path className="n-spark__line" d={line} />
      {dot ? <circle className="n-spark__dot" cx={px(values.length - 1)} cy={py(values[values.length - 1])} r={1.8} /> : null}
    </svg>
  );
}
