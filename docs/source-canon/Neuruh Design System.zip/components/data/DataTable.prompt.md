The operational workhorse. Every Neuruh product is fundamentally a table with context around it — use this rather than hand-writing `<table>`.

```jsx
<DataTable
  density="tight"
  rowKey="id"
  selectedKey={selected}
  flaggedKeys={["11-006-882"]}
  onSelect={setSelected}
  sort={sort} onSort={cycleSort}
  columns={[
    { key: "id", label: "Parcel", mono: true, sortable: true },
    { key: "owner", label: "Owner of record", primary: true },
    { key: "assessed", label: "Assessed", align: "right", numeric: true, sortable: true },
    { key: "status", label: "Title status", render: (r) => <Badge tone={r.tone}>{r.status}</Badge> },
  ]}
  rows={rows}
  footer={<><span style={{ flex: 1 }}>Showing 6 of 4,218</span><Button size="sm" variant="secondary">Next</Button></>}
/>
```

Declare formatting on the column (`numeric`, `mono`, `primary`) rather than styling cells — that is what keeps columns aligned across screens. Set `primary` on exactly one column.

The table owns its own horizontal scroll (cells are `nowrap`, so wide tables scroll inside the panel rather than breaching it) and the footer stays pinned outside that scroller. **Sticky headers require `maxHeight`** — capping the body is what gives the scroller vertical scroll for `top: 0` to engage. Without it the page scrolls and the header scrolls away with it, which is the right behaviour for a short table on a scrolling screen.
