import React from "react";
import { Icon } from "./../core/Icon.jsx";

/**
 * Declarative table. Columns describe alignment and formatting so numbers get
 * mono tabular treatment automatically instead of per-cell inline styles.
 */
export function DataTable({
  columns = [],
  rows = [],
  rowKey = "id",
  density = "default",
  selectedKey,
  flaggedKeys,
  onSelect,
  sort,
  onSort,
  footer,
  maxHeight,
  className = "",
  ...rest
}) {
  const flagged = React.useMemo(() => new Set(flaggedKeys || []), [flaggedKeys]);
  const cls = [
    "n-table",
    density !== "default" ? `n-table--${density}` : "",
    onSelect ? "n-table--interactive" : "",
    className,
  ]
    .filter(Boolean)
    .join(" ");
  return (
    <>
      <div
        className={maxHeight ? "n-table-scroll n-table-scroll--capped" : "n-table-scroll"}
        style={maxHeight ? { maxHeight } : undefined}
      >
      <table className={cls} {...rest}>
        <thead>
          <tr>
            {columns.map((c) => {
              const active = sort && sort.key === c.key;
              return (
                <th
                  key={c.key}
                  data-align={c.align}
                  data-sortable={c.sortable ? "" : undefined}
                  aria-sort={active ? (sort.dir === "asc" ? "ascending" : "descending") : undefined}
                  style={c.width ? { width: c.width } : undefined}
                  onClick={c.sortable && onSort ? () => onSort(c.key) : undefined}
                >
                  {c.label}
                  {active ? (
                    <span className="n-table__sort">
                      <Icon name="chevron-down" size={12} style={sort.dir === "asc" ? { transform: "scaleY(-1)" } : undefined} />
                    </span>
                  ) : null}
                </th>
              );
            })}
          </tr>
        </thead>
        <tbody>
          {rows.map((r) => {
            const k = r[rowKey];
            return (
              <tr
                key={k}
                aria-selected={selectedKey === k ? "true" : undefined}
                data-flagged={flagged.has(k) && selectedKey !== k ? "" : undefined}
                onClick={onSelect ? () => onSelect(k, r) : undefined}
              >
                {columns.map((c) => (
                  <td
                    key={c.key}
                    data-align={c.align}
                    data-numeric={c.numeric ? "" : undefined}
                    data-primary={c.primary ? "" : undefined}
                    data-key={c.mono ? "" : undefined}
                  >
                    {c.render ? c.render(r) : r[c.key]}
                  </td>
                ))}
              </tr>
            );
          })}
        </tbody>
      </table>
      </div>
      {footer ? <div className="n-table__foot">{footer}</div> : null}
    </>
  );
}
