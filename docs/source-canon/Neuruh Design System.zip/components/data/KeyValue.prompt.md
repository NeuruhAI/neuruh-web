Attribute lists — record detail panels, run parameters, scene metadata.

```jsx
<KeyValue items={[
  { key: "Assessed value", value: "$284,100" },
  { key: "Coordinates", value: "38.3607°N 75.5994°W" },
]} />
<KeyValue layout="columns" items={attrs} />
```

Keys are mono uppercase labels; values are mono tabular and right-aligned so a column of figures lines up. Use `layout="stacked"` when values are long enough to wrap.
