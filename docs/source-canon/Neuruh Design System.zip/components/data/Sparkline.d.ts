/**
 * Inline trend shape. Deliberately minimal — no axes, gridlines, or tooltips.
 * If a reader needs to know exact values, pair it with a Stat, do not add chrome.
 */
export interface SparklineProps extends React.SVGAttributes<SVGSVGElement> {
  /** Two or more values. Fewer renders nothing rather than a misleading flat line. */
  values?: number[];
  width?: number;
  height?: number;
  tone?: "accent" | "verified" | "caution" | "critical" | "metal";
  /** Wash under the line. Turn off inside dense table cells. */
  area?: boolean;
  /** Marks the latest value. */
  dot?: boolean;
  /** Dashed midline for reading direction of travel. */
  baseline?: boolean;
}
export function Sparkline(props: SparklineProps): JSX.Element | null;
