/** Attribute list — record detail, scene metadata, run parameters. */
export interface KeyValueItem {
  key: React.ReactNode;
  value: React.ReactNode;
}
export interface KeyValueProps extends React.HTMLAttributes<HTMLDListElement> {
  items?: KeyValueItem[];
  /** rows = key left / value right. columns = two-up. stacked = value under key, for long values. */
  layout?: "rows" | "columns" | "stacked";
}
export function KeyValue(props: KeyValueProps): JSX.Element;
