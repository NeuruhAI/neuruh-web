import React from "react";

/** Panel container. Header/body/footer are optional slots. */
export function Card({
  title,
  label,
  actions,
  footer,
  variant = "default",
  interactive = false,
  flushBody = false,
  children,
  className = "",
  ...rest
}) {
  const cls = [
    "n-card",
    variant !== "default" ? `n-card--${variant}` : "",
    interactive ? "n-card--interactive" : "",
    className,
  ]
    .filter(Boolean)
    .join(" ");
  return (
    <div className={cls} {...rest}>
      {title || label || actions ? (
        <div className="n-card__header">
          <div style={{ display: "flex", flexDirection: "column", gap: "var(--space-1)", flex: 1, minWidth: 0 }}>
            {label ? <span className="n-label">{label}</span> : null}
            {title ? <h3 className="n-card__title">{title}</h3> : null}
          </div>
          {actions ? <div style={{ display: "flex", alignItems: "center", gap: "var(--space-2)", flex: "none" }}>{actions}</div> : null}
        </div>
      ) : null}
      <div className={flushBody ? "n-card__body n-card__body--flush" : "n-card__body"}>{children}</div>
      {footer ? <div className="n-card__footer">{footer}</div> : null}
    </div>
  );
}
