import React from "react";
import { Icon } from "./Icon.jsx";

/** Square icon-only control for toolbars and panel headers. */
export function IconButton({ icon, size = "md", label, bordered = false, pressed, className = "", ...rest }) {
  const cls = ["n-iconbtn", `n-iconbtn--${size}`, bordered ? "n-iconbtn--bordered" : "", className]
    .filter(Boolean)
    .join(" ");
  const glyph = size === "sm" ? 14 : size === "lg" ? 18 : 16;
  return (
    <button type="button" className={cls} aria-label={label} aria-pressed={pressed} {...rest}>
      <Icon name={icon} size={glyph} />
    </button>
  );
}
