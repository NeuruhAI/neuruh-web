/** Compact uppercase mono status marker — state, not a label. */
export interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  tone?: "neutral" | "accent" | "verified" | "caution" | "critical" | "outline";
  icon?: string;
  children?: React.ReactNode;
}
export function Badge(props: BadgeProps): JSX.Element;
