import React from "react";
import { Icon } from "./Icon.jsx";

/** Pill for user-applied filters and categories. */
export function Tag({ selected = false, onRemove, icon, children, className = "", ...rest }) {
  return (
    <span className={`n-tag ${selected ? "n-tag--selected" : ""} ${className}`.trim()} {...rest}>
      {icon ? <Icon name={icon} size={12} /> : null}
      {children}
      {onRemove ? (
        <button type="button" className="n-tag__remove" aria-label="Remove" onClick={onRemove}>
          <Icon name="x" size={12} />
        </button>
      ) : null}
    </span>
  );
}
