/**
 * A glyph from the Neuruh icon set. 24px grid, 1.5px stroke, round caps.
 * Names match the filenames in assets/icons/ (e.g. "radar", "shield", "triangle-alert").
 */
export interface IconProps {
  /** Icon name — filename stem from assets/icons/, e.g. "crosshair". */
  name: string;
  /** Rendered box in px. Use 14 inline with text, 16 in UI, 20+ standalone. */
  size?: number;
  /** Stroke weight. Keep 1.5 unless matching a heavier display context. */
  strokeWidth?: number;
  className?: string;
  /** Supplying a title makes the icon exposed to assistive tech. */
  title?: string;
  style?: React.CSSProperties;
}
export function Icon(props: IconProps): JSX.Element | null;
