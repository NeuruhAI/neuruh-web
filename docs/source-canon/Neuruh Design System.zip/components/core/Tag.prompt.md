Represents something the user chose — an active filter, a category, a saved facet.

```jsx
<Tag icon="map-pin" onRemove={() => drop("wicomico")}>Wicomico County</Tag>
<Tag selected>Off-market</Tag>
```

Pill radius here is deliberate and is the only place the system rounds fully — it reads as removable. Sentence case, not uppercase (that is `Badge`).
