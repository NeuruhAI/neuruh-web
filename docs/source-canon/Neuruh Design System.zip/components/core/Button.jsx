import React from "react";
import { Icon } from "./Icon.jsx";

/** The primary action primitive. Five variants, three sizes. */
export function Button({
  variant = "secondary",
  size = "md",
  icon,
  iconAfter,
  block = false,
  href,
  children,
  className = "",
  ...rest
}) {
  const cls = ["n-btn", `n-btn--${variant}`, `n-btn--${size}`, block ? "n-btn--block" : "", className]
    .filter(Boolean)
    .join(" ");
  const glyph = size === "sm" ? 13 : size === "lg" ? 17 : 15;
  const inner = (
    <>
      {icon ? <Icon name={icon} size={glyph} /> : null}
      {children ? <span>{children}</span> : null}
      {iconAfter ? <Icon name={iconAfter} size={glyph} /> : null}
    </>
  );
  if (href) return <a className={cls} href={href} {...rest}>{inner}</a>;
  return <button type="button" className={cls} {...rest}>{inner}</button>;
}
