States a machine-readable condition in one or two words. Always uppercase mono, 20px tall, 2px radius.

```jsx
<Badge tone="verified" icon="circle-check">Verified</Badge>
<Badge tone="caution">Stale 14d</Badge>
<Badge tone="critical">Lien</Badge>
```

Use `Badge` for state and `Tag` for user-applied categories. Never put sentences in a badge.
