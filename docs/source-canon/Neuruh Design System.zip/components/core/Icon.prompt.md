Renders a single glyph from the Neuruh icon set; use it anywhere an icon is needed instead of inlining SVG.

```jsx
<Icon name="radar" size={16} />
<Icon name="triangle-alert" size={14} style={{ color: "var(--status-caution)" }} />
```

Icons inherit `currentColor`. Available names are the filename stems in `assets/icons/` — 48 glyphs covering navigation, status, data, geo, and system actions. An unknown name renders nothing rather than a broken box.
