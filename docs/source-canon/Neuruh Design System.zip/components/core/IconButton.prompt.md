Icon-only control for toolbars, panel headers, and table row actions.

```jsx
<IconButton icon="refresh-cw" label="Refresh telemetry" />
<IconButton icon="panel-left" label="Toggle sidebar" pressed bordered />
```

`label` is required. Set `pressed` for toggles — it renders the signal wash + accent border. 28/36/44px sizes; use 44px on touch surfaces.
