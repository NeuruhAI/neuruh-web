import React from "react";
import { Icon } from "./Icon.jsx";

/** Compact mono status marker. */
export function Badge({ tone = "neutral", icon, children, className = "", ...rest }) {
  return (
    <span className={`n-badge n-badge--${tone} ${className}`.trim()} {...rest}>
      {icon ? <Icon name={icon} size={11} /> : null}
      {children}
    </span>
  );
}
