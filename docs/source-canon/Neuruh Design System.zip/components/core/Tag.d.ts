/** Pill for user-applied filters, categories, and saved query chips. */
export interface TagProps extends React.HTMLAttributes<HTMLSpanElement> {
  selected?: boolean;
  /** Supplying a handler renders the dismiss affordance. */
  onRemove?: () => void;
  icon?: string;
  children?: React.ReactNode;
}
export function Tag(props: TagProps): JSX.Element;
