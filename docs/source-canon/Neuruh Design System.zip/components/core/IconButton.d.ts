/** Icon-only square control. Always pass `label` — it becomes the accessible name. */
export interface IconButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  icon: string;
  size?: "sm" | "md" | "lg";
  /** Required accessible name. */
  label: string;
  /** Adds a hairline border + raised surface. Use in dense toolbars. */
  bordered?: boolean;
  /** Renders the active toggle treatment (signal wash). */
  pressed?: boolean;
  className?: string;
}
export function IconButton(props: IconButtonProps): JSX.Element;
