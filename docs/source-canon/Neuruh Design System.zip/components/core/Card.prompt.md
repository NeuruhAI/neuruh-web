The panel container. Cards on dark surfaces separate with a hairline, not a shadow; on `[data-surface="light"]` they pick up `--shadow-1` automatically.

```jsx
<Card label="Parcel 04-118-227" title="Title chain" actions={<IconButton icon="external-link" label="Open record" />}>
  …
</Card>
<Card variant="inset" flushBody><table>…</table></Card>
```

6px radius, never more. `variant="accent"` marks the one card the user must act on. `interactive` adds the hover lift (border brightens, surface raises — no transform).
