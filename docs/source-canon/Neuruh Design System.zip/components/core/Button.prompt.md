The action primitive — one `primary` per view, everything else `secondary` or `ghost`.

```jsx
<Button variant="primary" icon="scan-line">Run scan</Button>
<Button variant="secondary">Cancel</Button>
<Button variant="command" size="sm" icon="zap">Arm sequence</Button>
```

Variants: `primary` (solid signal blue), `secondary` (raised surface + hairline), `ghost` (no chrome, for toolbars), `danger` (outlined red — never solid red), `command` (mono uppercase, reserved for system-level/armed operations). Sizes `sm` 28px / `md` 36px / `lg` 44px. Press state is a 1px downward nudge, no scale.
