/** Panel container — the unit of composition on every operational surface. */
export interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Header title. Omit for a bare container. */
  title?: React.ReactNode;
  /** Mono uppercase eyebrow above the title. */
  label?: string;
  /** Header-right controls, usually IconButtons. */
  actions?: React.ReactNode;
  footer?: React.ReactNode;
  /** inset = sunken well. flush = square corners for edge-to-edge panels. accent = signal border. */
  variant?: "default" | "inset" | "flush" | "accent";
  interactive?: boolean;
  /** Removes body padding — for tables and lists that own their own insets. */
  flushBody?: boolean;
  children?: React.ReactNode;
}
export function Card(props: CardProps): JSX.Element;
