import React from "react";
import { ICON_PATHS } from "../../assets/icons/icon-paths.js";

/** Renders a glyph from the Neuruh icon set (Lucide geometry, 24px grid, 1.5 stroke). */
export function Icon({ name, size = 16, strokeWidth = 1.5, className = "", title, style, ...rest }) {
  const geometry = ICON_PATHS[name];
  if (!geometry) return null;
  return (
    <svg
      className={`n-icon ${className}`.trim()}
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
      role={title ? "img" : "presentation"}
      aria-hidden={title ? undefined : true}
      style={style}
      dangerouslySetInnerHTML={{ __html: (title ? `<title>${title}</title>` : "") + geometry }}
      {...rest}
    />
  );
}
