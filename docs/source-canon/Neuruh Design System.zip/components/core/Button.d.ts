/** Neuruh action button. */
export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  /** primary = the one committing action per view. command = mono/uppercase, for armed system operations. */
  variant?: "primary" | "secondary" | "ghost" | "danger" | "command";
  size?: "sm" | "md" | "lg";
  /** Icon name from the Neuruh set, placed before the label. */
  icon?: string;
  /** Icon name placed after the label — use for "leaves this view" affordances. */
  iconAfter?: string;
  block?: boolean;
  /** Renders an anchor instead of a button. */
  href?: string;
  children?: React.ReactNode;
  className?: string;
}
export function Button(props: ButtonProps): JSX.Element;
