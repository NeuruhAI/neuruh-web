# Neuruh Design System

Neuruh is a modular AI execution platform — a "sovereign conglomerate" spanning defense
systems, real estate intelligence, enterprise automation, and creator-economy tools. The
brand communicates technical authority, operational precision, founder-led intensity, and
zero fluff.

The organizing principle of the whole system is stated in the source package as a rule:

> **Share the foundation. Never share the face.**

Shared infrastructure — authentication, permissions, data access, telemetry, testing,
deployment, accessibility primitives, basic interface components — is common. Every
product independently defines its own central metaphor, signature interaction, visual
language, motion language, vocabulary, evidence model, and performance budget.

This design system therefore ships **one spine, three expressions**:

| Layer | Purpose | Where it lives |
| --- | --- | --- |
| **Master Brand** | Tokens, type, color semantics, icon principles, evidence language, voice | `tokens/`, `css/`, `guidelines/` |
| **Flagship World** | Cinematic spatial expression for Neuruh.com and pitch frames | `ui_kits/neuruh-com/` |
| **Blackbox** | The diagnostic/operational sub-system — the terminal aesthetic, deliberately quarantined | `ui_kits/blackbox-console/` |
| **Product systems** | Inherit Master Brand semantics without copying page composition | `ui_kits/deedsonar/` (light-spine reference) |

## Sources this system was built from

Everything here derives from six process/architecture documents in `uploads/`:

- `uploads/README_START_HERE.md` — Spatial Product Studio OS v1, the core rule, ten-stage pipeline, tool routing, Neuruh.com mandate
- `uploads/ONE_SHOT_DESIGN_SYSTEM.md` — required design-system outputs and hard constraints
- `uploads/SETUP_CLAUDE_DESIGN.md` — the three-layer architecture and the eight-product roster
- `uploads/ONE_SHOT_THREE_RECIPES.md` — direction-generation protocol
- `uploads/ONE_SHOT_FRAME_AND_FLOW.md` — required prototype states
- `uploads/HANDOFF_TO_CLAUDE_CODE.md` — engineering handoff contract

Plus the saved **Neuruh brand standards** (positioning, voice, dark-for-internal /
light-for-client rule, Inter + JetBrains Mono typography) and **Neuruh pitch-deck
standards** (deck typography and data rules). The color system was re-cut at the user's
direction away from stock framework hues toward Carolina lake-country color — see
*Color* below.

### Not supplied — and therefore not invented

- **No logo or brand mark file.** The mark is set in type everywhere artwork would go —
  the `Wordmark` / `Seal` components (Archivo 800 at −0.055em, with an `N` monogram plate).
  Nothing was drawn or reconstructed. Send logo files and `components/brand/Wordmark.jsx`
  is the single place they drop in.
- **No font binaries.** See *Type substitutions* below.
- **No icon set.** See *Iconography* below.
- **No codebase, Figma file, screenshots, or live URLs.** No GitHub repo, Figma link, or
  local path was attached, so no screen was recreated from source. The UI kits are
  reconstructions from the written briefs — high-fidelity against the token system, but
  **proposals, not recreations**. Each kit's README names its own gaps.
- **No slide template.** No sample slides were created, per that rule.
- **No product copy from a live site.** Headlines follow the documented voice; treat them
  as drafts.

## Products in the roster

Eight products plus the flagship, from `SETUP_CLAUDE_DESIGN.md`: DeedSonar, Founder
Command, Cockpit/Galaxy, Adaptive Intelligence, Field Scout, LARIC, Find Sell Profit,
Lead Recipe OS. Six surfaces are built out here — Neuruh.com (flagship), Blackbox Console
(diagnostic), DeedSonar (light spine), Founder Command (operator cockpit), Galaxy
(portfolio graph), and Field Scout (mobile). Adaptive Intelligence, LARIC, Find Sell
Profit (seven-agent resale scanner, light spine). Adaptive Intelligence, LARIC, and
Lead Recipe OS inherit the Master Brand and are unbuilt — the source names them but
defines nothing about them.

---

## CONTENT FUNDAMENTALS

**The voice is a co-founder in the trenches, not a consultant giving a presentation.**

- **Tactical and execution-first.** Say the thing, then stop. "Sweep complete. 4,218
  parcels, 27 conflicts flagged." Not "We're excited to let you know your sweep has
  finished successfully!"
- **Clipped sentences with strategic cadence.** Hybrid formal-casual. Fragments are fine
  when they land: "Built to be audited, not admired."
- **Systems thinking always present.** Copy names the mechanism, not the benefit.
  "Recursive feedback loops in every automated workflow" beats "smarter automation."
- **Sentence case everywhere** except the mono system label, which is UPPERCASE with
  0.14em tracking. Never title case a heading. Never all-caps a sentence.
- **No emoji. Ever.** Not in UI, not in docs, not in decks. No unicode glyphs used as
  icons either — use the icon set.
- **No motivational fluff, no corporate filler.** Banned: "unlock", "empower",
  "seamlessly", "revolutionize", "game-changing", "leverage" as a verb, "excited to".
- **Dry humor when it lands, silence when it doesn't.** The system never jokes about
  failure states.
- **"You" for the operator, "we" only for the company's own commitments.** Never "I" —
  the system is not a persona. Machine output is stated impersonally: "2 sources
  disagree", not "I found a conflict".
- **Numbers are specific or flagged.** Real figures whenever available. If a number is
  unknown, write `PLACEHOLDER — need actual figure`, never `XX%` or a plausible invention.
- **Every consequential claim carries a source.** This is a copy rule as much as a
  component rule: a number without provenance does not ship.

Examples, all from this system:

| Context | Copy |
| --- | --- |
| Empty tax-history tab | "No tax-history layout was provided. Left intentionally blank rather than invented." |
| Critical alert | "MLS bridge unreachable. Last successful handshake 41 minutes ago. 118 targets are running on assessor data alone." |
| Dialog confirmation | "3 counties · 4,218 known parcels · 9 sources. Estimated 6 minutes. Existing conflict flags will be recomputed." |
| Flagship headline | "Share the foundation. Never share the face." |
| Confidence basis | "3 of 4 sources agree · 6h old" |

---

## VISUAL FOUNDATIONS

### Two spines, one token set

The system has a **dark spine** (`--ink-*`) and a **light spine** (`--paper-*`). Semantic
aliases (`--bg-canvas`, `--text-primary`, `--border-default`, …) resolve to the dark spine
by default; wrapping any subtree in `[data-surface="light"]` flips every alias to the light
spine. Product code references **only** the semantic aliases.

Both spines are also **explicit scopes**, so themes nest in either direction and to any
depth: `[data-surface="dark"]` re-values the aliases back to ink, letting a live telemetry
pane sit inside a light report page (see the Find Sell Profit scanner) or a printable
exhibit preview sit inside a dark console. A scope paints its own canvas — marking a
subtree is enough. Texture inversion follows the scope too.

Dark is the default because internal tools, consoles, and pitch frames are the majority
surface. **Dark mode is not mandatory** — that is an explicit hard constraint in the source
package. All-day client-facing tools (DeedSonar, proposals, portals, reports) run light.

### Color — "Lake light"

The palette is drawn from Carolina lake country: limestone and linen, weathered
cedar shade, deep water, aged brass hardware, sage and clay. Nothing in it is a
stock framework hue. Two properties make it read as considered rather than
generic — **everything is warm-biased** (the darks carry a pine-graphite
undertone, the lights are limestone not blue-white, the shadows are brown-black),
and **everything is desaturated** (no value sits at full chroma).

- **One accent, always.** Lake water `--lake-500` `#21808F` — a deep, calm
  teal-blue. Solid fills use `--lake-600`. There is no secondary brand hue.
- **Brass is emphasis, not a second brand color.** `--brass-400` `#C9A567` marks
  armed/system-level operations (`Button variant="command"`) and nothing else.
  One brass element per view, maximum.
- **Pine is a ground, not an accent.** `--pine-700` / `--pine-900` floor
  full-bleed editorial sections. Never used for text or controls.
- **Status colors are natural and muted** — never neon, never decorative, never a
  chart palette: sage = verified/corroborated, ochre = caution/stale/degraded,
  clay = critical/conflict, stone (`--ink-300`) = inert/archived. Each has a
  `-300` value tuned for dark surfaces and a `-600` for light.
- **Banned:** bluish-purple gradients, glass panels, decorative glow, ambient 3D,
  and any saturated primary. Gradients, glass, glow, and 3D require **semantic
  purpose** — the sanctioned exceptions are `--glow-live` (a system is genuinely
  streaming), `--sheen-*` (surface material, below), and the protection scrims.
- Imagery skews **warm and low-contrast** — limestone, weathered timber, water at
  dusk, deep pine shade. No cold steel filters, no film grain overlay, no duotone.
  Full-bleed and cropped hard, never floated in a rounded card.

### Type

- **Display / cinematic — Archivo 700–800, tracking −0.03em.** `--type-cinema-1/2/3`.
  Flagship and pitch frames only. Set large (≥40px) or don't use it.
- **Operational headings — Archivo for h1/h2 (28/22px), Inter 600 for h3/h4 (18/15px).**
- **Body — Inter 400.** 17px lead, 15px default, 13px small. Prose measure caps at 68ch.
- **Data — JetBrains Mono, tabular figures.** Every machine value: IDs, coordinates,
  timestamps, hashes, currency, percentages, counts. Never prose, never a headline.
- **System label — 11px mono, uppercase, 0.14em tracking** (`.n-label`). The single
  strongest brand signature. Used wherever a machine is speaking: field labels, section
  eyebrows, telemetry keys, table headers.

### Spacing, density, layout

4px-based scale (`--space-1` = 2px through `--space-14` = 160px); operational surfaces
live in the 4–16px range. Fixed rails: sidebar 248px (collapses to 56px), inspector 340px,
bars 48px, page max 1360px. Row heights 32 / 40 / 52px — tables default to tight. The
top bar and rails are `position: fixed` in product shells; the flagship nav is fixed and
solidifies past 80px of scroll. Content density over decoration.

### Borders, radii, cards, elevation

- **Radii are near-square.** 0 / 2 / 4 / 6 / 8 / 12px and pill. Buttons and inputs 4px,
  cards 6px, dialogs 8px, badges 2px. Pill is reserved for removable `Tag` chips and
  switch tracks — the one place full rounding is legible as "removable". Nothing above
  12px otherwise; radius signals softness and this brand does not want softness.
- **Surfaces are machined plates, not flat rectangles.** Every panel, raised button,
  tag, toast, and dialog carries `--sheen-panel` — a 2–3% luminance gradient falling
  from the top edge. It is material (a top-lit plate), not decoration, and it is the
  single biggest contributor to the system feeling polished rather than drawn.
- **Shadows are warm and layered.** A tight contact shadow plus a wide ambient one, both
  in brown-black (`rgba(32,26,18,…)`) rather than blue-black. Dark surfaces get
  `--shadow-dark-1` **plus** a 1px top light (`--edge-inset`); light surfaces get
  `--shadow-1`/`-2`/`-3`. Popovers and dialogs get `--shadow-modal`.
- No colored left-border accent cards. `variant="accent"` uses a lake border plus a
  1px inner lake ring — depth, not a stripe.

### Motion

**Mechanical, not playful. No bounce, no overshoot, no spring.** Things throw like a
switch. 80 / 120 / 180 / 320ms with `--ease-standard` for state changes and `--ease-out`
for entrances. `--dur-cinematic` (900ms, `--ease-cinematic`) is flagship-only — scroll
reveals and scene transitions. Every duration collapses to 0 under
`prefers-reduced-motion`; the flagship reveal is fully disabled, not merely shortened.

### Materials — the texture layer

Neuruh surfaces are physical: limestone, weathered plate, brushed brass, survey paper.
`tokens/materials.css` ships seven generated tileable overlays in `assets/textures/`, all
white-on-transparent so one file serves both spines. They are applied as pseudo-element
overlays (`.n-tex .n-tex--grain`) so the host keeps its own background, sheen, and border.

| Texture | Strength | Carries |
| --- | --- | --- |
| `grain` | 4.5% | Material only. The default on large dark grounds. |
| `paper` (fiber) | 7% | Material only. The light spine — reports, proposals. |
| `grid` (parcel) | 5% | **Meaning:** spatial / cadastral context. |
| `contour` | 5.5% | **Meaning:** terrain and elevation. |
| `brushed` | 10% | **Meaning:** brass emphasis — the monogram plate, seals. |
| `dots` | 9% | Editorial fills and chart hatching. |
| `hatch` | 16% | **Meaning:** no data, redacted, out of coverage. Tinted by status. |

Rules: **one texture per surface** (grain over contour over grid is mud); never above 8%
on a reading surface — body text sits on flat color; and a texture that carries meaning
may not be used decoratively. Grain and paper are the only two that are pure material.

### Interaction states

- **Hover:** surface brightens one step (`--bg-surface-hover`) and the border moves toward
  accent. Never opacity, never a scale-up.
- **Press:** 1px downward translate plus the next surface step. Never a scale-down.
- **Focus:** 2px lake ring with a 2px canvas-colored gap (`--ring-focus`) — a hard ring,
  never a soft glow. Always visible, never removed.
- **Disabled:** 0.38 opacity, `not-allowed` cursor, no hue change.
- **Selected row / active nav:** lake wash background plus a 2px lake bar on the
  leading edge — not a filled pill.

### Transparency and blur

Used in exactly two places: the flagship nav past scroll (`blur(14px) saturate(140%)` over
82% ink) and modal scrims. Never on cards, never on panels, never as a decorative frost
layer. Text over imagery uses a **bottom-up protection scrim**
(`--scrim-protection`) — never a translucent capsule or a blur pill behind the text.

---

## SPATIAL & MOTION LAYER

Neuruh is a *spatial* product studio; 3D, graph, map, and audio surfaces are first-class,
not garnish. The full routing table lives in **`guidelines/spatial-stack.md`** — libraries
by problem, per-surface performance budgets, the asset pipeline gate, shader discipline,
and the sound rules. The short version:

- **Primary runtime:** Three.js + React Three Fiber, with Drei, gltfjsx, postprocessing,
  Rapier, XR, and three-mesh-BVH. Babylon/PlayCanvas/PixiJS/OGL are alternates with
  named triggers, not preferences.
- **Nothing mounts unwrapped.** Every canvas — R3F, deck.gl, MapLibre, Cesium, Sigma,
  Spline — goes inside `SceneFrame`. It resolves a capability tier
  (`webgpu → webgl → reduced → static`), honours `prefers-reduced-motion` and Save-Data,
  and renders a poster instead of a blank box. WebGPU is **detected, never assumed**.
- **Scene color comes from tokens.** `tokens/spatial.css` supplies grounds, warm pine fog,
  a neutral-warm key / lake fill / brass rim lighting triad, an ordered six-step data ramp,
  and map surface tints. A scene that invents its own palette is off-brand regardless of
  how good it looks.
- **Motion rules hold in 3D.** No bounce, no overshoot, no spring — a camera move that
  oscillates is off-brand. Authored sequences use `--scene-dur-*` and `--scene-ease-camera`;
  CSS remains the default for everything a library isn't required for.
- **One signature effect per surface, two post-processing passes maximum.** The technique
  library is long on purpose; enabling it all at once is the failure mode. Effects must be
  semantic — depth-aware outlines to isolate a selected parcel, yes; bloom because it looks
  expensive, no.
- **Generative 3D is for greyboxing.** Hunyuan3D 2.1, TRELLIS, Stable Fast 3D and
  image-to-3D reconstruction are evaluation-stage; nothing generative ships as final
  geometry without a modeller pass. Everything ships as compressed glTF through
  glTF-Transform + meshoptimizer.
- **Audio is muted by default and user-initiated** via `SoundToggle`. The silent route is
  first-class: no information may live in audio alone. Reduced motion implies reduced sound.
- **Blackbox has a zero-canvas budget.** The operational console is DOM. Spatial expression
  belongs to the Flagship World and to Galaxy/Cockpit, DeedSonar's map, and Field Scout —
  it is not the universal Neuruh language.

No spatial dependency is installed in this project. The doc records repository paths so a
consuming project can pull the right one deliberately.

---

## ICONOGRAPHY

**Substitution flagged:** the source package specified icon *principles* but shipped no
icon set, font, or sprite. **Lucide** was chosen and copied in — its 24px grid, 1.5px
stroke, and round caps match the brand's sharp instrument-panel language without the
softness of a filled or rounded set. 48 glyphs live in `assets/icons/` as individual SVGs,
with geometry extracted to `assets/icons/icon-paths.js` for the `Icon` component.

- **Line only, 1.5px, 24px viewBox.** No filled icons, no duotone, no two-color glyphs.
- **Always via `<Icon name="…" />`** so glyphs inherit `currentColor`. Never inline SVG in
  a screen, never a raster icon.
- **Sizes:** 14px inline with text, 16px in UI controls, 18–20px standalone or in a
  bordered tile.
- **Icons never carry meaning alone** in a status context — pair with a `Badge` or label.
- **No emoji, ever.** No unicode dingbats as icons. The only non-icon glyph in the system
  is the `/` breadcrumb separator and the `→` in conveyance rows, both typographic.
- Coverage: navigation (`panel-left`, `menu`, `chevron-*`, `arrow-*`), status
  (`circle-check`, `triangle-alert`, `circle-alert`), data/system (`database`, `cpu`,
  `terminal`, `git-branch`, `hash`, `layers`, `gauge`, `signal`, `activity`), geo
  (`map-pin`, `globe`, `crosshair`, `radar`, `scan-line`), trust (`shield`, `lock`, `eye`,
  `link-2`, `file-text`), actions (`plus`, `search`, `funnel`, `download`, `copy`,
  `refresh-cw`, `external-link`, `play`, `pause`, `settings`, `bell`, `x`, `check`, `zap`).

If a needed glyph is missing, add the Lucide SVG to `assets/icons/` and regenerate
`icon-paths.js` — do not hand-draw one.

## Type substitutions

**Flagged:** no font binaries were supplied. Brand standards name Inter / SF Pro /
JetBrains Mono; SF Pro is not redistributable.

- **Inter** — used as named. SIL variable TTF at `assets/fonts/Inter-Variable.ttf`.
- **JetBrains Mono** — used as named. `assets/fonts/JetBrainsMono-Variable.ttf`.
- **Archivo** — *substituted* for SF Pro Display as the cinematic display face. A tight,
  high-contrast grotesque that holds at 120px with −0.03em tracking, where Inter goes soft.
  `assets/fonts/Archivo-Variable.ttf`.

**Ask:** if Neuruh has licensed a proprietary display face — or wants SF Pro on
Apple-platform surfaces — send the files and `tokens/fonts.css` is a three-line change.

---

## Index

### Root

| File | What it is |
| --- | --- |
| `styles.css` | The single entry point consumers link. `@import` list only. |
| `readme.md` | This document. |
| `SKILL.md` | Agent Skills front matter, for use in Claude Code. |
| `thumbnail.html` | Homepage tile. |

### `tokens/` — CSS custom properties

`fonts.css` (@font-face + family tokens) · `colors.css` (ink / paper / lake / brass /
pine / status palette) · `typography.css` (type compounds + tracking) · `spacing.css` (scale, rails,
row heights) · `radius.css` · `elevation.css` (warm layered shadows, surface sheens, edges,
focus rings, scrims) ·
`motion.css` (durations, easings, reduced-motion) · `semantic.css` (**the aliases product
code uses**, plus the `[data-surface="light"]` scope) · `spatial.css` (scene grounds,
atmosphere, lighting anchors, data ramp, map surfaces, scene choreography, `.n-scene`) ·
`materials.css` (the texture layer — see *Materials* below) ·
`print.css` (page geometry, point-based document type ladder, print ink, slide geometry,
`.n-doc`) ·
`base.css` (resets, link colors, `.n-label`, `.n-rule`, `.n-numeric`).

### `css/` — component stylesheets

`core.css` · `forms.css` · `feedback.css` · `navigation.css` · `evidence.css`

### `components/` — 34 React primitives

- **`core/`** — `Icon`, `Button`, `IconButton`, `Card`, `Badge`, `Tag`
- **`brand/`** — `Wordmark`, `Seal`
- **`forms/`** — `Field`, `Input`, `Select`, `Checkbox`, `Radio`, `Switch`
- **`data/`** — `DataTable`, `KeyValue`, `Sparkline`, `EmptyState`
- **`feedback/`** — `StatusDot`, `Progress`, `Toast`, `Dialog`, `Tooltip`
- **`navigation/`** — `Tabs`, `NavItem`, `Breadcrumbs`, `TopBar`
- **`evidence/`** — `EvidenceChip`, `ProvenanceTrail`, `ConfidenceMeter`, `Stat`
- **`spatial/`** — `SceneFrame` (+ `SceneFrame.detectTier()`), `SoundToggle`

Each has a sibling `.d.ts` props contract and `.prompt.md` usage note; each directory has
one `@dsCard` HTML state sheet.

**Intentional additions.** No source defined a component inventory, so the standard set
was authored. Two groups are deliberate departures from a generic set:

- **`evidence/`** (`EvidenceChip`, `ProvenanceTrail`, `ConfidenceMeter`, `Stat`) — the
  source package requires `EVIDENCE_AND_TRUST_COMPONENTS.md` and names evidence,
  authority, and lineage as brand-level trust properties. These make that enforceable in
  code rather than aspirational in a doc.
- **`Button variant="command"`** — mono, uppercase, brass-bordered. The Blackbox brief demands a
  visually distinct affordance for armed/system-level operations that is not "red danger".
- **`spatial/`** (`SceneFrame`, `SoundToggle`) — the source package specifies a large spatial
  runtime (Three.js/R3F, deck.gl, MapLibre, Cesium, Sigma, Spline) plus hard constraints:
  capability detection over assumption, a complete reduced-sensory route, and
  muted-by-default audio. `SceneFrame` makes those structural rather than advisory — no
  canvas mounts unguarded. See `guidelines/spatial-stack.md`.
- **`data/`** (`DataTable`, `KeyValue`, `Sparkline`, `EmptyState`) — every Neuruh product is
  fundamentally a table with context around it; all three UI kits were hand-rolling
  `<table>` markup, which is exactly how column alignment drifts between screens.
  `DataTable` declares formatting on the column so numeric columns get mono tabular
  treatment automatically. `EmptyState` also gives the brand's honest-gaps rule a
  component instead of an ad-hoc paragraph.
- **`brand/`** (`Wordmark`, `Seal`) — with no logo file, the mark is typographic. Routing it
  through a component means there is exactly **one** place to change when real artwork
  arrives, instead of a search for the literal string "Neuruh".

Omitted on purpose: Avatar, Accordion, Menu, DatePicker, Skeleton — no
source defines them, and inventing them would give consumers components designers won't
recognize.

### What this system still needs

Ranked by impact, split by what only you can supply.

**Blocked on you**

1. **The real source.** A GitHub URL for Neuruh.com, the Blackbox console, or DeedSonar
   turns six educated reconstructions into recreations. By far the biggest gap.
2. **Logo artwork.** Everything routes through `Wordmark`, so it is a one-file change.
3. **Licensed display font**, if Archivo is not the final call.
4. **A map tile provider and parcel geometry source** — the DeedSonar and Field Scout map
   panes are `EmptyState`s until then; `--map-*` styling targets are already written.
5. **Photography or spatial stills.** The flagship hero and editorial slots are
   placeholders. The texture layer sets the vocabulary imagery should match: warm,
   low-chroma, limestone and deep pine.
6. **Real numbers.** Every figure in the templates and kits is a placeholder or drawn from
   the source docs. Placeholders are labelled `PLACEHOLDER` on purpose — do not ship them.

7. **A one-paragraph definition of Adaptive Intelligence, LARIC, and Lead Recipe OS.**
   Find Sell Profit is now built because its behaviour was documented (a seven-agent
   resale scanner). The other three are names in a roster — who uses them, what the
   primary object on screen is, and what decision the screen exists to serve. Without
   that, a kit would be invention wearing the brand.

**Buildable now**

8. **Postprocessing pass on the spatial layer.** Bloom and depth-aware outlines are
   sanctioned and would suit the Galaxy node halos; held back for the bundle budget.
9. **Motion choreography.** `--scene-*` timing tokens exist; no authored sequence uses
   them yet.
10. **More templates** — an email, a proposal/SOW, a case study, and a deck theme variant
    for client (light spine) rather than investor use.

### `css/` — component stylesheets

`core.css` · `forms.css` · `data.css` · `feedback.css` · `navigation.css` · `evidence.css` · `brand.css`

### `guidelines/` — 27 foundation specimen cards + the spatial routing doc

Colors (ink, paper, lake, brass &amp; pine, status, dark roles, light roles) · Type (cinematic, headings,
body, mono, system label) · Spacing (scale, rails, density) · Brand (radii, elevation,
motion, focus states, wordmark, iconography, protection scrim) · Spatial (scene atmosphere,
scene lighting, data ramp, map surfaces, scene choreography, capability routes).

**`guidelines/spatial-stack.md`** — the spatial routing table: which library owns which
problem, per-surface performance budgets, the asset pipeline gate, shader discipline, and
the sound rules. Read it before opening a canvas.

### `ui_kits/`

| Kit | Surface | Spine |
| --- | --- | --- |
| `neuruh-com/` | Flagship home — cinematic hero, evidence band, nine-product index, editorial, footer | Dark |
| `blackbox-console/` | Diagnostic console — sweep board, event stream, provenance inspector | Dark |
| `deedsonar/` | Title & parcel intelligence — explorer, results, title chain | **Light** |
| `founder-command/` | Operator cockpit — decision queue, deployment stream, budgets, ⌘K palette | Dark |
| `galaxy/` | Portfolio graph — 2D and **3D** lenses, ontology recolor, cluster collapse, isolation, timeline replay | Dark |
| `field-scout/` | **Mobile** capture — 44px targets, offline-first queue, signed field evidence | Dark |
| `find-sell-profit/` | Resale intelligence — seven-agent scanner, held inventory | **Light**, with a nested dark telemetry island |

Each has its own `README.md` listing screens, wired interactions, and known gaps.

### `templates/`

Starting folders a consuming project copies. Each has a `ds-base.js` with one `base` line
to repoint, and each entry is a Design Component.

| Template | Entry | Notes |
| --- | --- | --- |
| Pitch deck | `pitch-deck/PitchDeck.dc.html` | 7 slides at 1920×1080 — cover, section, evidence, comparison, quote, roster, ask. Exports to PDF and PPTX as-is. |
| Title opinion report | `title-report/TitleReport.dc.html` | Flowing printable document — running header/footer, chain-of-conveyance and provenance tables. Paginates onto the reader's own paper. |
| Console screen | `console-screen/ConsoleScreen.dc.html` | Empty operator shell — chrome, nav rail, toolbar, work area, inspector. The begin-here for any product surface. |
| Marketing page | `marketing-page/MarketingPage.dc.html` | Flagship page rhythm — sticky nav, hero with image slot, evidence band, three capabilities, pine editorial close. |
| Report document | `report-document/ReportDocument.dc.html` | Empty client-facing report — brass masthead, matter block, findings, evidence and provenance tables. |
| Capability one-pager | `one-pager/OnePager.dc.html` | Single explicitly-paginated sheet — brass masthead, evidence tiles, capability grid, one ask. |

### `assets/`

`fonts/` — three variable TTFs · `icons/` — 50 Lucide SVGs plus `icon-paths.js` ·
`textures/` — seven generated tileable overlays (grain, paper fiber, parcel grid, contour,
brushed, dot lattice, hatch).
**No logo files** — the mark is typographic, via the `Wordmark` component.
