/* @ds-bundle: {"format":4,"namespace":"NeuruhDesignSystem_5cb7e4","components":[{"name":"ICON_NAMES","sourcePath":"assets/icons/icon-paths.js"},{"name":"ICON_PATHS","sourcePath":"assets/icons/icon-paths.js"},{"name":"Wordmark","sourcePath":"components/brand/Wordmark.jsx"},{"name":"Seal","sourcePath":"components/brand/Wordmark.jsx"},{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"Icon","sourcePath":"components/core/Icon.jsx"},{"name":"IconButton","sourcePath":"components/core/IconButton.jsx"},{"name":"Tag","sourcePath":"components/core/Tag.jsx"},{"name":"DataTable","sourcePath":"components/data/DataTable.jsx"},{"name":"EmptyState","sourcePath":"components/data/EmptyState.jsx"},{"name":"KeyValue","sourcePath":"components/data/KeyValue.jsx"},{"name":"Sparkline","sourcePath":"components/data/Sparkline.jsx"},{"name":"ConfidenceMeter","sourcePath":"components/evidence/ConfidenceMeter.jsx"},{"name":"EvidenceChip","sourcePath":"components/evidence/EvidenceChip.jsx"},{"name":"ProvenanceTrail","sourcePath":"components/evidence/ProvenanceTrail.jsx"},{"name":"Stat","sourcePath":"components/evidence/Stat.jsx"},{"name":"Dialog","sourcePath":"components/feedback/Dialog.jsx"},{"name":"Progress","sourcePath":"components/feedback/Progress.jsx"},{"name":"StatusDot","sourcePath":"components/feedback/StatusDot.jsx"},{"name":"Toast","sourcePath":"components/feedback/Toast.jsx"},{"name":"Tooltip","sourcePath":"components/feedback/Tooltip.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Field","sourcePath":"components/forms/Field.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Radio","sourcePath":"components/forms/Radio.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Switch","sourcePath":"components/forms/Switch.jsx"},{"name":"Breadcrumbs","sourcePath":"components/navigation/Breadcrumbs.jsx"},{"name":"NavItem","sourcePath":"components/navigation/NavItem.jsx"},{"name":"Tabs","sourcePath":"components/navigation/Tabs.jsx"},{"name":"TopBar","sourcePath":"components/navigation/TopBar.jsx"},{"name":"SceneFrame","sourcePath":"components/spatial/SceneFrame.jsx"},{"name":"SoundToggle","sourcePath":"components/spatial/SoundToggle.jsx"}],"sourceHashes":{"assets/icons/icon-paths.js":"bab9d671e294","components/brand/Wordmark.jsx":"e035dd08a012","components/core/Badge.jsx":"75313f5824e4","components/core/Button.jsx":"cc4e4a49c6dd","components/core/Card.jsx":"1bf239f92015","components/core/Icon.jsx":"0f92662f1708","components/core/IconButton.jsx":"9334b0548ba5","components/core/Tag.jsx":"d0dbba78096a","components/data/DataTable.jsx":"8db5f7b3ee6d","components/data/EmptyState.jsx":"a9e8a22d4c55","components/data/KeyValue.jsx":"bf20918b376a","components/data/Sparkline.jsx":"cf6af6a184e1","components/evidence/ConfidenceMeter.jsx":"c271b7b9bd9e","components/evidence/EvidenceChip.jsx":"29ba9479e0b9","components/evidence/ProvenanceTrail.jsx":"a5fcffa7940b","components/evidence/Stat.jsx":"d90645b70fc3","components/feedback/Dialog.jsx":"e94773e48b0a","components/feedback/Progress.jsx":"bdf910036e27","components/feedback/StatusDot.jsx":"28532dd873aa","components/feedback/Toast.jsx":"f76589410e58","components/feedback/Tooltip.jsx":"af4c3de3ca9a","components/forms/Checkbox.jsx":"986d119a9d85","components/forms/Field.jsx":"0c1465802ce0","components/forms/Input.jsx":"98c820b9c04b","components/forms/Radio.jsx":"0ee05dec58ea","components/forms/Select.jsx":"0fa47a11b8ee","components/forms/Switch.jsx":"7dcb1f3869e1","components/navigation/Breadcrumbs.jsx":"6f12dd21bd67","components/navigation/NavItem.jsx":"2c48f7d125fc","components/navigation/Tabs.jsx":"61dffc784178","components/navigation/TopBar.jsx":"c53a2addf38f","components/spatial/SceneFrame.jsx":"a7a015457d3f","components/spatial/SoundToggle.jsx":"4247fb11f016","guidelines/doc-page.js":"371bab66f42d","ui_kits/blackbox-console/ConsoleShell.jsx":"d3c17b9bd45b","ui_kits/blackbox-console/DiagnosticStream.jsx":"78eaa276f6ed","ui_kits/blackbox-console/InspectorPanel.jsx":"c534dccf6d3e","ui_kits/blackbox-console/SweepBoard.jsx":"84b8b3d8ec89","ui_kits/deedsonar/DeedSonarShell.jsx":"d2a053b55617","ui_kits/deedsonar/ParcelExplorer.jsx":"396ff0f70385","ui_kits/deedsonar/TitleChain.jsx":"ccc926f2276b","ui_kits/field-scout/CaptureSheet.jsx":"9fa5039b7182","ui_kits/field-scout/ScoutShell.jsx":"66ac6ea5cc52","ui_kits/field-scout/SweepList.jsx":"45d27de891c2","ui_kits/find-sell-profit/FSPShell.jsx":"338fed386988","ui_kits/find-sell-profit/OpportunityBoard.jsx":"1c6a2044e111","ui_kits/find-sell-profit/ScanPipeline.jsx":"dc9a4a5ea0a0","ui_kits/founder-command/CommandBoard.jsx":"fbb69b48872f","ui_kits/founder-command/CommandShell.jsx":"4eb4223e526b","ui_kits/founder-command/DecisionDrawer.jsx":"5367e5e06b9e","ui_kits/galaxy/GalaxyGraph.jsx":"7d4a91667ff1","ui_kits/galaxy/GalaxyScene3D.jsx":"6636db490a84","ui_kits/galaxy/GalaxyShell.jsx":"18b6e632b69d","ui_kits/galaxy/NodeInspector.jsx":"b509449ce5f0","ui_kits/neuruh-com/CapabilityIndex.jsx":"06768d53c38f","ui_kits/neuruh-com/EditorialSection.jsx":"ce0b51b0d278","ui_kits/neuruh-com/EvidenceBand.jsx":"05ff9d0d4f65","ui_kits/neuruh-com/FlagshipHero.jsx":"85d70ec4151f","ui_kits/neuruh-com/FlagshipNav.jsx":"189b78609833","ui_kits/neuruh-com/image-slot.js":"fff26d081c8d"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.NeuruhDesignSystem_5cb7e4 = window.NeuruhDesignSystem_5cb7e4 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// assets/icons/icon-paths.js
try { (() => {
/* Lucide 0.x icon geometry, extracted from assets/icons/*.svg.
   SUBSTITUTION: the Neuruh source package defined no icon set; Lucide was
   chosen for its 1.5px/24px stroke geometry and square-ish terminals, which
   match the brand's sharp, instrument-panel language. See readme.md.
   Regenerate this file if icons are added to assets/icons/. */
const ICON_NAMES = ["activity", "arrow-right", "arrow-up-right", "bell", "building-2", "check", "chevron-down", "chevron-right", "circle-alert", "circle-check", "clock", "copy", "cpu", "crosshair", "database", "download", "external-link", "eye", "file-text", "funnel", "gauge", "git-branch", "globe", "hash", "layers", "link-2", "lock", "map-pin", "menu", "panel-left", "pause", "play", "plus", "radar", "radio", "refresh-cw", "scan-line", "search", "settings", "shield", "signal", "square-terminal", "terminal", "trending-up", "triangle-alert", "users", "volume-2", "volume-x", "x", "zap"];
const ICON_PATHS = {
  "activity": "<path d=\"M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2\"></path>",
  "arrow-right": "<path d=\"M5 12h14\"></path> <path d=\"m12 5 7 7-7 7\"></path>",
  "arrow-up-right": "<path d=\"M7 7h10v10\"></path> <path d=\"M7 17 17 7\"></path>",
  "bell": "<path d=\"M10.268 21a2 2 0 0 0 3.464 0\"></path> <path d=\"M3.262 15.326A1 1 0 0 0 4 17h16a1 1 0 0 0 .74-1.673C19.41 13.956 18 12.499 18 8A6 6 0 0 0 6 8c0 4.499-1.411 5.956-2.738 7.326\"></path>",
  "building-2": "<path d=\"M10 12h4\"></path> <path d=\"M10 8h4\"></path> <path d=\"M14 21v-3a2 2 0 0 0-4 0v3\"></path> <path d=\"M6 10H4a2 2 0 0 0-2 2v7a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-2\"></path> <path d=\"M6 21V5a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v16\"></path>",
  "check": "<path d=\"M20 6 9 17l-5-5\"></path>",
  "chevron-down": "<path d=\"m6 9 6 6 6-6\"></path>",
  "chevron-right": "<path d=\"m9 18 6-6-6-6\"></path>",
  "circle-alert": "<circle cx=\"12\" cy=\"12\" r=\"10\"></circle> <line x1=\"12\" x2=\"12\" y1=\"8\" y2=\"12\"></line> <line x1=\"12\" x2=\"12.01\" y1=\"16\" y2=\"16\"></line>",
  "circle-check": "<circle cx=\"12\" cy=\"12\" r=\"10\"></circle> <path d=\"m9 12 2 2 4-4\"></path>",
  "clock": "<circle cx=\"12\" cy=\"12\" r=\"10\"></circle> <path d=\"M12 6v6l4 2\"></path>",
  "copy": "<rect width=\"14\" height=\"14\" x=\"8\" y=\"8\" rx=\"2\" ry=\"2\"></rect> <path d=\"M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2\"></path>",
  "cpu": "<path d=\"M12 20v2\"></path> <path d=\"M12 2v2\"></path> <path d=\"M17 20v2\"></path> <path d=\"M17 2v2\"></path> <path d=\"M2 12h2\"></path> <path d=\"M2 17h2\"></path> <path d=\"M2 7h2\"></path> <path d=\"M20 12h2\"></path> <path d=\"M20 17h2\"></path> <path d=\"M20 7h2\"></path> <path d=\"M7 20v2\"></path> <path d=\"M7 2v2\"></path> <rect x=\"4\" y=\"4\" width=\"16\" height=\"16\" rx=\"2\"></rect> <rect x=\"8\" y=\"8\" width=\"8\" height=\"8\" rx=\"1\"></rect>",
  "crosshair": "<circle cx=\"12\" cy=\"12\" r=\"10\"></circle> <line x1=\"22\" x2=\"18\" y1=\"12\" y2=\"12\"></line> <line x1=\"6\" x2=\"2\" y1=\"12\" y2=\"12\"></line> <line x1=\"12\" x2=\"12\" y1=\"6\" y2=\"2\"></line> <line x1=\"12\" x2=\"12\" y1=\"22\" y2=\"18\"></line>",
  "database": "<ellipse cx=\"12\" cy=\"5\" rx=\"9\" ry=\"3\"></ellipse> <path d=\"M3 5V19A9 3 0 0 0 21 19V5\"></path> <path d=\"M3 12A9 3 0 0 0 21 12\"></path>",
  "download": "<path d=\"M12 15V3\"></path> <path d=\"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4\"></path> <path d=\"m7 10 5 5 5-5\"></path>",
  "external-link": "<path d=\"M15 3h6v6\"></path> <path d=\"M10 14 21 3\"></path> <path d=\"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6\"></path>",
  "eye": "<path d=\"M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0\"></path> <circle cx=\"12\" cy=\"12\" r=\"3\"></circle>",
  "file-text": "<path d=\"M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z\"></path> <path d=\"M14 2v5a1 1 0 0 0 1 1h5\"></path> <path d=\"M10 9H8\"></path> <path d=\"M16 13H8\"></path> <path d=\"M16 17H8\"></path>",
  "funnel": "<path d=\"M10 20a1 1 0 0 0 .553.895l2 1A1 1 0 0 0 14 21v-7a2 2 0 0 1 .517-1.341L21.74 4.67A1 1 0 0 0 21 3H3a1 1 0 0 0-.742 1.67l7.225 7.989A2 2 0 0 1 10 14z\"></path>",
  "gauge": "<path d=\"m12 14 4-4\"></path> <path d=\"M3.34 19a10 10 0 1 1 17.32 0\"></path>",
  "git-branch": "<path d=\"M15 6a9 9 0 0 0-9 9V3\"></path> <circle cx=\"18\" cy=\"6\" r=\"3\"></circle> <circle cx=\"6\" cy=\"18\" r=\"3\"></circle>",
  "globe": "<circle cx=\"12\" cy=\"12\" r=\"10\"></circle> <path d=\"M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20\"></path> <path d=\"M2 12h20\"></path>",
  "hash": "<line x1=\"4\" x2=\"20\" y1=\"9\" y2=\"9\"></line> <line x1=\"4\" x2=\"20\" y1=\"15\" y2=\"15\"></line> <line x1=\"10\" x2=\"8\" y1=\"3\" y2=\"21\"></line> <line x1=\"16\" x2=\"14\" y1=\"3\" y2=\"21\"></line>",
  "layers": "<path d=\"M12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83z\"></path> <path d=\"M2 12a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 12\"></path> <path d=\"M2 17a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 17\"></path>",
  "link-2": "<path d=\"M9 17H7A5 5 0 0 1 7 7h2\"></path> <path d=\"M15 7h2a5 5 0 1 1 0 10h-2\"></path> <line x1=\"8\" x2=\"16\" y1=\"12\" y2=\"12\"></line>",
  "lock": "<rect width=\"18\" height=\"11\" x=\"3\" y=\"11\" rx=\"2\" ry=\"2\"></rect> <path d=\"M7 11V7a5 5 0 0 1 10 0v4\"></path>",
  "map-pin": "<path d=\"M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0\"></path> <circle cx=\"12\" cy=\"10\" r=\"3\"></circle>",
  "menu": "<path d=\"M4 5h16\"></path> <path d=\"M4 12h16\"></path> <path d=\"M4 19h16\"></path>",
  "panel-left": "<rect width=\"18\" height=\"18\" x=\"3\" y=\"3\" rx=\"2\"></rect> <path d=\"M9 3v18\"></path>",
  "pause": "<rect x=\"14\" y=\"3\" width=\"5\" height=\"18\" rx=\"1\"></rect> <rect x=\"5\" y=\"3\" width=\"5\" height=\"18\" rx=\"1\"></rect>",
  "play": "<path d=\"M5 5a2 2 0 0 1 3.008-1.728l11.997 6.998a2 2 0 0 1 .003 3.458l-12 7A2 2 0 0 1 5 19z\"></path>",
  "plus": "<path d=\"M5 12h14\"></path> <path d=\"M12 5v14\"></path>",
  "radar": "<path d=\"M19.07 4.93A10 10 0 0 0 6.99 3.34\"></path> <path d=\"M4 6h.01\"></path> <path d=\"M2.29 9.62A10 10 0 1 0 21.31 8.35\"></path> <path d=\"M16.24 7.76A6 6 0 1 0 8.23 16.67\"></path> <path d=\"M12 18h.01\"></path> <path d=\"M17.99 11.66A6 6 0 0 1 15.77 16.67\"></path> <circle cx=\"12\" cy=\"12\" r=\"2\"></circle> <path d=\"m13.41 10.59 5.66-5.66\"></path>",
  "radio": "<path d=\"M16.247 7.761a6 6 0 0 1 0 8.478\"></path> <path d=\"M19.075 4.933a10 10 0 0 1 0 14.134\"></path> <path d=\"M4.925 19.067a10 10 0 0 1 0-14.134\"></path> <path d=\"M7.753 16.239a6 6 0 0 1 0-8.478\"></path> <circle cx=\"12\" cy=\"12\" r=\"2\"></circle>",
  "refresh-cw": "<path d=\"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8\"></path> <path d=\"M21 3v5h-5\"></path> <path d=\"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16\"></path> <path d=\"M8 16H3v5\"></path>",
  "scan-line": "<path d=\"M3 7V5a2 2 0 0 1 2-2h2\"></path> <path d=\"M17 3h2a2 2 0 0 1 2 2v2\"></path> <path d=\"M21 17v2a2 2 0 0 1-2 2h-2\"></path> <path d=\"M7 21H5a2 2 0 0 1-2-2v-2\"></path> <path d=\"M7 12h10\"></path>",
  "search": "<path d=\"m21 21-4.34-4.34\"></path> <circle cx=\"11\" cy=\"11\" r=\"8\"></circle>",
  "settings": "<path d=\"M9.671 4.136a2.34 2.34 0 0 1 4.659 0 2.34 2.34 0 0 0 3.319 1.915 2.34 2.34 0 0 1 2.33 4.033 2.34 2.34 0 0 0 0 3.831 2.34 2.34 0 0 1-2.33 4.033 2.34 2.34 0 0 0-3.319 1.915 2.34 2.34 0 0 1-4.659 0 2.34 2.34 0 0 0-3.32-1.915 2.34 2.34 0 0 1-2.33-4.033 2.34 2.34 0 0 0 0-3.831A2.34 2.34 0 0 1 6.35 6.051a2.34 2.34 0 0 0 3.319-1.915\"></path> <circle cx=\"12\" cy=\"12\" r=\"3\"></circle>",
  "shield": "<path d=\"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z\"></path>",
  "signal": "<path d=\"M2 20h.01\"></path> <path d=\"M7 20v-4\"></path> <path d=\"M12 20v-8\"></path> <path d=\"M17 20V8\"></path> <path d=\"M22 4v16\"></path>",
  "square-terminal": "<path d=\"m7 11 2-2-2-2\"></path> <path d=\"M11 13h4\"></path> <rect width=\"18\" height=\"18\" x=\"3\" y=\"3\" rx=\"2\" ry=\"2\"></rect>",
  "terminal": "<path d=\"M12 19h8\"></path> <path d=\"m4 17 6-6-6-6\"></path>",
  "trending-up": "<path d=\"M16 7h6v6\"></path> <path d=\"m22 7-8.5 8.5-5-5L2 17\"></path>",
  "triangle-alert": "<path d=\"m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3\"></path> <path d=\"M12 9v4\"></path> <path d=\"M12 17h.01\"></path>",
  "users": "<path d=\"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2\"></path> <path d=\"M16 3.128a4 4 0 0 1 0 7.744\"></path> <path d=\"M22 21v-2a4 4 0 0 0-3-3.87\"></path> <circle cx=\"9\" cy=\"7\" r=\"4\"></circle>",
  "volume-2": "<path d=\"M11 4.702a.705.705 0 0 0-1.203-.498L6.413 7.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298z\"></path> <path d=\"M16 9a5 5 0 0 1 0 6\"></path> <path d=\"M19.364 18.364a9 9 0 0 0 0-12.728\"></path>",
  "volume-x": "<path d=\"M11 4.702a.705.705 0 0 0-1.203-.498L6.413 7.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298z\"></path> <line x1=\"22\" x2=\"16\" y1=\"9\" y2=\"15\"></line> <line x1=\"16\" x2=\"22\" y1=\"9\" y2=\"15\"></line>",
  "x": "<path d=\"M18 6 6 18\"></path> <path d=\"m6 6 12 12\"></path>",
  "zap": "<path d=\"M15.914 4a1.5 1.5 0 00-2.474-1.561l-9 9A1.5 1.5 0 005.5 14h4.002a.5.5 0 01.471.666L8.086 20a1.5 1.5 0 002.475 1.56l9-9A1.5 1.5 0 0018.5 10h-3.997a.5.5 0 01-.472-.667z\"></path>"
};
if (typeof window !== "undefined") {
  window.NeuruhIconPaths = ICON_PATHS;
}
Object.assign(__ds_scope, { ICON_NAMES, ICON_PATHS });
})(); } catch (e) { __ds_ns.__errors.push({ path: "assets/icons/icon-paths.js", error: String((e && e.message) || e) }); }

// components/brand/Wordmark.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const WORD = {
  sm: 15,
  md: 21,
  lg: 34,
  xl: 56,
  display: 112
};
const GLYPH = {
  sm: 22,
  md: 28,
  lg: 40,
  xl: 60,
  display: 112
};

/**
 * The Neuruh mark. Typographic by design — no logo artwork was supplied.
 * Swap the glyph content here when real artwork arrives; the lockup geometry
 * is what the rest of the system depends on.
 */
function Wordmark({
  size = "md",
  monogram = false,
  product,
  stacked = false,
  divided = true,
  tone = "auto",
  href,
  className = "",
  ...rest
}) {
  const cls = ["n-mark", tone === "inverse" ? "n-mark--inverse" : tone === "onlight" ? "n-mark--onlight" : "", stacked ? "n-mark--stacked" : "", divided && product && !stacked ? "n-mark--divided" : "", className].filter(Boolean).join(" ");
  const w = WORD[size] || WORD.md;
  const g = GLYPH[size] || GLYPH.md;
  const body = /*#__PURE__*/React.createElement(React.Fragment, null, monogram ? /*#__PURE__*/React.createElement("span", {
    className: "n-mark__glyph",
    style: {
      width: g,
      fontSize: g * 0.62
    },
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("span", null, "N")) : null, monogram && !product ? null : /*#__PURE__*/React.createElement("span", {
    className: "n-mark__lockup"
  }, /*#__PURE__*/React.createElement("span", {
    className: "n-mark__word",
    style: {
      fontSize: w
    }
  }, "Neuruh"), product && stacked ? /*#__PURE__*/React.createElement("span", {
    className: "n-mark__product"
  }, product) : null), product && !stacked ? /*#__PURE__*/React.createElement("span", {
    className: "n-mark__product"
  }, product) : null);
  if (href) return /*#__PURE__*/React.createElement("a", _extends({
    className: cls,
    href: href,
    "aria-label": product ? `Neuruh ${product}` : "Neuruh"
  }, rest), body);
  return /*#__PURE__*/React.createElement("span", _extends({
    className: cls
  }, rest), body);
}

/** Display lockup for deck covers, report title pages, and certificates. */
function Seal({
  eyebrow = "Neuruh Org",
  size = 72,
  className = "",
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({
    className: `n-seal ${className}`.trim()
  }, rest), /*#__PURE__*/React.createElement("span", {
    className: "n-seal__word",
    style: {
      fontSize: size
    }
  }, "Neuruh"), eyebrow ? /*#__PURE__*/React.createElement("span", {
    className: "n-seal__rule"
  }, eyebrow) : null);
}
Object.assign(__ds_scope, { Wordmark, Seal });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/Wordmark.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Panel container. Header/body/footer are optional slots. */
function Card({
  title,
  label,
  actions,
  footer,
  variant = "default",
  interactive = false,
  flushBody = false,
  children,
  className = "",
  ...rest
}) {
  const cls = ["n-card", variant !== "default" ? `n-card--${variant}` : "", interactive ? "n-card--interactive" : "", className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("div", _extends({
    className: cls
  }, rest), title || label || actions ? /*#__PURE__*/React.createElement("div", {
    className: "n-card__header"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "var(--space-1)",
      flex: 1,
      minWidth: 0
    }
  }, label ? /*#__PURE__*/React.createElement("span", {
    className: "n-label"
  }, label) : null, title ? /*#__PURE__*/React.createElement("h3", {
    className: "n-card__title"
  }, title) : null), actions ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "var(--space-2)",
      flex: "none"
    }
  }, actions) : null) : null, /*#__PURE__*/React.createElement("div", {
    className: flushBody ? "n-card__body n-card__body--flush" : "n-card__body"
  }, children), footer ? /*#__PURE__*/React.createElement("div", {
    className: "n-card__footer"
  }, footer) : null);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/Icon.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Renders a glyph from the Neuruh icon set (Lucide geometry, 24px grid, 1.5 stroke). */
function Icon({
  name,
  size = 16,
  strokeWidth = 1.5,
  className = "",
  title,
  style,
  ...rest
}) {
  const geometry = __ds_scope.ICON_PATHS[name];
  if (!geometry) return null;
  return /*#__PURE__*/React.createElement("svg", _extends({
    className: `n-icon ${className}`.trim(),
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: strokeWidth,
    strokeLinecap: "round",
    strokeLinejoin: "round",
    role: title ? "img" : "presentation",
    "aria-hidden": title ? undefined : true,
    style: style,
    dangerouslySetInnerHTML: {
      __html: (title ? `<title>${title}</title>` : "") + geometry
    }
  }, rest));
}
Object.assign(__ds_scope, { Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Icon.jsx", error: String((e && e.message) || e) }); }

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Compact mono status marker. */
function Badge({
  tone = "neutral",
  icon,
  children,
  className = "",
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({
    className: `n-badge n-badge--${tone} ${className}`.trim()
  }, rest), icon ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 11
  }) : null, children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** The primary action primitive. Five variants, three sizes. */
function Button({
  variant = "secondary",
  size = "md",
  icon,
  iconAfter,
  block = false,
  href,
  children,
  className = "",
  ...rest
}) {
  const cls = ["n-btn", `n-btn--${variant}`, `n-btn--${size}`, block ? "n-btn--block" : "", className].filter(Boolean).join(" ");
  const glyph = size === "sm" ? 13 : size === "lg" ? 17 : 15;
  const inner = /*#__PURE__*/React.createElement(React.Fragment, null, icon ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: glyph
  }) : null, children ? /*#__PURE__*/React.createElement("span", null, children) : null, iconAfter ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: iconAfter,
    size: glyph
  }) : null);
  if (href) return /*#__PURE__*/React.createElement("a", _extends({
    className: cls,
    href: href
  }, rest), inner);
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    className: cls
  }, rest), inner);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Square icon-only control for toolbars and panel headers. */
function IconButton({
  icon,
  size = "md",
  label,
  bordered = false,
  pressed,
  className = "",
  ...rest
}) {
  const cls = ["n-iconbtn", `n-iconbtn--${size}`, bordered ? "n-iconbtn--bordered" : "", className].filter(Boolean).join(" ");
  const glyph = size === "sm" ? 14 : size === "lg" ? 18 : 16;
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    className: cls,
    "aria-label": label,
    "aria-pressed": pressed
  }, rest), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: glyph
  }));
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/core/Tag.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Pill for user-applied filters and categories. */
function Tag({
  selected = false,
  onRemove,
  icon,
  children,
  className = "",
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({
    className: `n-tag ${selected ? "n-tag--selected" : ""} ${className}`.trim()
  }, rest), icon ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 12
  }) : null, children, onRemove ? /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "n-tag__remove",
    "aria-label": "Remove",
    onClick: onRemove
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "x",
    size: 12
  })) : null);
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Tag.jsx", error: String((e && e.message) || e) }); }

// components/data/DataTable.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Declarative table. Columns describe alignment and formatting so numbers get
 * mono tabular treatment automatically instead of per-cell inline styles.
 */
function DataTable({
  columns = [],
  rows = [],
  rowKey = "id",
  density = "default",
  selectedKey,
  flaggedKeys,
  onSelect,
  sort,
  onSort,
  footer,
  maxHeight,
  className = "",
  ...rest
}) {
  const flagged = React.useMemo(() => new Set(flaggedKeys || []), [flaggedKeys]);
  const cls = ["n-table", density !== "default" ? `n-table--${density}` : "", onSelect ? "n-table--interactive" : "", className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: maxHeight ? "n-table-scroll n-table-scroll--capped" : "n-table-scroll",
    style: maxHeight ? {
      maxHeight
    } : undefined
  }, /*#__PURE__*/React.createElement("table", _extends({
    className: cls
  }, rest), /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, columns.map(c => {
    const active = sort && sort.key === c.key;
    return /*#__PURE__*/React.createElement("th", {
      key: c.key,
      "data-align": c.align,
      "data-sortable": c.sortable ? "" : undefined,
      "aria-sort": active ? sort.dir === "asc" ? "ascending" : "descending" : undefined,
      style: c.width ? {
        width: c.width
      } : undefined,
      onClick: c.sortable && onSort ? () => onSort(c.key) : undefined
    }, c.label, active ? /*#__PURE__*/React.createElement("span", {
      className: "n-table__sort"
    }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
      name: "chevron-down",
      size: 12,
      style: sort.dir === "asc" ? {
        transform: "scaleY(-1)"
      } : undefined
    })) : null);
  }))), /*#__PURE__*/React.createElement("tbody", null, rows.map(r => {
    const k = r[rowKey];
    return /*#__PURE__*/React.createElement("tr", {
      key: k,
      "aria-selected": selectedKey === k ? "true" : undefined,
      "data-flagged": flagged.has(k) && selectedKey !== k ? "" : undefined,
      onClick: onSelect ? () => onSelect(k, r) : undefined
    }, columns.map(c => /*#__PURE__*/React.createElement("td", {
      key: c.key,
      "data-align": c.align,
      "data-numeric": c.numeric ? "" : undefined,
      "data-primary": c.primary ? "" : undefined,
      "data-key": c.mono ? "" : undefined
    }, c.render ? c.render(r) : r[c.key])));
  })))), footer ? /*#__PURE__*/React.createElement("div", {
    className: "n-table__foot"
  }, footer) : null);
}
Object.assign(__ds_scope, { DataTable });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/DataTable.jsx", error: String((e && e.message) || e) }); }

// components/data/EmptyState.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * The state a surface shows when it has nothing — including, deliberately,
 * "this was not specified in the source material". Honest gaps over invented
 * content is a brand rule, so it needs a first-class component.
 */
function EmptyState({
  icon = "layers",
  label,
  title,
  children,
  actions,
  variant = "default",
  hatched = false,
  className = "",
  ...rest
}) {
  const cls = ["n-empty", variant !== "default" ? `n-empty--${variant}` : "", hatched ? "n-hatch" : "", hatched && variant === "unavailable" ? "n-hatch--caution" : "", className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("div", _extends({
    className: cls
  }, rest), icon ? /*#__PURE__*/React.createElement("span", {
    className: "n-empty__mark"
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 18
  })) : null, label ? /*#__PURE__*/React.createElement("span", {
    className: "n-label"
  }, label) : null, title ? /*#__PURE__*/React.createElement("h3", {
    className: "n-empty__title"
  }, title) : null, children ? /*#__PURE__*/React.createElement("p", {
    className: "n-empty__body"
  }, children) : null, actions ? /*#__PURE__*/React.createElement("div", {
    className: "n-empty__actions"
  }, actions) : null);
}
Object.assign(__ds_scope, { EmptyState });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/EmptyState.jsx", error: String((e && e.message) || e) }); }

// components/data/KeyValue.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Attribute list. Mono uppercase keys, tabular values. */
function KeyValue({
  items = [],
  layout = "rows",
  className = "",
  ...rest
}) {
  const cls = ["n-kv", layout === "columns" ? "n-kv--columns" : layout === "stacked" ? "n-kv--stacked" : "", className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("dl", _extends({
    className: cls
  }, rest), items.map((it, i) => /*#__PURE__*/React.createElement("div", {
    className: "n-kv__row",
    key: (it.key || "") + i
  }, /*#__PURE__*/React.createElement("dt", {
    className: "n-kv__key"
  }, it.key), /*#__PURE__*/React.createElement("dd", {
    className: "n-kv__val",
    style: {
      margin: 0
    }
  }, it.value))));
}
Object.assign(__ds_scope, { KeyValue });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/KeyValue.jsx", error: String((e && e.message) || e) }); }

// components/data/Sparkline.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Inline trend. No axes, no gridlines, no tooltip — a shape, not a chart. */
function Sparkline({
  values = [],
  width = 92,
  height = 24,
  tone = "accent",
  area = true,
  dot = true,
  baseline = false,
  className = "",
  ...rest
}) {
  if (values.length < 2) return null;
  const min = Math.min(...values);
  const max = Math.max(...values);
  const span = max - min || 1;
  const pad = 2;
  const px = i => pad + i / (values.length - 1) * (width - pad * 2);
  const py = v => height - pad - (v - min) / span * (height - pad * 2);
  const line = values.map((v, i) => `${i ? "L" : "M"}${px(i).toFixed(1)},${py(v).toFixed(1)}`).join(" ");
  const fill = `${line} L${px(values.length - 1).toFixed(1)},${height} L${px(0).toFixed(1)},${height} Z`;
  const midY = py(min + span / 2).toFixed(1);
  return /*#__PURE__*/React.createElement("svg", _extends({
    className: ["n-spark", tone !== "accent" ? `n-spark--${tone}` : "", className].filter(Boolean).join(" "),
    width: width,
    height: height,
    viewBox: `0 0 ${width} ${height}`,
    role: "img",
    "aria-hidden": "true"
  }, rest), baseline ? /*#__PURE__*/React.createElement("line", {
    className: "n-spark__baseline",
    x1: 0,
    y1: midY,
    x2: width,
    y2: midY
  }) : null, area ? /*#__PURE__*/React.createElement("path", {
    className: "n-spark__area",
    d: fill
  }) : null, /*#__PURE__*/React.createElement("path", {
    className: "n-spark__line",
    d: line
  }), dot ? /*#__PURE__*/React.createElement("circle", {
    className: "n-spark__dot",
    cx: px(values.length - 1),
    cy: py(values[values.length - 1]),
    r: 1.8
  }) : null);
}
Object.assign(__ds_scope, { Sparkline });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/Sparkline.jsx", error: String((e && e.message) || e) }); }

// components/evidence/ConfidenceMeter.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Ten-tick confidence readout. */
function ConfidenceMeter({
  value = 0,
  label = "Confidence",
  basis,
  className = "",
  ...rest
}) {
  const pct = Math.max(0, Math.min(100, value));
  const band = pct >= 80 ? "high" : pct >= 50 ? "medium" : "low";
  const on = Math.round(pct / 10);
  return /*#__PURE__*/React.createElement("div", _extends({
    className: `n-confidence n-confidence--${band} ${className}`.trim()
  }, rest), /*#__PURE__*/React.createElement("div", {
    className: "n-confidence__head"
  }, /*#__PURE__*/React.createElement("span", {
    className: "n-confidence__label"
  }, label), /*#__PURE__*/React.createElement("span", {
    className: "n-confidence__value"
  }, pct, "%")), /*#__PURE__*/React.createElement("div", {
    className: "n-confidence__ticks"
  }, Array.from({
    length: 10
  }, (_, i) => /*#__PURE__*/React.createElement("span", {
    key: i,
    className: `n-confidence__tick ${i < on ? "n-confidence__tick--on" : ""}`.trim()
  }))), basis ? /*#__PURE__*/React.createElement("span", {
    className: "n-confidence__basis"
  }, basis) : null);
}
Object.assign(__ds_scope, { ConfidenceMeter });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/evidence/ConfidenceMeter.jsx", error: String((e && e.message) || e) }); }

// components/evidence/EvidenceChip.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const GLYPH = {
  verified: "circle-check",
  unverified: "triangle-alert",
  conflict: "circle-alert",
  neutral: "link-2"
};

/** Inline citation: which source backs this value. */
function EvidenceChip({
  state = "neutral",
  source,
  id,
  href,
  onClick,
  className = "",
  ...rest
}) {
  const Tag = href ? "a" : onClick ? "button" : "span";
  const cls = ["n-evidence", state !== "neutral" ? `n-evidence--${state}` : "", className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement(Tag, _extends({
    className: cls,
    href: href,
    onClick: onClick,
    type: onClick && !href ? "button" : undefined
  }, rest), /*#__PURE__*/React.createElement("span", {
    className: "n-evidence__mark"
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: GLYPH[state],
    size: 11
  })), /*#__PURE__*/React.createElement("span", null, source), id ? /*#__PURE__*/React.createElement("span", {
    className: "n-evidence__id"
  }, id) : null);
}
Object.assign(__ds_scope, { EvidenceChip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/evidence/EvidenceChip.jsx", error: String((e && e.message) || e) }); }

// components/evidence/ProvenanceTrail.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const GLYPH = {
  verified: "circle-check",
  unverified: "triangle-alert",
  conflict: "circle-alert",
  neutral: "database"
};

/** Ordered list of every source that produced a value. */
function ProvenanceTrail({
  rows = [],
  className = "",
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    className: `n-provenance ${className}`.trim()
  }, rest), rows.map((r, i) => /*#__PURE__*/React.createElement("div", {
    className: "n-provenance__row",
    key: r.source + i
  }, /*#__PURE__*/React.createElement("span", {
    className: "n-provenance__mark",
    style: r.state === "conflict" ? {
      color: "var(--status-critical)"
    } : r.state === "verified" ? {
      color: "var(--status-verified)"
    } : r.state === "unverified" ? {
      color: "var(--status-caution)"
    } : undefined
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: GLYPH[r.state || "neutral"],
    size: 13
  })), /*#__PURE__*/React.createElement("span", {
    className: "n-provenance__source"
  }, r.source), /*#__PURE__*/React.createElement("span", {
    className: "n-provenance__value"
  }, r.value), /*#__PURE__*/React.createElement("span", {
    className: "n-provenance__stamp"
  }, r.stamp))));
}
Object.assign(__ds_scope, { ProvenanceTrail });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/evidence/ProvenanceTrail.jsx", error: String((e && e.message) || e) }); }

// components/evidence/Stat.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Single mono numeral with label and optional delta. */
function Stat({
  label,
  value,
  delta,
  deltaDirection = "flat",
  foot,
  size = "md",
  className = "",
  ...rest
}) {
  const cls = ["n-stat", size !== "md" ? `n-stat--${size}` : "", className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("div", _extends({
    className: cls
  }, rest), label ? /*#__PURE__*/React.createElement("span", {
    className: "n-stat__label"
  }, label) : null, /*#__PURE__*/React.createElement("span", {
    className: "n-stat__value"
  }, value), delta || foot ? /*#__PURE__*/React.createElement("span", {
    className: "n-stat__foot"
  }, delta ? /*#__PURE__*/React.createElement("span", {
    className: `n-stat__delta n-stat__delta--${deltaDirection}`
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: deltaDirection === "down" ? "trending-up" : "trending-up",
    size: 12,
    style: deltaDirection === "down" ? {
      transform: "scaleY(-1)"
    } : undefined
  }), delta) : null, foot ? /*#__PURE__*/React.createElement("span", null, foot) : null) : null);
}
Object.assign(__ds_scope, { Stat });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/evidence/Stat.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Dialog.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Modal. Renders nothing when `open` is false. */
function Dialog({
  open = false,
  title,
  description,
  footer,
  onClose,
  width,
  children,
  className = "",
  ...rest
}) {
  if (!open) return null;
  return /*#__PURE__*/React.createElement("div", {
    className: "n-dialog__scrim",
    onClick: onClose
  }, /*#__PURE__*/React.createElement("div", _extends({
    className: `n-dialog ${className}`.trim(),
    role: "dialog",
    "aria-modal": "true",
    style: width ? {
      maxWidth: width
    } : undefined,
    onClick: e => e.stopPropagation()
  }, rest), /*#__PURE__*/React.createElement("div", {
    className: "n-dialog__header"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, title ? /*#__PURE__*/React.createElement("h2", {
    className: "n-dialog__title"
  }, title) : null, description ? /*#__PURE__*/React.createElement("p", {
    className: "n-dialog__desc"
  }, description) : null), onClose ? /*#__PURE__*/React.createElement(__ds_scope.IconButton, {
    icon: "x",
    size: "sm",
    label: "Close",
    onClick: onClose
  }) : null), children ? /*#__PURE__*/React.createElement("div", {
    className: "n-dialog__body"
  }, children) : null, footer ? /*#__PURE__*/React.createElement("div", {
    className: "n-dialog__footer"
  }, footer) : null));
}
Object.assign(__ds_scope, { Dialog });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Dialog.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Progress.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Determinate or indeterminate 4px bar. */
function Progress({
  value = 0,
  tone = "accent",
  indeterminate = false,
  className = "",
  ...rest
}) {
  const cls = ["n-progress", tone !== "accent" ? `n-progress--${tone}` : "", indeterminate ? "n-progress--indeterminate" : "", className].filter(Boolean).join(" ");
  const pct = Math.max(0, Math.min(100, value));
  return /*#__PURE__*/React.createElement("div", _extends({
    className: cls,
    role: "progressbar",
    "aria-valuenow": indeterminate ? undefined : pct,
    "aria-valuemin": 0,
    "aria-valuemax": 100
  }, rest), /*#__PURE__*/React.createElement("div", {
    className: "n-progress__fill",
    style: indeterminate ? undefined : {
      width: `${pct}%`
    }
  }));
}
Object.assign(__ds_scope, { Progress });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Progress.jsx", error: String((e && e.message) || e) }); }

// components/feedback/StatusDot.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Machine state indicator: dot + uppercase mono label. */
function StatusDot({
  state = "inert",
  label,
  pulse = false,
  className = "",
  ...rest
}) {
  const cls = ["n-status", `n-status--${state}`, pulse ? "n-status--pulse" : "", className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("span", _extends({
    className: cls
  }, rest), /*#__PURE__*/React.createElement("span", {
    className: "n-status__dot"
  }), label ? /*#__PURE__*/React.createElement("span", null, label) : null);
}
Object.assign(__ds_scope, { StatusDot });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/StatusDot.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Toast.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const GLYPH = {
  info: "circle-alert",
  success: "circle-check",
  caution: "triangle-alert",
  critical: "circle-alert"
};

/** Transient notification. */
function Toast({
  tone = "info",
  title,
  message,
  onDismiss,
  className = "",
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    className: `n-toast n-toast--${tone} ${className}`.trim(),
    role: "status"
  }, rest), /*#__PURE__*/React.createElement("span", {
    className: "n-toast__icon"
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: GLYPH[tone],
    size: 16
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, title ? /*#__PURE__*/React.createElement("div", {
    className: "n-toast__title"
  }, title) : null, message ? /*#__PURE__*/React.createElement("div", {
    className: "n-toast__msg"
  }, message) : null), onDismiss ? /*#__PURE__*/React.createElement(__ds_scope.IconButton, {
    icon: "x",
    size: "sm",
    label: "Dismiss",
    onClick: onDismiss
  }) : null);
}
Object.assign(__ds_scope, { Toast });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Toast.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Tooltip.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Hover/focus label. Mono, single line. */
function Tooltip({
  content,
  side = "top",
  children,
  className = "",
  ...rest
}) {
  const [open, setOpen] = React.useState(false);
  return /*#__PURE__*/React.createElement("span", _extends({
    className: `n-tooltip ${className}`.trim(),
    onMouseEnter: () => setOpen(true),
    onMouseLeave: () => setOpen(false),
    onFocus: () => setOpen(true),
    onBlur: () => setOpen(false)
  }, rest), children, open && content ? /*#__PURE__*/React.createElement("span", {
    className: `n-tooltip__bubble n-tooltip__bubble--${side}`,
    role: "tooltip"
  }, content) : null);
}
Object.assign(__ds_scope, { Tooltip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Tooltip.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Checkbox({
  label,
  checked,
  disabled,
  className = "",
  ...rest
}) {
  const cls = ["n-check", checked ? "n-check--checked" : "", disabled ? "n-check--disabled" : "", className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("label", {
    className: cls,
    style: {
      position: "relative"
    }
  }, /*#__PURE__*/React.createElement("input", _extends({
    type: "checkbox",
    checked: checked,
    disabled: disabled
  }, rest)), /*#__PURE__*/React.createElement("span", {
    className: "n-check__box"
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "check",
    size: 11,
    strokeWidth: 2.5
  })), label ? /*#__PURE__*/React.createElement("span", null, label) : null);
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/Field.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Label + control + hint/error wrapper. */
function Field({
  label,
  hint,
  error,
  htmlFor,
  children,
  className = "",
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    className: `n-field ${className}`.trim()
  }, rest), label ? /*#__PURE__*/React.createElement("label", {
    className: "n-field__label",
    htmlFor: htmlFor
  }, label) : null, children, error ? /*#__PURE__*/React.createElement("span", {
    className: "n-field__error"
  }, error) : hint ? /*#__PURE__*/React.createElement("span", {
    className: "n-field__hint"
  }, hint) : null);
}
Object.assign(__ds_scope, { Field });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Field.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Text input. Pass `icon` for a leading glyph, `mono` for identifiers. */
function Input({
  icon,
  size = "md",
  mono = false,
  invalid = false,
  className = "",
  ...rest
}) {
  const cls = ["n-input", size === "lg" ? "n-input--lg" : "", mono ? "n-input--mono" : "", invalid ? "n-input--invalid" : "", className].filter(Boolean).join(" ");
  const field = /*#__PURE__*/React.createElement("input", _extends({
    className: cls,
    "aria-invalid": invalid || undefined
  }, rest));
  if (!icon) return /*#__PURE__*/React.createElement("span", {
    className: "n-inputwrap"
  }, field);
  return /*#__PURE__*/React.createElement("span", {
    className: "n-inputwrap n-inputwrap--icon"
  }, /*#__PURE__*/React.createElement("span", {
    className: "n-inputwrap__icon"
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 14
  })), field);
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Radio.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Radio({
  label,
  checked,
  disabled,
  className = "",
  ...rest
}) {
  const cls = ["n-check", "n-check--radio", checked ? "n-check--checked" : "", disabled ? "n-check--disabled" : "", className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("label", {
    className: cls,
    style: {
      position: "relative"
    }
  }, /*#__PURE__*/React.createElement("input", _extends({
    type: "radio",
    checked: checked,
    disabled: disabled
  }, rest)), /*#__PURE__*/React.createElement("span", {
    className: "n-check__box"
  }), label ? /*#__PURE__*/React.createElement("span", null, label) : null);
}
Object.assign(__ds_scope, { Radio });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Radio.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Native select with Neuruh chrome. */
function Select({
  options = [],
  size = "md",
  invalid = false,
  className = "",
  ...rest
}) {
  const cls = ["n-input", "n-select", size === "lg" ? "n-input--lg" : "", invalid ? "n-input--invalid" : "", className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("span", {
    className: "n-selectwrap"
  }, /*#__PURE__*/React.createElement("select", _extends({
    className: cls,
    "aria-invalid": invalid || undefined
  }, rest), options.map(o => {
    const value = typeof o === "string" ? o : o.value;
    const label = typeof o === "string" ? o : o.label;
    return /*#__PURE__*/React.createElement("option", {
      key: value,
      value: value
    }, label);
  })), /*#__PURE__*/React.createElement("span", {
    className: "n-selectwrap__caret"
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "chevron-down",
    size: 14
  })));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/Switch.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Immediate-effect toggle. */
function Switch({
  label,
  checked,
  disabled,
  className = "",
  ...rest
}) {
  const cls = ["n-switch", checked ? "n-switch--on" : "", disabled ? "n-switch--disabled" : "", className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("label", {
    className: cls,
    style: {
      position: "relative"
    }
  }, /*#__PURE__*/React.createElement("input", _extends({
    type: "checkbox",
    role: "switch",
    checked: checked,
    disabled: disabled
  }, rest)), /*#__PURE__*/React.createElement("span", {
    className: "n-switch__track"
  }, /*#__PURE__*/React.createElement("span", {
    className: "n-switch__thumb"
  })), label ? /*#__PURE__*/React.createElement("span", null, label) : null);
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Switch.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Breadcrumbs.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Mono trail showing where the current record sits. */
function Breadcrumbs({
  items = [],
  className = "",
  ...rest
}) {
  return /*#__PURE__*/React.createElement("nav", _extends({
    className: `n-crumbs ${className}`.trim(),
    "aria-label": "Breadcrumb"
  }, rest), items.map((it, i) => {
    const label = typeof it === "string" ? it : it.label;
    const href = typeof it === "string" ? undefined : it.href;
    const last = i === items.length - 1;
    return /*#__PURE__*/React.createElement(React.Fragment, {
      key: label
    }, i > 0 ? /*#__PURE__*/React.createElement("span", {
      className: "n-crumbs__sep"
    }, "/") : null, last || !href ? /*#__PURE__*/React.createElement("span", {
      className: "n-crumbs__current"
    }, label) : /*#__PURE__*/React.createElement("a", {
      href: href
    }, label));
  }));
}
Object.assign(__ds_scope, { Breadcrumbs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Breadcrumbs.jsx", error: String((e && e.message) || e) }); }

// components/navigation/NavItem.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Sidebar row. */
function NavItem({
  icon,
  label,
  meta,
  active = false,
  href,
  className = "",
  ...rest
}) {
  const cls = ["n-navitem", active ? "n-navitem--active" : "", className].filter(Boolean).join(" ");
  const inner = /*#__PURE__*/React.createElement(React.Fragment, null, icon ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 16
  }) : null, /*#__PURE__*/React.createElement("span", {
    className: "n-navitem__label"
  }, label), meta != null ? /*#__PURE__*/React.createElement("span", {
    className: "n-navitem__meta"
  }, meta) : null);
  if (href) return /*#__PURE__*/React.createElement("a", _extends({
    className: cls,
    href: href,
    "aria-current": active ? "page" : undefined
  }, rest), inner);
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    className: cls,
    "aria-current": active ? "page" : undefined
  }, rest), inner);
}
Object.assign(__ds_scope, { NavItem });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/NavItem.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Tabs.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Horizontal view switcher. Controlled via `value`/`onChange`. */
function Tabs({
  items = [],
  value,
  onChange,
  variant = "underline",
  className = "",
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    className: ["n-tabs", variant === "enclosed" ? "n-tabs--enclosed" : "", className].filter(Boolean).join(" "),
    role: "tablist"
  }, rest), items.map(it => {
    const id = typeof it === "string" ? it : it.id;
    const label = typeof it === "string" ? it : it.label;
    const active = id === value;
    return /*#__PURE__*/React.createElement("button", {
      key: id,
      type: "button",
      role: "tab",
      "aria-selected": active,
      className: `n-tab ${active ? "n-tab--active" : ""}`.trim(),
      onClick: () => onChange && onChange(id)
    }, it.icon ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
      name: it.icon,
      size: 14
    }) : null, label, it.count != null ? /*#__PURE__*/React.createElement("span", {
      className: "n-tab__count"
    }, it.count) : null);
  }));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Tabs.jsx", error: String((e && e.message) || e) }); }

// components/navigation/TopBar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** 48px product chrome bar. The mark renders through Wordmark — no logo file exists. */
function TopBar({
  product,
  monogram = false,
  left,
  children,
  right,
  className = "",
  ...rest
}) {
  return /*#__PURE__*/React.createElement("header", _extends({
    className: `n-topbar ${className}`.trim()
  }, rest), /*#__PURE__*/React.createElement("div", {
    className: "n-topbar__brand"
  }, left, /*#__PURE__*/React.createElement(__ds_scope.Wordmark, {
    size: "sm",
    monogram: monogram,
    product: product,
    href: "#"
  })), children, /*#__PURE__*/React.createElement("span", {
    className: "n-topbar__spacer"
  }), right ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "var(--space-3)"
    }
  }, right) : null);
}
Object.assign(__ds_scope, { TopBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/TopBar.jsx", error: String((e && e.message) || e) }); }

// components/spatial/SceneFrame.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * The only sanctioned container for a spatial / WebGL surface.
 * Detects capability, honours reduced motion, and falls back to a poster
 * rather than shipping a blank canvas.
 */
function detectSceneTier() {
  if (typeof window === "undefined") return "static";
  const reduced = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  if (reduced) return "static";
  const saveData = navigator.connection && navigator.connection.saveData;
  if (saveData) return "static";
  const cores = navigator.hardwareConcurrency || 4;
  const mem = navigator.deviceMemory ?? 8;
  if (typeof navigator !== "undefined" && navigator.gpu) {
    return cores >= 8 ? "webgpu" : "webgl";
  }
  try {
    const c = document.createElement("canvas");
    const gl = c.getContext("webgl2") || c.getContext("webgl");
    if (!gl) return "static";
  } catch (e) {
    return "static";
  }
  if (cores <= 4 || mem <= 4) return "reduced";
  return "webgl";
}
const ORDER = {
  static: 0,
  reduced: 1,
  webgl: 2,
  webgpu: 3
};
function SceneFrame({
  aspect = "hero",
  fill = false,
  poster,
  posterAlt = "",
  requires = "webgl",
  label,
  caption,
  scrim = true,
  controls,
  overlay,
  children,
  className = "",
  ...rest
}) {
  const [tier, setTier] = React.useState("static");
  React.useEffect(() => {
    setTier(detectSceneTier());
  }, []);
  const live = ORDER[tier] >= ORDER[requires];
  const cls = ["n-scene", fill ? "n-scene--fill" : `n-scene--${aspect}`, className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("div", _extends({
    className: cls,
    "data-scene-tier": tier
  }, rest), poster ? /*#__PURE__*/React.createElement("img", {
    className: "n-scene__poster",
    src: poster,
    alt: posterAlt
  }) : null, live ? /*#__PURE__*/React.createElement("div", {
    className: "n-scene__canvas"
  }, children) : null, !live && !poster ? /*#__PURE__*/React.createElement("div", {
    className: "n-scene__notice"
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "layers",
    size: 20,
    style: {
      color: "var(--text-faint)"
    }
  }), /*#__PURE__*/React.createElement("span", {
    className: "n-label"
  }, tier === "static" ? "Static route" : "Reduced route"), /*#__PURE__*/React.createElement("p", null, caption || "This surface has a spatial scene. It is not rendered on this device or under reduced-motion settings — supply a poster still for the fallback.")) : null, scrim ? /*#__PURE__*/React.createElement("span", {
    className: "n-scene__scrim"
  }) : null, label ? /*#__PURE__*/React.createElement("div", {
    className: "n-scene__badge"
  }, /*#__PURE__*/React.createElement(__ds_scope.Badge, {
    tone: "outline"
  }, label), !live ? /*#__PURE__*/React.createElement(__ds_scope.Badge, {
    tone: "neutral"
  }, tier) : null) : null, overlay ? /*#__PURE__*/React.createElement("div", {
    className: "n-scene__overlay"
  }, overlay) : null, controls ? /*#__PURE__*/React.createElement("div", {
    className: "n-scene__controls"
  }, controls) : null);
}

/** Highest route this device and user preference allow: static | reduced | webgl | webgpu. */
SceneFrame.detectTier = detectSceneTier;

/** Ordered tiers, weakest first — for comparing a detected tier against a requirement. */
SceneFrame.TIERS = ["static", "reduced", "webgl", "webgpu"];
Object.assign(__ds_scope, { SceneFrame });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/spatial/SceneFrame.jsx", error: String((e && e.message) || e) }); }

// components/spatial/SoundToggle.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Audio is muted by default and must be user-initiated. */
function SoundToggle({
  on = false,
  onChange,
  label = "Scene audio",
  bars = 4,
  className = "",
  ...rest
}) {
  const [t, setT] = React.useState(0);
  React.useEffect(() => {
    if (!on) return;
    const id = setInterval(() => setT(v => v + 1), 160);
    return () => clearInterval(id);
  }, [on]);
  return /*#__PURE__*/React.createElement("span", _extends({
    className: `n-sound ${className}`.trim()
  }, rest), /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "n-iconbtn n-iconbtn--sm n-iconbtn--bordered",
    "aria-pressed": on,
    "aria-label": on ? "Mute " + label : "Unmute " + label,
    onClick: () => onChange && onChange(!on)
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: on ? "volume-2" : "volume-x",
    size: 14
  })), /*#__PURE__*/React.createElement("span", {
    className: "n-sound__meter",
    "aria-hidden": "true"
  }, Array.from({
    length: bars
  }, (_, i) => /*#__PURE__*/React.createElement("span", {
    key: i,
    className: "n-sound__bar",
    style: {
      height: on ? 3 + (Math.sin(t * 0.9 + i) + 1) / 2 * 9 : 2,
      opacity: on ? 1 : 0.32
    }
  }))));
}
Object.assign(__ds_scope, { SoundToggle });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/spatial/SoundToggle.jsx", error: String((e && e.message) || e) }); }

// guidelines/doc-page.js
try { (() => {
// @ds-adherence-ignore -- omelette starter scaffold (raw elements/hex/px by design)
// Copied omelette starter. Re-running copy_starter_component with this kind overwrites this file with the latest version (page content is unaffected).
/* BEGIN USAGE */
/**
 * <doc-page> — paged-document shell for printable HTML.
 *
 * FIRST, decide how the document paginates — up front, before building:
 *
 * - FLOWING document (the default): write the whole document as one
 *   normal HTML flow inside <doc-page>; the browser's print engine
 *   splits it onto pages at export. Use for long-form documents with a
 *   single text flow: reports, memos, letters, essays.
 * - EXPLICIT pagination: a fixed set of pre-paginated pages, one
 *   <section class="page"> child per page. Use when the user asks for a
 *   specific page count, or the design implies one: a one-page resume, a
 *   two-sided flier, a poster, a certificate, a brochure — any richly
 *   laid-out document without a single text flow.
 * - If in doubt, ask the user as part of the build.
 *
 * PAGE SIZING — paper differs by country (letter vs A4), so the printed
 * sheet is not one fixed truth:
 * - FLOWING documents pin NO paper size: the print engine paginates
 *   onto the user's real paper, and the content reflows to it.
 * - EXPLICITLY PAGINATED documents print each page at a FIXED page box
 *   with overflow hidden — letter by default, size="a4" for a clearly
 *   metric user, the user's chosen paper when they export. Design each
 *   page to FILL that box, fitting letter and A4 alike without overlap.
 * - width/height pin an explicit fixed size, ONLY when the user gives
 *   one.
 * Never write your own @page rule or hard-code paper dimensions in the
 * content.
 *
 * Sizing modes (attributes):
 *   (none)                      — portrait: flowing docs use the user's
 *           paper; explicitly paginated pages use the named size box
 *           (letter unless size="a4")
 *   orientation="landscape"     — the same, landscape
 *   width / height              — explicit fixed size, ONLY when the user
 *           gives one (e.g. width="22in" height="30in" for a 22×30
 *           poster): the page IS the design's size, printed at true
 *           dimensions (or scaled onto the user's paper at print time).
 *           Any absolute CSS length: px/in/mm/cm/pt/pc.
 * The component announces the chosen mode to the host app at runtime (a
 * meta tag it injects), so the print path can inject the user's true
 * paper size.
 *
 * On screen the document renders on a desk background: a flowing
 * document as one tall scrolling sheet (Google Docs' pageless view);
 * explicitly paginated documents as one card per page.
 *
 * EXPLICIT pagination usage:
 *   <style>doc-page:not(:defined){visibility:hidden}</style>
 *   <doc-page>
 *     <section class="page" id="p1">…one page's design…</section>
 *     <section class="page" id="p2">…</section>
 *   </doc-page>
 *   <script src="doc-page.js"></script>
 * How the page box works, concretely: each .page prints as ONE full-bleed
 * sheet at a FIXED physical size — letter by default (set size="a4" for
 * a clearly metric user), the user's chosen paper when they export —
 * with overflow hidden. Nothing scrolls and nothing reflows onto a next
 * sheet: content that misses the box is CLIPPED. Design each page to
 * FILL that page box, and to fit it — letter and A4 alike — without
 * overlap. Each page is a size container; don't size anything in
 * viewport units (they track the window, not the page), and never set
 * width or height on the .page section itself (the component sizes the
 * page box; an authored height like 100% is meaningless at print and is
 * overridden). The component owns the page box, the screen card chrome,
 * and the page breaks (never add your own break-before/after). Don't mix
 * .page sections with flowing content or header/footer slots in the same
 * document.
 *
 * FLOWING usage:
 *   <style>doc-page:not(:defined){visibility:hidden}</style>
 *   <doc-page margin="0.75in">
 *     <h1>Title</h1>
 *     <p>…body…</p>
 *   </doc-page>
 *   <script src="doc-page.js"></script>
 * There is no manual page-splitting — the browser's print engine
 * paginates at export. Standard break-hygiene rules (`break-inside:
 * avoid` on figures, code blocks, images and table rows; `orphans/
 * widows: 3`) are applied so paragraphs and groups split cleanly. On
 * screen and at print, headings default to `text-wrap: balance` and
 * body text to `text-wrap: pretty`; the defaults have zero specificity,
 * so any text-wrap you declare wins.
 *
 * Other attributes:
 *   size    — letter | a4 | legal (default letter). Flowing documents:
 *           preview proportion only — it does NOT pin their printed
 *           paper (the print dialog's paper governs); leave it alone
 *           there. Explicitly paginated documents: it sets the page box
 *           the cards and the pinned @page share (the export dialog's
 *           choice overrides both at print) — set size="a4" for a
 *           clearly metric user. Scaled-fit: names the sheet the fit is
 *           computed against, same a4-for-metric-users advice.
 *   content-width / content-height — the design's own fixed dimensions
 *           (CSS lengths), for scaling a fixed-size design ONTO the
 *           named sheet: content lays out at exactly this size, and the
 *           component scales it to fit that sheet's printable area
 *           (centered horizontally, top-aligned; the export dialog
 *           re-fits to the user's actual paper choice where available).
 *           Both must be set; they do not change the page box. For pages
 *           WITHOUT running header/footer slots.
 *   margin  — printable inset on every page of a FLOWING document
 *           (default 0.75in); margin="0" makes pages full-bleed.
 *           Explicitly paginated pages are always full-bleed.
 *
 * Running header/footer (flowing documents only): give an element
 * `slot="header"` or `slot="footer"` and it repeats on every printed
 * page via `position: fixed`. To keep body text from sliding under it,
 * the component prints inside a single-cell table whose <thead>/<tfoot>
 * are spacers sized to the header/footer height — browsers repeat
 * thead/tfoot on every page, so each sheet's content starts below the
 * header and ends above the footer. On screen the header/footer render
 * once at the top/bottom of the sheet.
 *
 * At print the component injects `@page { margin: 0 }` (which leaves
 * Chrome no margin box to draw its date/URL/page-count header in) and
 * moves the visual margin onto the sheet's own padding. It also marks
 * the document as owning its print CSS (a
 * `meta[name="omelette-owns-print"]` it injects at runtime), so the
 * PDF export never injects page-geometry CSS of its own on top.
 *
 * Print best practices for the content you author:
 * - Multi-column text: use CSS columns (`column-count` +
 *   `column-gap`), never side-by-side flex/grid columns — only real
 *   CSS columns flow and break across pages. `column-span: all` lets
 *   a heading span the columns; `hyphens: auto` (needs `lang` on
 *   the html element) keeps narrow columns readable.
 * - Page breaks in flowing documents: `break-before: page` on an
 *   element that must start a new page (a chapter, an appendix). Add
 *   your own kept-together blocks (callouts, stat tiles, cards) to a
 *   `break-inside: avoid` rule, and keep each one shorter than a page.
 * - Extend `orphans: 3; widows: 3` to any custom text blocks you add
 *   (p and li are covered by default).
 * - Give long tables a <thead> — browsers repeat it on every printed
 *   page.
 * - No `position: fixed`/`sticky` and no viewport units in content:
 *   fixed elements stamp every printed page (running headers/footers go
 *   in the component's slots) and `100vh` mis-sizes at print.
 *
 * Author content as static HTML so the user can click-to-edit any text
 * directly. Do not set width/padding/background on the document body —
 * the component owns the sheet box.
 */
/* END USAGE */

(() => {
  const PAPER = {
    letter: ['8.5in', '11in'],
    a4: ['210mm', '297mm'],
    legal: ['8.5in', '14in']
  };
  const CSS_LENGTH = /^\d+(\.\d+)?(px|in|mm|cm|pt|pc)$/;
  // Unitless "0" is a valid CSS length and the natural way to write
  // margin="0"; normalise it to 0px so max()/calc() (which reject a bare
  // number) keep working.
  const safeLen = (v, fb) => {
    v = (v || '').trim();
    return v === '0' ? '0px' : CSS_LENGTH.test(v) ? v : fb;
  };
  // WebKit (Safari and every iOS browser shell) never repeats a table's
  // thead/tfoot on printed pages (WebKit bug 17205), so the spacer-borne
  // vertical margins of a FLOWING document reach only the first page
  // there. Engine check, not browser check: vendor is 'Apple Computer,
  // Inc.' exactly for WebKit and 'Google Inc.' for Blink.
  const WK_PRINT = /apple/i.test(navigator.vendor || '');
  // CSS length → px number (CSS absolute units are exact: 1in = 96px).
  // Returns NaN for anything safeLen would reject — callers gate on it.
  const PX_PER = {
    px: 1,
    in: 96,
    mm: 96 / 25.4,
    cm: 96 / 2.54,
    pt: 96 / 72,
    pc: 16
  };
  const toPx = v => {
    const m = /^(\d+(?:\.\d+)?)(px|in|mm|cm|pt|pc)$/.exec((v || '').trim());
    return m ? parseFloat(m[1]) * PX_PER[m[2]] : NaN;
  };
  const stylesheet = `
    :host {
      position: relative;
      display: block;
      /* When the viewport is narrower than the page, grow to wrap the
       * sheet (plus this padding) instead of staying viewport-width, so
       * the desk background and right margin reach the sheet's far edge
       * in the horizontal scroll. */
      min-width: max-content;
      min-height: 100vh;
      background: #f5f5f4;
      padding: 48px 24px;
      box-sizing: border-box;
      font-family: -apple-system, BlinkMacSystemFont, "Helvetica Neue", Arial, sans-serif;
      --doc-page-w: 8.5in;
      --doc-page-h: 11in;
      --doc-page-margin: 0.75in;
      --doc-hdr-h: 0px;
      --doc-ftr-h: 0px;
      --doc-hdr-pad: 0px;
      --doc-ftr-pad: 0px;
    }
    .sheet {
      width: var(--doc-page-w);
      margin: 0 auto;
      background: #fff;
      box-shadow: 0 2px 10px rgba(20, 20, 19, 0.12);
      border-radius: 7px;
      box-sizing: border-box;
      padding: var(--doc-page-margin);
    }
    .frame { width: 100%; border-collapse: collapse; }
    /* Scaled-fit mode (content-width/content-height): the inner .fit box
     * lays the content out at its authored fixed size and scales it onto
     * the printable area; .fit-box reserves the scaled footprint in flow
     * (transforms don't affect layout) and centers it. Without the mode,
     * both divs are unstyled block pass-throughs. */
    /* Explicit pagination: direct .page children are the pages. The sheet
     * becomes a transparent stack and each page carries the card look on
     * screen; at print each page is exactly one full-bleed sheet. The
     * ::slotted defaults are deliberately weak (document CSS wins), so
     * authored page styling can override any of this. */
    .sheet.paginated {
      background: transparent;
      box-shadow: none;
      border-radius: 0;
      padding: 0;
    }
    .paginated ::slotted(.page) {
      position: relative;
      display: block;
      width: 100%;
      aspect-ratio: var(--doc-page-ar);
      container-type: size;
      overflow: hidden;
      box-sizing: border-box;
      background: #fff;
      border-radius: 7px;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.25);
      print-color-adjust: exact;
      -webkit-print-color-adjust: exact;
      break-inside: avoid;
    }
    .paginated ::slotted(.page:not(:first-child)) { margin-top: 1rem; }
    @media print {
      .sheet.paginated { padding: 0; }
      /* The flowing-document vertical inset lives on the repeating
       * thead/tfoot spacers, not the sheet padding — they must go too,
       * or each full-sheet .page is pushed ~margin down and spills onto
       * a second sheet. Paginated pages are full-bleed by definition
       * (content owns its insets). */
      .sheet.paginated .hdr-space,
      .sheet.paginated .ftr-space { height: 0; }
      .paginated ::slotted(.page) {
        border-radius: 0 !important;
        box-shadow: none !important;
        margin: 0 !important;
        /* Physical page-box sizing, no viewport units: Safari resolves
         * 100vh against the window, not the page box, so a vh-sized card
         * paginates wrong there. --doc-page-w/h are the named size by
         * default and are overridden to the user's chosen paper by the
         * export path, so every card is exactly one sheet either way.
         * Width + height (same source values as @page size) rather than
         * width + aspect-ratio: the ratio is a 6-decimal rounding of the
         * same division, and a few millionths of overflow would spill a
         * blank sheet after every page. The screen-only aspect-ratio
         * (preview proportions) must not leak into print. cqh typography
         * tracks the same box.
         *
         * Every declaration is !important: per CSS Scoping, unimportant
         * shadow ::slotted rules LOSE to the document context, so a page
         * section's authored inline style would silently beat this print
         * geometry. A model-authored height:100% did exactly that — the
         * percentage resolves as auto in the all-auto print ancestry, the
         * base rule's size containment turns auto into ZERO, and
         * overflow:hidden then paints nothing: a blank PDF with perfect
         * page boxes. At print the component's geometry is the design's
         * whole contract, so it must win over any authored sizing. */
        aspect-ratio: auto !important;
        width: var(--doc-page-w) !important;
        height: var(--doc-page-h) !important;
        overflow: hidden !important;
      }
      .paginated ::slotted(.page:not(:first-child)) {
        break-before: page !important;
        margin-top: 0 !important;
      }
    }
    .fit-mode .fit-box {
      width: calc(var(--doc-fit-w) * var(--doc-fit-scale));
      height: calc(var(--doc-fit-h) * var(--doc-fit-scale));
      margin: 0 auto;
      break-inside: avoid;
    }
    .fit-mode .fit {
      width: var(--doc-fit-w);
      height: var(--doc-fit-h);
      transform: scale(var(--doc-fit-scale));
      transform-origin: top left;
    }
    .frame td, .frame th { padding: 0; text-align: left; font-weight: inherit; }
    .hdr-space { height: var(--doc-hdr-h); }
    .ftr-space { height: var(--doc-ftr-h); }
    ::slotted([slot="header"]),
    ::slotted([slot="footer"]) { display: block; box-sizing: border-box; }
    @media print {
      :host { background: none; padding: 0; min-width: 0; min-height: 0; }
      .sheet {
        width: auto; margin: 0; box-shadow: none; border-radius: 0;
        padding: 0 var(--doc-page-margin);
      }
      /* The thead/tfoot spacers repeat on every page, so they carry the
       * vertical page margin (which the sheet's own padding cannot, since
       * that padding is consumed once on the first/last page). The running
       * header/footer are fixed inside that band. */
      /* The 0.35in is breathing room between a running header/footer and
       * the body; without one the spacer is exactly the page margin, so a
       * margin="0" full-bleed document gets truly full-bleed pages. */
      .hdr-space { height: max(var(--doc-page-margin), calc(var(--doc-hdr-h) + var(--doc-hdr-pad))); }
      .ftr-space { height: max(var(--doc-page-margin), calc(var(--doc-ftr-h) + var(--doc-ftr-pad))); }
      /* WebKit flowing documents: @page carries the vertical margin (see
       * _syncPrintPageRule), so the spacers keep only whatever a running
       * header/footer needs BEYOND it — page 1 would otherwise double its
       * top inset. Paginated sheets already zero their spacers above. */
      .sheet.wk-print:not(.paginated) .hdr-space { height: max(0px, calc(max(var(--doc-page-margin), calc(var(--doc-hdr-h) + var(--doc-hdr-pad))) - var(--doc-page-margin))); }
      .sheet.wk-print:not(.paginated) .ftr-space { height: max(0px, calc(max(var(--doc-page-margin), calc(var(--doc-ftr-h) + var(--doc-ftr-pad))) - var(--doc-page-margin))); }
      ::slotted([slot="header"]) {
        position: fixed; top: 0; left: 0; right: 0; margin: 0;
        padding: calc(var(--doc-page-margin) * 0.45) var(--doc-page-margin) 0;
      }
      ::slotted([slot="footer"]) {
        position: fixed; bottom: 0; left: 0; right: 0; margin: 0;
        padding: 0 var(--doc-page-margin) calc(var(--doc-page-margin) * 0.45);
      }
    }
  `;
  class DocPage extends HTMLElement {
    static get observedAttributes() {
      return ['size', 'width', 'height', 'margin', 'orientation', 'content-width', 'content-height'];
    }
    constructor() {
      super();
      this._root = this.attachShadow({
        mode: 'open'
      });
      this._mo = typeof MutationObserver === 'function' ? new MutationObserver(() => this._scheduleMeasure()) : null;
    }

    /** The named paper's [w, h], swapped when orientation="landscape".
     *  Only the named size swaps — explicit width/height are exact values
     *  the author already oriented. */
    _paperSize() {
      const named = PAPER[(this.getAttribute('size') || '').toLowerCase()] || PAPER.letter;
      const landscape = (this.getAttribute('orientation') || '').trim().toLowerCase() === 'landscape';
      return landscape ? [named[1], named[0]] : named;
    }
    get pageWidth() {
      return safeLen(this.getAttribute('width'), this._paperSize()[0]);
    }
    get pageHeight() {
      return safeLen(this.getAttribute('height'), this._paperSize()[1]);
    }
    get pageMargin() {
      return safeLen(this.getAttribute('margin'), '0.75in');
    }

    /** Scaled-fit mode's content box [w, h] as CSS lengths, or null when
     *  the mode is off (either attribute missing/invalid/zero — a partial
     *  declaration falls back to normal flow rather than guessing). */
    _contentFit() {
      const w = safeLen(this.getAttribute('content-width'), null);
      const h = safeLen(this.getAttribute('content-height'), null);
      if (!w || !h) return null;
      const wPx = toPx(w),
        hPx = toPx(h);
      return wPx > 0 && hPx > 0 ? [w, h, wPx, hPx] : null;
    }
    connectedCallback() {
      if (!this._sheet) this._render();
      this._syncSize();
      this._syncPrintPageRule();
      this._ensureTextWrapDefaults();
      this._ensureOwnsPrintMeta();
      this._syncFixedSizeMeta();
      this._syncPrintSizingMeta();
      if (this._mo) this._mo.observe(this, {
        subtree: true,
        childList: true,
        characterData: true,
        attributes: true
      });
      this._onResize = () => this._scheduleMeasure();
      window.addEventListener('resize', this._onResize);
      if (document.fonts && document.fonts.ready) {
        document.fonts.ready.then(() => this._scheduleMeasure());
      }
      this._scheduleMeasure();
    }
    disconnectedCallback() {
      window.removeEventListener('resize', this._onResize);
      if (this._mo) this._mo.disconnect();
      if (this._raf) {
        cancelAnimationFrame(this._raf);
        this._raf = null;
      }
      // Drop the head rules when the last doc-page leaves, so a deleted
      // document's @page geometry and text-wrap defaults can't apply to
      // whatever replaces it.
      const survivor = document.querySelector('doc-page');
      if (!survivor) {
        ['doc-page-print', 'doc-page-text-wrap', 'doc-page-owns-print', 'doc-page-fixed-size', 'doc-page-print-sizing'].forEach(id => {
          const tag = document.getElementById(id);
          if (tag) tag.remove();
        });
        // A live deck-stage deferred its own print-sizing meta to ours —
        // hand the page-global meta over so the deck isn't left unmarked.
        const deck = document.querySelector('deck-stage');
        if (deck && typeof deck._ensurePrintSizingMeta === 'function') {
          deck._ensurePrintSizingMeta();
        }
      } else {
        // A departed owner hands each page-global meta to whatever
        // doc-page remains (or it's removed).
        if (typeof survivor._syncFixedSizeMeta === 'function') {
          survivor._syncFixedSizeMeta();
        }
        if (typeof survivor._syncPrintSizingMeta === 'function') {
          survivor._syncPrintSizingMeta();
        }
      }
    }
    attributeChangedCallback() {
      if (!this._sheet) return;
      this._syncSize();
      this._syncPrintPageRule();
      this._syncFixedSizeMeta();
      this._syncPrintSizingMeta();
      this._scheduleMeasure();
    }
    _render() {
      this._root.innerHTML = `
        <style>${stylesheet}</style>
        <style id="vars"></style>
        <div class="sheet" data-screen-label="Document">
          <table class="frame" role="presentation">
            <thead><tr><th><div class="hdr-space"><slot name="header"></slot></div></th></tr></thead>
            <tbody><tr><td class="body"><div class="fit-box"><div class="fit"><slot></slot></div></div></td></tr></tbody>
            <tfoot><tr><td><div class="ftr-space"><slot name="footer"></slot></div></td></tr></tfoot>
          </table>
        </div>`;
      this._sheet = this._root.querySelector('.sheet');
      this._vars = this._root.getElementById('vars');
    }

    /** Runtime sizing lives in a shadow <style> :host rule, never on the
     *  light-DOM host element, so serialize-persist can't write it back. */
    _syncSize(hdrH, ftrH) {
      // Scaled-fit mode: content at its authored size, scaled onto the
      // printable area (page minus margins on both axes). The factor is a
      // plain number var so calc(length * number) stays valid; 4 decimals
      // keeps the shadow style stable across re-measures. Upscaling is
      // allowed — print transforms are vector, so text and CSS stay crisp
      // (raster images soften, which the catalog bullet warns about).
      const fit = this._contentFit();
      let fitVars = '';
      if (fit) {
        const marginPx = toPx(this.pageMargin) || 0;
        const availW = toPx(this.pageWidth) - 2 * marginPx;
        const availH = toPx(this.pageHeight) - 2 * marginPx;
        const scale = Math.min(availW / fit[2], availH / fit[3]);
        if (scale > 0 && Number.isFinite(scale)) {
          fitVars = '--doc-fit-w:' + fit[0] + ';' + '--doc-fit-h:' + fit[1] + ';' + '--doc-fit-scale:' + scale.toFixed(4) + ';';
        }
      }
      this._sheet.classList.toggle('fit-mode', !!fitVars);
      // Numeric w/h ratio for the paginated page cards' aspect-ratio —
      // aspect-ratio takes a number, not a length ratio, so compute it
      // here (CSS length division isn't portable). 6 decimals keeps the
      // shadow style stable across re-syncs.
      const arW = toPx(this.pageWidth);
      const arH = toPx(this.pageHeight);
      const ar = arW > 0 && arH > 0 ? (arW / arH).toFixed(6) : '0.772727';
      this._vars.textContent = ':host{' + fitVars + '--doc-page-ar:' + ar + ';' + '--doc-page-w:' + this.pageWidth + ';' + '--doc-page-h:' + this.pageHeight + ';' + '--doc-page-margin:' + this.pageMargin + ';' + '--doc-hdr-h:' + (hdrH || 0) + 'px;' + '--doc-ftr-h:' + (ftrH || 0) + 'px;' + '--doc-hdr-pad:' + (hdrH ? '0.35in' : '0px') + ';' + '--doc-ftr-pad:' + (ftrH ? '0.35in' : '0px') + '}';
    }

    /** @page is a no-op inside shadow DOM, so the rule lives in <head>.
     *  Re-appended on every sync so it stays last in source order — the
     *  @page cascade is source-order per descriptor, so this rule wins
     *  over any other @page rule in the document.
     *
     *  The @page SIZE is pinned where the page box IS part of the design:
     *  explicit-fixed-size mode (width + height authored), scaled-fit
     *  mode (the named sheet the fit targets), and explicit pagination
     *  (the named size the cards share — so card and sheet agree on
     *  every print path, and the export path's chosen paper overrides
     *  BOTH with one later rule). For FLOWING documents no paper size is
     *  emitted at all — the true size comes from the user's preference,
     *  injected by the export path or chosen in the print dialog — so a
     *  flowing document never fights the paper it lands on.
     *  margin: 0 is emitted in every mode: it leaves Chrome no margin box
     *  to draw its date/URL/page-count header in, and the visual margin
     *  lives on the sheet's own padding. */
    _syncPrintPageRule() {
      const id = 'doc-page-print';
      let tag = document.getElementById(id);
      if (!tag) {
        tag = document.createElement('style');
        tag.id = id;
      }
      document.head.appendChild(tag);
      // Three print-geometry regimes:
      // - true-size: the page IS the design — pin its exact size.
      // - scaled-fit (content-width/height): the fit factor is computed
      //   against the NAMED paper's printable area, so that paper must
      //   stay pinned or the scaled content overflows a smaller sheet
      //   (the export path re-fits and re-pins at print time on top).
      // - default modes: no paper size — but landscape still needs the
      //   paper-agnostic 'size: landscape' keyword, because the size
      //   descriptor is what carries orientation; without it a landscape
      //   document prints portrait whenever nothing injects a size.
      const landscape = (this.getAttribute('orientation') || '').trim().toLowerCase() === 'landscape';
      // Explicit pagination pins the page box to the SAME values that
      // size the cards (the named size by default, the export path's
      // chosen paper when its later rule overrides both) — card and
      // sheet agree on every print path, and a mismatched real paper
      // shrinks-to-fit in the dialog instead of clipping a Letter card
      // on A4. Declared before the paginated read below so both derive
      // from one check.
      const paginatedNow = this.querySelector(':scope > .page') !== null;
      const sizeDescriptor = this._trueSizePx() ? 'size: ' + this.pageWidth + ' ' + this.pageHeight + '; ' : this._contentFit() ? 'size: ' + this.pageWidth + ' ' + this.pageHeight + '; ' : paginatedNow ? 'size: ' + this.pageWidth + ' ' + this.pageHeight + '; ' : landscape ? 'size: landscape; ' : '';
      // WebKit never repeats the thead/tfoot spacers that carry a flowing
      // document's vertical page margins (see WK_PRINT above), so pages
      // after the first print edge-to-edge there. Carry the VERTICAL
      // margins on @page for WebKit instead, and the shadow print CSS
      // trims the first-page spacers by the same amount (.sheet.wk-print
      // rules). Horizontal inset stays on the sheet's own padding in
      // every engine. Blink keeps margin: 0 (a nonzero margin there
      // re-opens the box Chrome draws its header furniture in). One cost,
      // learned in testing: Safari's own date/URL headers are a USER
      // dialog setting ("Print headers and footers") that renders in the
      // margin area when room exists — margin: 0 only suppressed it by
      // leaving no room, and no CSS controls it. The export dialog's
      // Safari guide teaches turning the setting off for flowing
      // documents. Explicitly paginated and fixed-size documents keep
      // margin: 0 everywhere: their pages ARE the sheet.
      const wkFlowing = WK_PRINT && !paginatedNow && !this._trueSizePx() && !this._contentFit();
      const marginDescriptor = wkFlowing ? 'margin: ' + this.pageMargin + ' 0; ' : 'margin: 0; ';
      // Shadow-internal marker (never serialized), kept in lockstep with
      // the @page decision above: the print CSS trims the first-page
      // spacers ONLY while @page actually carries the margins — a
      // true-size or scaled-fit sheet keeps margin: 0 and must keep its
      // spacers too. Re-synced here so attribute changes and pagination
      // flips move both together.
      if (this._sheet) this._sheet.classList.toggle('wk-print', wkFlowing);
      tag.textContent = '@page { ' + sizeDescriptor + marginDescriptor + '} ' + '@media print { html, body { margin: 0 !important; padding: 0 !important; background: none !important; height: auto !important; overflow: visible !important; } ' + 'h1,h2,h3,h4,h5,h6 { break-after: avoid; } ' + 'figure,pre,blockquote,img,svg,tr { break-inside: avoid; } ' + 'p,li { orphans: 3; widows: 3; } ' + '* { -webkit-print-color-adjust: exact; print-color-adjust: exact; ' + 'backdrop-filter: none !important; -webkit-backdrop-filter: none !important; } ' + '*, *::before, *::after { animation-delay: -99s !important; animation-duration: .001s !important; ' + 'animation-iteration-count: 1 !important; animation-fill-mode: both !important; ' + 'animation-play-state: running !important; transition-duration: 0s !important; } }';
    }

    /** Typographic defaults for document text: balance headings, avoid
     *  widowed/orphaned words in body copy (browsers without text-wrap
     *  support drop the declarations). Zero-specificity via :where() so
     *  any text-wrap authored on those elements wins; document-level so the
     *  rules reach the slotted (light DOM) content — shadow styles can't.
     *  data-omelette-injected marks the tag for the host editor to strip
     *  at serialize, so it is never written back as authored source. */
    _ensureTextWrapDefaults() {
      if (document.getElementById('doc-page-text-wrap')) return;
      const tag = document.createElement('style');
      tag.id = 'doc-page-text-wrap';
      tag.setAttribute('data-omelette-injected', '');
      tag.textContent = ':where(h1,h2,h3,h4,h5,h6){text-wrap:balance}' + ':where(p,li,blockquote,figcaption){text-wrap:pretty}';
      document.head.appendChild(tag);
    }

    /** Declares that this document owns its print CSS. The instant-PDF
     *  export checks for the meta by NAME PRESENCE alone (content is
     *  ignored) and skips its automatic print-CSS injections, so the
     *  component's @page geometry is never overridden by a heuristic.
     *  data-omelette-injected keeps it out of serialized source. */
    _ensureOwnsPrintMeta() {
      if (document.getElementById('doc-page-owns-print')) return;
      const tag = document.createElement('meta');
      tag.id = 'doc-page-owns-print';
      tag.name = 'omelette-owns-print';
      tag.content = 'true';
      tag.setAttribute('data-omelette-injected', '');
      document.head.appendChild(tag);
    }

    /** This page's valid true-size page box (explicit width AND height)
     *  as [w, h] px ints, or null when the mode is off. */
    _trueSizePx() {
      if (!safeLen(this.getAttribute('width'), null) || !safeLen(this.getAttribute('height'), null)) return null;
      const w = Math.round(toPx(this.pageWidth));
      const h = Math.round(toPx(this.pageHeight));
      return w > 0 && h > 0 ? [w, h] : null;
    }

    /** True-size pages (explicit width AND height) also declare the page
     *  box as the preview size: the in-app preview reads
     *  meta[name="omelette-fixed-size"] (content "W,H" in px ints) and
     *  scales the sheet into view — without it an 18in poster previews at
     *  true size with scrollbars. Never overrides an author-set meta
     *  (only the component's own id is managed). The meta is page-global
     *  while doc-page instances are not, so every sync recomputes the
     *  page-wide owner — the first connected true-size doc-page — and a
     *  non-true-size sibling's sync can never delete the owner's meta.
     *  Removed when no true-size page remains (the owner's disconnect
     *  re-syncs via any survivor) or when an author-set meta exists. */
    _syncFixedSizeMeta() {
      const id = 'doc-page-fixed-size';
      const own = document.getElementById(id);
      const authored = document.querySelector('meta[name="omelette-fixed-size"]:not([data-omelette-injected])');
      // The page-wide owner, not this instance: an upgraded true-size page
      // anywhere in the document keeps the meta alive and sized.
      let box = null;
      for (const el of document.querySelectorAll('doc-page')) {
        box = typeof el._trueSizePx === 'function' ? el._trueSizePx() : null;
        if (box) break;
      }
      if (!box || authored) {
        if (own) own.remove();
        return;
      }
      const tag = own || document.createElement('meta');
      tag.id = id;
      tag.name = 'omelette-fixed-size';
      tag.content = box[0] + ',' + box[1];
      tag.setAttribute('data-omelette-injected', '');
      if (!own) document.head.appendChild(tag);
    }

    /** This page's print-sizing mode: 'fixed' when an explicit width AND
     *  height are authored (the page is the design's own size), else the
     *  default paper in the authored orientation. */
    _printSizingMode() {
      if (this._trueSizePx()) return 'fixed';
      const landscape = (this.getAttribute('orientation') || '').trim().toLowerCase() === 'landscape';
      return landscape ? 'default-landscape' : 'default-portrait';
    }

    /** Announces the print-sizing mode to the host app:
     *  meta[name="omelette-print-sizing"] with content 'default-portrait',
     *  'default-landscape', or 'fixed' (fixed pages also carry the
     *  omelette-fixed-size meta with the page box in px). The export path
     *  probes it to decide what true paper size to inject at print time —
     *  in the default modes the component emits no paper size of its own.
     *  Same page-global ownership rules as the fixed-size meta above:
     *  first connected doc-page owns it, an authored meta is never
     *  overridden, removed when no doc-page remains. */
    _syncPrintSizingMeta() {
      const id = 'doc-page-print-sizing';
      const own = document.getElementById(id);
      const authored = document.querySelector('meta[name="omelette-print-sizing"]:not([data-omelette-injected])');
      // A fixed page wins outright (mirroring the fixed-size loop above,
      // so the two metas can never contradict each other in a mixed
      // multi-page document); otherwise the first page's mode holds.
      let mode = null;
      for (const el of document.querySelectorAll('doc-page')) {
        if (typeof el._printSizingMode !== 'function') continue;
        const m = el._printSizingMode();
        if (m === 'fixed') {
          mode = m;
          break;
        }
        if (mode === null) mode = m;
      }
      if (!mode || authored) {
        if (own) own.remove();
        return;
      }
      // A deck-stage that connected first injected its own meta and
      // defers to any existing one — take it over, or the document ends
      // up with two conflicting injected metas (a doc-page page is the
      // document; the deck re-ensures its meta if every doc-page leaves).
      const deckMeta = document.getElementById('deck-stage-print-sizing');
      if (deckMeta) deckMeta.remove();
      const tag = own || document.createElement('meta');
      tag.id = id;
      tag.name = 'omelette-print-sizing';
      tag.content = mode;
      tag.setAttribute('data-omelette-injected', '');
      if (!own) document.head.appendChild(tag);
    }
    _scheduleMeasure() {
      if (this._raf) return;
      this._raf = requestAnimationFrame(() => {
        this._raf = null;
        this._measure();
      });
    }

    /** Slot heights feed the print spacers (--doc-hdr-h / --doc-ftr-h), so
     *  they re-measure on content mutation, resize, and font load. The
     *  same pass detects explicit pagination (direct .page children) and
     *  toggles the sheet between the flowing-document card and the
     *  page-per-card stack — content edits can add or remove pages at any
     *  time, so this tracks the same mutations the measurement does. */
    _measure() {
      const hdr = this.querySelector(':scope > [slot="header"]');
      const ftr = this.querySelector(':scope > [slot="footer"]');
      const wasPaginated = this._sheet.classList.contains('paginated');
      this._sheet.classList.toggle('paginated', this.querySelector(':scope > .page') !== null);
      // The WebKit @page margin is flowing-only, so a pagination flip
      // must re-emit the rule (content edits can add or remove .page
      // sections at any time).
      if (this._sheet.classList.contains('paginated') !== wasPaginated) {
        this._syncPrintPageRule();
      }
      this._syncSize(hdr ? hdr.offsetHeight : 0, ftr ? ftr.offsetHeight : 0);
    }
  }
  if (!customElements.get('doc-page')) {
    customElements.define('doc-page', DocPage);
  }
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "guidelines/doc-page.js", error: String((e && e.message) || e) }); }

// ui_kits/blackbox-console/ConsoleShell.jsx
try { (() => {
(() => {
  const {
    TopBar,
    IconButton,
    StatusDot,
    NavItem,
    Breadcrumbs,
    Switch,
    Button
  } = window.NeuruhDesignSystem_5cb7e4;
  const NAV = [{
    group: "Surveillance",
    items: [{
      id: "sweep",
      icon: "radar",
      label: "Sweep board",
      meta: "12"
    }, {
      id: "stream",
      icon: "terminal",
      label: "Diagnostic stream",
      meta: "418"
    }]
  }, {
    group: "Sources",
    items: [{
      id: "feeds",
      icon: "database",
      label: "Feeds",
      meta: "9"
    }, {
      id: "lineage",
      icon: "git-branch",
      label: "Lineage",
      meta: "318"
    }]
  }, {
    group: "Control",
    items: [{
      id: "policy",
      icon: "shield",
      label: "Policy"
    }, {
      id: "audit",
      icon: "lock",
      label: "Audit log"
    }]
  }];
  function ConsoleRail({
    view,
    onView,
    collapsed
  }) {
    return /*#__PURE__*/React.createElement("nav", {
      className: "n-nav",
      style: {
        width: collapsed ? "var(--rail-sidebar-collapsed)" : "var(--rail-sidebar)",
        flex: "none",
        padding: collapsed ? "8px 8px" : "0 8px 8px",
        borderRight: "1px solid var(--border-default)",
        background: "var(--bg-canvas)",
        overflow: "hidden",
        transition: "width var(--dur-base) var(--ease-standard)"
      }
    }, NAV.map(g => /*#__PURE__*/React.createElement(React.Fragment, {
      key: g.group
    }, collapsed ? /*#__PURE__*/React.createElement("div", {
      style: {
        height: 16
      }
    }) : /*#__PURE__*/React.createElement("div", {
      className: "n-nav__group"
    }, g.group), g.items.map(it => /*#__PURE__*/React.createElement(NavItem, {
      key: it.id,
      icon: it.icon,
      label: collapsed ? "" : it.label,
      meta: collapsed ? undefined : it.meta,
      active: view === it.id,
      onClick: () => onView(it.id)
    })))), !collapsed ? /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: "auto",
        paddingTop: 20
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "n-label",
      style: {
        marginBottom: 8
      }
    }, "Build"), /*#__PURE__*/React.createElement("div", {
      style: {
        font: "var(--type-data-sm)",
        color: "var(--text-faint)",
        lineHeight: 1.7
      }
    }, "blackbox 4.2.1", /*#__PURE__*/React.createElement("br", null), "run 0x4E2", /*#__PURE__*/React.createElement("br", null), "us-east-1b")) : null);
  }
  function ConsoleShell({
    view,
    onView,
    collapsed,
    onToggleRail,
    live,
    onLive,
    crumbs,
    children,
    inspector
  }) {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        flexDirection: "column",
        height: "100%",
        background: "var(--bg-sunken)"
      }
    }, /*#__PURE__*/React.createElement(TopBar, {
      product: "Blackbox",
      left: /*#__PURE__*/React.createElement(IconButton, {
        icon: "panel-left",
        size: "sm",
        label: "Toggle rail",
        pressed: collapsed,
        onClick: onToggleRail
      }),
      right: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Switch, {
        label: "Live",
        checked: live,
        onChange: e => onLive(e.target.checked)
      }), /*#__PURE__*/React.createElement(StatusDot, {
        state: live ? "live" : "inert",
        label: live ? "Streaming" : "Halted",
        pulse: live
      }), /*#__PURE__*/React.createElement("span", {
        style: {
          width: 8
        }
      }), /*#__PURE__*/React.createElement(IconButton, {
        icon: "bell",
        size: "sm",
        label: "Alerts"
      }), /*#__PURE__*/React.createElement(IconButton, {
        icon: "settings",
        size: "sm",
        label: "Settings"
      }))
    }, /*#__PURE__*/React.createElement(Breadcrumbs, {
      items: crumbs
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        flex: 1,
        minHeight: 0
      }
    }, /*#__PURE__*/React.createElement(ConsoleRail, {
      view: view,
      onView: onView,
      collapsed: collapsed
    }), /*#__PURE__*/React.createElement("main", {
      style: {
        flex: 1,
        minWidth: 0,
        overflow: "auto",
        padding: "20px 24px"
      }
    }, children), inspector));
  }
  Object.assign(window, {
    ConsoleShell,
    ConsoleRail
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/blackbox-console/ConsoleShell.jsx", error: String((e && e.message) || e) }); }

// ui_kits/blackbox-console/DiagnosticStream.jsx
try { (() => {
(() => {
  const {
    Card,
    Tabs,
    Badge,
    IconButton,
    Input,
    Button,
    StatusDot,
    Stat
  } = window.NeuruhDesignSystem_5cb7e4;
  const SEVERITY = {
    info: "neutral",
    warn: "caution",
    error: "critical",
    ok: "verified"
  };
  const SEED = [{
    t: "03:14:22.418",
    sev: "warn",
    src: "resolver",
    msg: "owner mismatch parcel=04-118-227 sdat=\"MARTIN, R & K\" clerk=\"MARTIN, ROBERT A\""
  }, {
    t: "03:14:22.401",
    sev: "ok",
    src: "sdat",
    msg: "batch 0x4E2 ingested rows=1284 dur=912ms"
  }, {
    t: "03:14:19.077",
    sev: "info",
    src: "geocode",
    msg: "resolved 38.3607,-75.5994 conf=0.94"
  }, {
    t: "03:14:11.902",
    sev: "error",
    src: "mls-bridge",
    msg: "handshake timeout after 30000ms attempt=3"
  }, {
    t: "03:13:58.640",
    sev: "warn",
    src: "ncoa",
    msg: "latency 14.2s exceeds budget 5.0s"
  }, {
    t: "03:13:41.115",
    sev: "ok",
    src: "clerk",
    msg: "DEED 2019-4412 fetched pages=7 sha256=9f2c…a041"
  }, {
    t: "03:12:07.883",
    sev: "error",
    src: "resolver",
    msg: "confidence floor breached parcel=11-006-882 conf=0.44 floor=0.50"
  }, {
    t: "03:11:52.209",
    sev: "info",
    src: "policy",
    msg: "redaction applied field=owner_ssn actor=system"
  }];
  function DiagnosticStream({
    live
  }) {
    const [filter, setFilter] = React.useState("all");
    const [rows, setRows] = React.useState(SEED);
    React.useEffect(() => {
      if (!live) return;
      const id = setInterval(() => {
        setRows(r => [{
          t: new Date().toISOString().slice(11, 23) + "Z",
          sev: ["info", "ok", "warn"][Math.floor(Math.random() * 3)],
          src: ["sdat", "geocode", "resolver", "clerk"][Math.floor(Math.random() * 4)],
          msg: "heartbeat ok queue=" + Math.floor(Math.random() * 40) + " lag=" + (Math.random() * 2).toFixed(2) + "s"
        }, ...r].slice(0, 60));
      }, 2200);
      return () => clearInterval(id);
    }, [live]);
    const shown = filter === "all" ? rows : rows.filter(r => r.sev === filter);
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        flexDirection: "column",
        gap: 18,
        maxWidth: 1080
      }
    }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
      className: "n-label"
    }, "Append-only event log"), /*#__PURE__*/React.createElement("h1", {
      style: {
        font: "var(--type-h1)",
        letterSpacing: "var(--tracking-tight)",
        color: "var(--text-primary)",
        margin: "6px 0 0"
      }
    }, "Diagnostic stream")), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 32
      }
    }, /*#__PURE__*/React.createElement(Stat, {
      size: "sm",
      label: "Events 1h",
      value: "418"
    }), /*#__PURE__*/React.createElement(Stat, {
      size: "sm",
      label: "Errors",
      value: "6"
    }), /*#__PURE__*/React.createElement(Stat, {
      size: "sm",
      label: "Warnings",
      value: "31"
    }), /*#__PURE__*/React.createElement(Stat, {
      size: "sm",
      label: "Retention",
      value: "90d"
    })), /*#__PURE__*/React.createElement(Card, {
      flushBody: true,
      label: "live tail",
      title: "blackbox://stream/0x4E2",
      actions: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Input, {
        icon: "search",
        placeholder: "grep",
        style: {
          width: 180
        }
      }), /*#__PURE__*/React.createElement(IconButton, {
        icon: "copy",
        size: "sm",
        label: "Copy",
        bordered: true
      }), /*#__PURE__*/React.createElement(IconButton, {
        icon: live ? "pause" : "play",
        size: "sm",
        label: "Pause stream",
        bordered: true
      }))
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        padding: "10px 16px",
        borderBottom: "1px solid var(--border-subtle)",
        display: "flex",
        alignItems: "center",
        gap: 14
      }
    }, /*#__PURE__*/React.createElement(Tabs, {
      variant: "enclosed",
      value: filter,
      onChange: setFilter,
      items: [{
        id: "all",
        label: "All"
      }, {
        id: "error",
        label: "Errors"
      }, {
        id: "warn",
        label: "Warnings"
      }, {
        id: "ok",
        label: "Success"
      }]
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        flex: 1
      }
    }), /*#__PURE__*/React.createElement(StatusDot, {
      state: live ? "live" : "inert",
      label: live ? "Tailing" : "Paused",
      pulse: live
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        background: "var(--bg-inset)",
        maxHeight: 380,
        overflow: "auto"
      }
    }, shown.map((r, i) => /*#__PURE__*/React.createElement("div", {
      key: r.t + i,
      style: {
        display: "grid",
        gridTemplateColumns: "116px 62px 92px 1fr",
        gap: 12,
        alignItems: "baseline",
        padding: "5px 16px",
        borderBottom: "1px solid var(--border-subtle)"
      }
    }, /*#__PURE__*/React.createElement("span", {
      className: "n-numeric",
      style: {
        font: "var(--type-data-sm)",
        color: "var(--text-faint)"
      }
    }, r.t), /*#__PURE__*/React.createElement(Badge, {
      tone: SEVERITY[r.sev]
    }, r.sev), /*#__PURE__*/React.createElement("span", {
      style: {
        font: "var(--type-data-sm)",
        color: "var(--text-accent)"
      }
    }, r.src), /*#__PURE__*/React.createElement("span", {
      style: {
        font: "var(--type-data-sm)",
        color: "var(--text-body)",
        wordBreak: "break-word"
      }
    }, r.msg))))));
  }
  Object.assign(window, {
    DiagnosticStream
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/blackbox-console/DiagnosticStream.jsx", error: String((e && e.message) || e) }); }

// ui_kits/blackbox-console/InspectorPanel.jsx
try { (() => {
(() => {
  const {
    ConfidenceMeter,
    ProvenanceTrail,
    EvidenceChip,
    Button,
    IconButton,
    Tabs,
    KeyValue
  } = window.NeuruhDesignSystem_5cb7e4;
  const RECORDS = {
    "04-118-227": {
      owner: "MARTIN, R & K",
      county: "Wicomico, MD",
      conf: 86,
      assessed: "$284,100",
      acres: "0.41",
      coords: "38.3607°N 75.5994°W",
      built: "1974",
      deed: "DEED 2019-4412",
      rows: [{
        source: "SDAT",
        value: "MARTIN, R & K",
        stamp: "07-28 03:14Z",
        state: "verified"
      }, {
        source: "Clerk of Court",
        value: "MARTIN, ROBERT A",
        stamp: "07-14 09:02Z",
        state: "conflict"
      }, {
        source: "USPS NCOA",
        value: "MARTIN, ROBERT",
        stamp: "06-30 11:47Z",
        state: "unverified"
      }, {
        source: "Tax roll 2025",
        value: "MARTIN, R & K",
        stamp: "01-12 00:00Z",
        state: "verified"
      }]
    },
    "11-006-882": {
      owner: "REDDEN, A & J",
      county: "Somerset, MD",
      conf: 44,
      assessed: "$88,700",
      acres: "1.02",
      coords: "38.0114°N 75.8712°W",
      built: "1961",
      deed: "DEED 2004-0918",
      rows: [{
        source: "SDAT",
        value: "REDDEN, A & J",
        stamp: "07-28 03:12Z",
        state: "verified"
      }, {
        source: "Clerk of Court",
        value: "REDDEN ESTATE",
        stamp: "05-02 14:20Z",
        state: "conflict"
      }, {
        source: "MLS bridge",
        value: "unreachable",
        stamp: "—",
        state: "unverified"
      }]
    }
  };
  function InspectorPanel({
    id,
    onClose,
    onOpenProvenance
  }) {
    const r = RECORDS[id] || RECORDS["04-118-227"];
    const [tab, setTab] = React.useState("evidence");
    return /*#__PURE__*/React.createElement("aside", {
      style: {
        width: "var(--rail-inspector)",
        flex: "none",
        borderLeft: "1px solid var(--border-default)",
        background: "var(--bg-canvas)",
        overflow: "auto"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 10,
        height: "var(--bar-height)",
        padding: "0 12px 0 16px",
        borderBottom: "1px solid var(--border-default)"
      }
    }, /*#__PURE__*/React.createElement("span", {
      className: "n-label",
      style: {
        flex: 1
      }
    }, "Inspector"), /*#__PURE__*/React.createElement(IconButton, {
      icon: "external-link",
      size: "sm",
      label: "Open full record"
    }), /*#__PURE__*/React.createElement(IconButton, {
      icon: "x",
      size: "sm",
      label: "Close inspector",
      onClick: onClose
    })), /*#__PURE__*/React.createElement("div", {
      className: "n-tex n-tex--grid",
      style: {
        padding: "16px"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        font: "var(--type-data)",
        color: "var(--text-accent)"
      }
    }, id), /*#__PURE__*/React.createElement("h2", {
      style: {
        font: "var(--type-h2)",
        letterSpacing: "var(--tracking-tight)",
        color: "var(--text-primary)",
        margin: "6px 0 4px"
      }
    }, r.owner), /*#__PURE__*/React.createElement("div", {
      style: {
        font: "var(--type-body-sm)",
        color: "var(--text-muted)"
      }
    }, r.county), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 8,
        margin: "14px 0 0",
        flexWrap: "wrap"
      }
    }, /*#__PURE__*/React.createElement(EvidenceChip, {
      state: "verified",
      source: "SDAT",
      id: id,
      onClick: onOpenProvenance
    }), /*#__PURE__*/React.createElement(EvidenceChip, {
      state: "conflict",
      source: "2 disagree",
      onClick: onOpenProvenance
    }))), /*#__PURE__*/React.createElement("hr", {
      className: "n-rule"
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        padding: "16px"
      }
    }, /*#__PURE__*/React.createElement(ConfidenceMeter, {
      value: r.conf,
      basis: r.conf >= 80 ? "3 of 4 sources agree · 6h old" : "2 of 3 sources agree · MLS unreachable"
    })), /*#__PURE__*/React.createElement("hr", {
      className: "n-rule"
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        padding: "0 16px"
      }
    }, /*#__PURE__*/React.createElement(Tabs, {
      value: tab,
      onChange: setTab,
      items: [{
        id: "evidence",
        label: "Evidence",
        count: r.rows.length
      }, {
        id: "attrs",
        label: "Attributes"
      }]
    })), tab === "evidence" ? /*#__PURE__*/React.createElement("div", {
      style: {
        padding: "12px 16px 20px"
      }
    }, /*#__PURE__*/React.createElement(ProvenanceTrail, {
      rows: r.rows
    }), /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      variant: "secondary",
      iconAfter: "chevron-right",
      onClick: onOpenProvenance,
      style: {
        marginTop: 14
      }
    }, "Full lineage")) : /*#__PURE__*/React.createElement("div", {
      style: {
        padding: "12px 16px 20px"
      }
    }, /*#__PURE__*/React.createElement(KeyValue, {
      items: [{
        key: "Assessed value",
        value: r.assessed
      }, {
        key: "Acreage",
        value: r.acres
      }, {
        key: "Coordinates",
        value: r.coords
      }, {
        key: "Year built",
        value: r.built
      }, {
        key: "Instrument",
        value: r.deed
      }]
    })));
  }
  Object.assign(window, {
    InspectorPanel,
    RECORDS
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/blackbox-console/InspectorPanel.jsx", error: String((e && e.message) || e) }); }

// ui_kits/blackbox-console/SweepBoard.jsx
try { (() => {
(() => {
  const {
    Card,
    Stat,
    Badge,
    Button,
    IconButton,
    Progress,
    Tabs,
    Tag,
    Input,
    StatusDot,
    DataTable,
    Sparkline,
    EmptyState
  } = window.NeuruhDesignSystem_5cb7e4;
  const TARGETS = [{
    id: "04-118-227",
    label: "MARTIN, R & K",
    county: "Wicomico",
    conf: 86,
    state: "conflict",
    assessed: "$284,100",
    seen: "03:14:22Z",
    trend: [4, 6, 5, 8, 7, 9, 12]
  }, {
    id: "04-118-231",
    label: "HOLLOWAY TRUST",
    county: "Wicomico",
    conf: 94,
    state: "verified",
    assessed: "$196,400",
    seen: "03:14:19Z",
    trend: [9, 8, 8, 7, 7, 6, 6]
  }, {
    id: "07-402-009",
    label: "PARSONS, D",
    county: "Worcester",
    conf: 71,
    state: "unverified",
    assessed: "$412,900",
    seen: "03:13:58Z",
    trend: [6, 6, 7, 7, 8, 8, 9]
  }, {
    id: "07-402-114",
    label: "CHESAPEAKE HOLDINGS LLC",
    county: "Worcester",
    conf: 91,
    state: "verified",
    assessed: "$1,140,000",
    seen: "03:13:41Z",
    trend: [3, 4, 6, 6, 9, 11, 14]
  }, {
    id: "11-006-882",
    label: "REDDEN, A & J",
    county: "Somerset",
    conf: 44,
    state: "conflict",
    assessed: "$88,700",
    seen: "03:12:07Z",
    trend: [7, 6, 6, 5, 4, 4, 3]
  }, {
    id: "11-006-903",
    label: "ESTATE OF W. TULL",
    county: "Somerset",
    conf: 63,
    state: "unverified",
    assessed: "$134,250",
    seen: "03:11:52Z",
    trend: [5, 5, 4, 5, 4, 4, 4]
  }];
  const FEEDS = [{
    name: "SDAT assessor",
    state: "verified",
    latency: "0.9s"
  }, {
    name: "Clerk of Court",
    state: "verified",
    latency: "1.8s"
  }, {
    name: "USPS NCOA",
    state: "caution",
    latency: "14.2s"
  }, {
    name: "MLS bridge",
    state: "critical",
    latency: "—"
  }];
  function SweepBoard({
    selected,
    onSelect,
    sweeping,
    onArm
  }) {
    const [range, setRange] = React.useState("24H");
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        flexDirection: "column",
        gap: 18,
        maxWidth: 1080
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "flex-end",
        gap: 16
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1
      }
    }, /*#__PURE__*/React.createElement("span", {
      className: "n-label"
    }, "Active sweep"), /*#__PURE__*/React.createElement("h1", {
      style: {
        font: "var(--type-h1)",
        letterSpacing: "var(--tracking-tight)",
        color: "var(--text-primary)",
        margin: "6px 0 0"
      }
    }, "Lower Eastern Shore \xB7 3 counties")), /*#__PURE__*/React.createElement(Tabs, {
      variant: "enclosed",
      value: range,
      onChange: setRange,
      items: ["24H", "7D", "30D", "FY"]
    }), /*#__PURE__*/React.createElement(Button, {
      variant: "command",
      icon: "zap",
      onClick: onArm,
      disabled: sweeping
    }, sweeping ? "Sweeping" : "Run sweep")), sweeping ? /*#__PURE__*/React.createElement(Progress, {
      indeterminate: true
    }) : /*#__PURE__*/React.createElement("hr", {
      className: "n-rule"
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "repeat(4, 1fr)",
        gap: 1,
        background: "var(--border-default)",
        border: "1px solid var(--border-default)",
        borderRadius: "var(--radius-3)",
        overflow: "hidden"
      }
    }, [{
      label: "Parcels swept",
      value: "4,218",
      delta: "+312",
      dir: "up",
      foot: "last 24h"
    }, {
      label: "Conflicts open",
      value: "27",
      delta: "−9",
      dir: "down",
      foot: "vs 7d"
    }, {
      label: "Median confidence",
      value: "84%",
      foot: "9 sources"
    }, {
      label: "Feed latency p95",
      value: "1.8s",
      delta: "+0.4s",
      dir: "up",
      foot: "degraded"
    }].map(s => /*#__PURE__*/React.createElement("div", {
      key: s.label,
      className: "n-tex n-tex--grain",
      style: {
        background: "var(--bg-surface)",
        backgroundImage: "var(--sheen-panel)",
        padding: "14px 16px"
      }
    }, /*#__PURE__*/React.createElement(Stat, {
      label: s.label,
      value: s.value,
      delta: s.delta,
      deltaDirection: s.dir,
      foot: s.foot
    })))), /*#__PURE__*/React.createElement(Card, {
      label: "Targets",
      title: "Ranked by conflict severity",
      flushBody: true,
      actions: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Input, {
        icon: "search",
        placeholder: "Filter targets",
        style: {
          width: 200
        }
      }), /*#__PURE__*/React.createElement(IconButton, {
        icon: "funnel",
        size: "sm",
        label: "Filters",
        bordered: true
      }), /*#__PURE__*/React.createElement(IconButton, {
        icon: "download",
        size: "sm",
        label: "Export",
        bordered: true
      }))
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        padding: "10px 16px",
        display: "flex",
        gap: 8,
        borderBottom: "1px solid var(--border-subtle)"
      }
    }, /*#__PURE__*/React.createElement(Tag, {
      icon: "map-pin",
      onRemove: () => {}
    }, "3 counties"), /*#__PURE__*/React.createElement(Tag, {
      selected: true,
      onRemove: () => {}
    }, "Conflict \u2265 1"), /*#__PURE__*/React.createElement(Tag, {
      onRemove: () => {}
    }, "Assessed > $50k")), /*#__PURE__*/React.createElement(DataTable, {
      density: "tight",
      maxHeight: 272,
      selectedKey: selected,
      onSelect: onSelect,
      flaggedKeys: TARGETS.filter(t => t.state === "conflict").map(t => t.id),
      columns: [{
        key: "id",
        label: "Parcel",
        mono: true,
        sortable: true
      }, {
        key: "label",
        label: "Owner of record",
        primary: true
      }, {
        key: "county",
        label: "County"
      }, {
        key: "assessed",
        label: "Assessed",
        align: "right",
        numeric: true,
        sortable: true
      }, {
        key: "trend",
        label: "Sweep 7d",
        width: 96,
        render: t => /*#__PURE__*/React.createElement(Sparkline, {
          values: t.trend,
          width: 80,
          height: 16,
          area: false,
          tone: t.conf >= 80 ? "verified" : t.conf >= 50 ? "caution" : "critical"
        })
      }, {
        key: "conf",
        label: "Conf",
        align: "right",
        numeric: true,
        render: t => /*#__PURE__*/React.createElement("span", {
          style: {
            color: t.conf >= 80 ? "var(--status-verified)" : t.conf >= 50 ? "var(--status-caution)" : "var(--status-critical)"
          }
        }, t.conf, "%")
      }, {
        key: "seen",
        label: "Last seen",
        numeric: true
      }, {
        key: "state",
        label: "",
        align: "right",
        render: t => /*#__PURE__*/React.createElement(Badge, {
          tone: t.state === "verified" ? "verified" : t.state === "conflict" ? "critical" : "caution"
        }, t.state === "verified" ? "OK" : t.state === "conflict" ? "Conflict" : "Single src")
      }],
      rows: TARGETS,
      footer: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
        style: {
          flex: 1
        }
      }, "Showing 6 of 4,218 \xB7 abbreviated for the kit"), /*#__PURE__*/React.createElement(Button, {
        size: "sm",
        variant: "secondary"
      }, "Next"))
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 18
      }
    }, /*#__PURE__*/React.createElement(Card, {
      style: {
        flex: 1
      },
      label: "Feed health",
      title: "9 registered sources",
      flushBody: true
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        padding: "4px 16px 12px"
      }
    }, FEEDS.map(f => /*#__PURE__*/React.createElement("div", {
      key: f.name,
      style: {
        display: "flex",
        alignItems: "center",
        gap: 12,
        height: "var(--row-height-tight)",
        borderBottom: "1px solid var(--border-subtle)"
      }
    }, /*#__PURE__*/React.createElement(StatusDot, {
      state: f.state
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        flex: 1,
        font: "var(--type-ui)",
        color: "var(--text-body)"
      }
    }, f.name), /*#__PURE__*/React.createElement("span", {
      className: "n-numeric",
      style: {
        font: "var(--type-data-sm)",
        color: "var(--text-faint)"
      }
    }, f.latency))))), /*#__PURE__*/React.createElement(Card, {
      style: {
        width: 300
      },
      variant: "accent",
      label: "Action required",
      title: "MLS bridge unreachable"
    }, /*#__PURE__*/React.createElement("p", {
      style: {
        font: "var(--type-body-sm)",
        color: "var(--text-muted)",
        margin: "0 0 14px"
      }
    }, "Last successful handshake 41 minutes ago. 118 targets are running on assessor data alone."), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 8
      }
    }, /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      variant: "primary",
      icon: "refresh-cw"
    }, "Retry now"), /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      variant: "ghost"
    }, "Mute 1h")))));
  }
  Object.assign(window, {
    SweepBoard,
    TARGETS,
    FEEDS
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/blackbox-console/SweepBoard.jsx", error: String((e && e.message) || e) }); }

// ui_kits/deedsonar/DeedSonarShell.jsx
try { (() => {
(() => {
  const {
    TopBar,
    IconButton,
    NavItem,
    Breadcrumbs,
    Input,
    Button,
    StatusDot
  } = window.NeuruhDesignSystem_5cb7e4;
  function DeedSonarShell({
    view,
    onView,
    crumbs,
    saved,
    children
  }) {
    return /*#__PURE__*/React.createElement("div", {
      "data-surface": "light",
      style: {
        display: "flex",
        flexDirection: "column",
        height: "100%",
        background: "var(--bg-sunken)"
      }
    }, /*#__PURE__*/React.createElement(TopBar, {
      product: "DeedSonar",
      right: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(StatusDot, {
        state: "verified",
        label: "SDAT current"
      }), /*#__PURE__*/React.createElement("span", {
        style: {
          width: 4
        }
      }), /*#__PURE__*/React.createElement(Button, {
        size: "sm",
        variant: "secondary",
        icon: "download"
      }, "Report"), /*#__PURE__*/React.createElement(IconButton, {
        icon: "bell",
        size: "sm",
        label: "Alerts"
      }), /*#__PURE__*/React.createElement("span", {
        style: {
          width: 26,
          height: 26,
          borderRadius: "var(--radius-pill)",
          background: "var(--ink-800)",
          color: "var(--paper-050)",
          display: "grid",
          placeItems: "center",
          font: "var(--type-data-sm)"
        }
      }, "JB"))
    }, /*#__PURE__*/React.createElement(Breadcrumbs, {
      items: crumbs
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        flex: 1,
        minHeight: 0
      }
    }, /*#__PURE__*/React.createElement("nav", {
      className: "n-nav",
      style: {
        width: "var(--rail-sidebar)",
        flex: "none",
        padding: "0 8px 8px",
        borderRight: "1px solid var(--border-default)",
        background: "var(--bg-surface)",
        overflow: "auto"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        padding: "10px 4px 4px"
      }
    }, /*#__PURE__*/React.createElement(Input, {
      icon: "search",
      placeholder: "Parcel, owner, deed"
    })), /*#__PURE__*/React.createElement("div", {
      className: "n-nav__group"
    }, "Research"), /*#__PURE__*/React.createElement(NavItem, {
      icon: "scan-line",
      label: "Parcel explorer",
      meta: "4.2k",
      active: view === "explore",
      onClick: () => onView("explore")
    }), /*#__PURE__*/React.createElement(NavItem, {
      icon: "git-branch",
      label: "Title chains",
      meta: "318",
      active: view === "record",
      onClick: () => onView("record")
    }), /*#__PURE__*/React.createElement(NavItem, {
      icon: "triangle-alert",
      label: "Clouds & liens",
      meta: "27"
    }), /*#__PURE__*/React.createElement(NavItem, {
      icon: "file-text",
      label: "Reports",
      meta: "14"
    }), /*#__PURE__*/React.createElement("div", {
      className: "n-nav__group"
    }, "Saved searches"), saved.map(s => /*#__PURE__*/React.createElement(NavItem, {
      key: s.label,
      icon: "funnel",
      label: s.label,
      meta: s.count
    })), /*#__PURE__*/React.createElement("div", {
      className: "n-nav__group"
    }, "Jurisdictions"), [["Wicomico, MD", "1,842"], ["Worcester, MD", "1,506"], ["Somerset, MD", "870"]].map(([l, c]) => /*#__PURE__*/React.createElement(NavItem, {
      key: l,
      icon: "map-pin",
      label: l,
      meta: c
    }))), /*#__PURE__*/React.createElement("main", {
      style: {
        flex: 1,
        minWidth: 0,
        overflow: "auto"
      }
    }, children)));
  }
  Object.assign(window, {
    DeedSonarShell
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/deedsonar/DeedSonarShell.jsx", error: String((e && e.message) || e) }); }

// ui_kits/deedsonar/ParcelExplorer.jsx
try { (() => {
(() => {
  const {
    Card,
    Tag,
    Select,
    Button,
    IconButton,
    Badge,
    Stat,
    Tabs,
    Input,
    DataTable,
    EmptyState
  } = window.NeuruhDesignSystem_5cb7e4;
  const RESULTS = [{
    id: "04-118-227",
    owner: "Martin, R & K",
    addr: "3114 Nanticoke Rd",
    city: "Salisbury",
    assessed: "$284,100",
    acres: "0.41",
    last: "2019",
    flag: "conflict"
  }, {
    id: "04-118-231",
    owner: "Holloway Trust",
    addr: "3120 Nanticoke Rd",
    city: "Salisbury",
    assessed: "$196,400",
    acres: "0.33",
    last: "2011",
    flag: "clean"
  }, {
    id: "07-402-009",
    owner: "Parsons, D",
    addr: "812 Bay St",
    city: "Berlin",
    assessed: "$412,900",
    acres: "0.62",
    last: "2022",
    flag: "lien"
  }, {
    id: "07-402-114",
    owner: "Chesapeake Holdings LLC",
    addr: "44 Commerce Way",
    city: "Berlin",
    assessed: "$1,140,000",
    acres: "2.10",
    last: "2024",
    flag: "clean"
  }, {
    id: "11-006-882",
    owner: "Redden, A & J",
    addr: "9 Tull Rd",
    city: "Princess Anne",
    assessed: "$88,700",
    acres: "1.02",
    last: "2004",
    flag: "conflict"
  }, {
    id: "11-006-903",
    owner: "Estate of W. Tull",
    addr: "17 Tull Rd",
    city: "Princess Anne",
    assessed: "$134,250",
    acres: "0.88",
    last: "1998",
    flag: "probate"
  }];
  const FLAG = {
    clean: ["verified", "Clean"],
    conflict: ["critical", "Owner conflict"],
    lien: ["caution", "Lien"],
    probate: ["caution", "Probate"]
  };
  function ParcelExplorer({
    onOpen
  }) {
    const [filters, setFilters] = React.useState(["Lower Eastern Shore", "Assessed $50k–$1.5M", "Last conveyance > 3y"]);
    const [layout, setLayout] = React.useState("split");
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        flexDirection: "column",
        minHeight: "100%"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        padding: "18px 24px 0"
      }
    }, /*#__PURE__*/React.createElement("span", {
      className: "n-label"
    }, "Parcel explorer"), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "flex-end",
        gap: 16,
        marginTop: 6
      }
    }, /*#__PURE__*/React.createElement("h1", {
      style: {
        font: "var(--type-h1)",
        letterSpacing: "var(--tracking-tight)",
        color: "var(--text-primary)",
        margin: 0,
        flex: 1,
        whiteSpace: "nowrap"
      }
    }, "4,218 parcels match"), /*#__PURE__*/React.createElement(Select, {
      options: ["Sort: Conflict severity", "Sort: Assessed value", "Sort: Last conveyance"]
    }), /*#__PURE__*/React.createElement(Tabs, {
      variant: "enclosed",
      value: layout,
      onChange: setLayout,
      items: [{
        id: "split",
        label: "Split"
      }, {
        id: "table",
        label: "Table"
      }]
    }), /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      icon: "file-text"
    }, "Generate report")), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 8,
        flexWrap: "wrap",
        padding: "16px 0"
      }
    }, filters.map(f => /*#__PURE__*/React.createElement(Tag, {
      key: f,
      icon: "funnel",
      onRemove: () => setFilters(filters.filter(x => x !== f))
    }, f)), /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      variant: "ghost",
      icon: "plus"
    }, "Add filter"))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 18,
        padding: "0 24px 24px",
        flex: 1,
        minHeight: 0
      }
    }, layout === "split" ? /*#__PURE__*/React.createElement(Card, {
      style: {
        width: 420,
        flex: "none",
        alignSelf: "flex-start",
        position: "sticky",
        top: 0
      },
      flushBody: true,
      label: "Map surface",
      title: "Wicomico \xB7 Worcester \xB7 Somerset",
      actions: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(IconButton, {
        icon: "layers",
        size: "sm",
        label: "Layers"
      }), /*#__PURE__*/React.createElement(IconButton, {
        icon: "crosshair",
        size: "sm",
        label: "Recenter"
      }))
    }, /*#__PURE__*/React.createElement("div", {
      className: "n-tex n-tex--grid",
      style: {
        height: 400,
        background: "var(--bg-inset)",
        borderTop: "1px solid var(--border-default)"
      }
    }, /*#__PURE__*/React.createElement(EmptyState, {
      variant: "unavailable",
      icon: "map-pin",
      label: "Awaiting tile provider",
      title: "Basemap not connected",
      actions: /*#__PURE__*/React.createElement(Button, {
        size: "sm",
        variant: "secondary",
        icon: "link-2"
      }, "Connect source")
    }, "No tile provider, map style, or parcel-geometry source was specified in the design package. Styling targets are ready in ", /*#__PURE__*/React.createElement("code", {
      style: {
        font: "var(--type-data-sm)"
      }
    }, "--map-*"), ".")), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 24,
        padding: "14px 16px",
        borderTop: "1px solid var(--border-default)"
      }
    }, /*#__PURE__*/React.createElement(Stat, {
      size: "sm",
      label: "In view",
      value: "4,218"
    }), /*#__PURE__*/React.createElement(Stat, {
      size: "sm",
      label: "Flagged",
      value: "27"
    }), /*#__PURE__*/React.createElement(Stat, {
      size: "sm",
      label: "Median",
      value: "$214k"
    }))) : null, /*#__PURE__*/React.createElement(Card, {
      style: {
        flex: 1,
        minWidth: 0
      },
      flushBody: true,
      label: "Results",
      title: "Ranked by title risk",
      actions: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Input, {
        icon: "search",
        placeholder: "Filter results",
        style: {
          width: 180
        }
      }), /*#__PURE__*/React.createElement(IconButton, {
        icon: "download",
        size: "sm",
        label: "Export CSV"
      }))
    }, /*#__PURE__*/React.createElement(DataTable, {
      density: "loose",
      maxHeight: 392,
      onSelect: onOpen,
      flaggedKeys: RESULTS.filter(r => r.flag !== "clean").map(r => r.id),
      columns: [{
        key: "id",
        label: "Parcel",
        mono: true,
        sortable: true
      }, {
        key: "owner",
        label: "Owner of record",
        primary: true
      }, {
        key: "addr",
        label: "Situs",
        render: r => /*#__PURE__*/React.createElement(React.Fragment, null, r.addr, /*#__PURE__*/React.createElement("span", {
          style: {
            color: "var(--text-faint)"
          }
        }, " \xB7 ", r.city))
      }, {
        key: "assessed",
        label: "Assessed",
        align: "right",
        numeric: true,
        sortable: true
      }, {
        key: "acres",
        label: "Acres",
        align: "right",
        numeric: true
      }, {
        key: "last",
        label: "Last conveyance",
        numeric: true,
        sortable: true
      }, {
        key: "flag",
        label: "Title status",
        render: r => {
          const [tone, text] = FLAG[r.flag];
          return /*#__PURE__*/React.createElement(Badge, {
            tone: tone
          }, text);
        }
      }],
      rows: RESULTS,
      footer: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
        style: {
          flex: 1
        }
      }, "Showing 6 of 4,218 \xB7 abbreviated for the kit"), /*#__PURE__*/React.createElement(Button, {
        size: "sm",
        variant: "secondary"
      }, "Previous"), /*#__PURE__*/React.createElement(Button, {
        size: "sm",
        variant: "secondary"
      }, "Next"))
    }))));
  }
  Object.assign(window, {
    ParcelExplorer,
    RESULTS
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/deedsonar/ParcelExplorer.jsx", error: String((e && e.message) || e) }); }

// ui_kits/deedsonar/TitleChain.jsx
try { (() => {
(() => {
  const {
    Card,
    Tabs,
    Badge,
    Button,
    EvidenceChip,
    ConfidenceMeter,
    Stat,
    EmptyState,
    DataTable
  } = window.NeuruhDesignSystem_5cb7e4;
  const CHAIN = [{
    year: "2019",
    instr: "DEED 2019-4412",
    from: "Whaley, T",
    to: "Martin, R & K",
    price: "$212,000",
    state: "conflict"
  }, {
    year: "2004",
    instr: "DEED 2004-0918",
    from: "Whaley Family Trust",
    to: "Whaley, T",
    price: "—",
    state: "verified"
  }, {
    year: "1996",
    instr: "DEED 1996-2210",
    from: "Nanticoke Land Co",
    to: "Whaley Family Trust",
    price: "$84,500",
    state: "verified"
  }, {
    year: "1981",
    instr: "DEED 1981-0774",
    from: "Bounds, E",
    to: "Nanticoke Land Co",
    price: "$31,000",
    state: "verified"
  }, {
    year: "1974",
    instr: "PLAT 1974-014",
    from: "—",
    to: "Bounds, E",
    price: "—",
    state: "unverified"
  }];
  const LIENS = [{
    type: "Judgment",
    holder: "Peninsula Regional",
    amount: "$14,208",
    filed: "2021-06-14",
    state: "critical"
  }, {
    type: "Tax",
    holder: "Wicomico County",
    amount: "$1,940",
    filed: "2025-01-12",
    state: "caution"
  }];
  function TitleChain({
    id,
    onBack,
    onProvenance
  }) {
    const [tab, setTab] = React.useState("chain");
    return /*#__PURE__*/React.createElement("div", {
      style: {
        padding: "18px 24px 32px",
        display: "flex",
        flexDirection: "column",
        gap: 18,
        maxWidth: 1120
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "flex-start",
        gap: 16
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 10
      }
    }, /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      variant: "ghost",
      icon: "arrow-right",
      onClick: onBack,
      style: {
        transform: "scaleX(-1)"
      }
    }), /*#__PURE__*/React.createElement("span", {
      className: "n-label"
    }, "Record \xB7 ", id)), /*#__PURE__*/React.createElement("h1", {
      style: {
        font: "var(--type-h1)",
        letterSpacing: "var(--tracking-tight)",
        color: "var(--text-primary)",
        margin: "6px 0 6px"
      }
    }, "Martin, R & K"), /*#__PURE__*/React.createElement("div", {
      style: {
        font: "var(--type-body)",
        color: "var(--text-muted)"
      }
    }, "3114 Nanticoke Rd, Salisbury, MD 21801 \xB7 Wicomico County"), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 8,
        marginTop: 12,
        flexWrap: "wrap"
      }
    }, /*#__PURE__*/React.createElement(EvidenceChip, {
      state: "verified",
      source: "SDAT",
      id: id,
      onClick: onProvenance
    }), /*#__PURE__*/React.createElement(EvidenceChip, {
      state: "conflict",
      source: "Owner name disputed",
      onClick: onProvenance
    }), /*#__PURE__*/React.createElement(Badge, {
      tone: "critical"
    }, "1 judgment"), /*#__PURE__*/React.createElement(Badge, {
      tone: "caution"
    }, "Tax lien"))), /*#__PURE__*/React.createElement(Card, {
      style: {
        width: 236,
        flex: "none"
      }
    }, /*#__PURE__*/React.createElement(ConfidenceMeter, {
      value: 86,
      basis: "3 of 4 sources agree \xB7 6h old"
    }))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "repeat(4, 1fr)",
        gap: 14
      }
    }, [["Assessed value", "$284,100"], ["Acreage", "0.41"], ["Year built", "1974"], ["Conveyances", "5"]].map(([l, v]) => /*#__PURE__*/React.createElement(Card, {
      key: l,
      className: "n-tex n-tex--paper"
    }, /*#__PURE__*/React.createElement(Stat, {
      label: l,
      value: v
    })))), /*#__PURE__*/React.createElement(Card, {
      flushBody: true,
      label: "Record",
      title: /*#__PURE__*/React.createElement(Tabs, {
        value: tab,
        onChange: setTab,
        items: [{
          id: "chain",
          label: "Title chain",
          count: CHAIN.length
        }, {
          id: "liens",
          label: "Liens",
          count: LIENS.length
        }, {
          id: "tax",
          label: "Tax history"
        }]
      })
    }, tab === "chain" ? /*#__PURE__*/React.createElement("div", {
      style: {
        padding: "6px 0 0"
      }
    }, CHAIN.map((c, i) => /*#__PURE__*/React.createElement("div", {
      key: c.instr,
      style: {
        display: "grid",
        gridTemplateColumns: "72px 1fr 200px 120px 140px",
        alignItems: "center",
        gap: 16,
        padding: "14px 20px",
        borderBottom: i < CHAIN.length - 1 ? "1px solid var(--border-subtle)" : "none",
        background: c.state === "conflict" ? "var(--status-critical-wash)" : "transparent"
      }
    }, /*#__PURE__*/React.createElement("span", {
      className: "n-numeric",
      style: {
        font: "var(--type-h3)",
        fontFamily: "var(--font-mono)",
        color: "var(--text-primary)"
      }
    }, c.year), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        font: "var(--type-ui)",
        color: "var(--text-primary)"
      }
    }, c.from, " ", /*#__PURE__*/React.createElement("span", {
      style: {
        color: "var(--text-faint)"
      }
    }, "\u2192"), " ", c.to), /*#__PURE__*/React.createElement("div", {
      style: {
        font: "var(--type-data-sm)",
        color: "var(--text-faint)",
        marginTop: 3
      }
    }, c.instr)), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(EvidenceChip, {
      state: c.state,
      source: "Clerk of Court",
      id: c.instr.split(" ")[1],
      onClick: onProvenance
    })), /*#__PURE__*/React.createElement("span", {
      className: "n-numeric",
      style: {
        font: "var(--type-data)",
        color: "var(--text-body)",
        textAlign: "right"
      }
    }, c.price), /*#__PURE__*/React.createElement("div", {
      style: {
        textAlign: "right"
      }
    }, c.state === "conflict" ? /*#__PURE__*/React.createElement(Badge, {
      tone: "critical"
    }, "Name mismatch") : c.state === "unverified" ? /*#__PURE__*/React.createElement(Badge, {
      tone: "caution"
    }, "Plat only") : /*#__PURE__*/React.createElement(Badge, {
      tone: "verified"
    }, "Recorded"))))) : tab === "liens" ? /*#__PURE__*/React.createElement("div", null, LIENS.map(l => /*#__PURE__*/React.createElement("div", {
      key: l.holder,
      style: {
        display: "grid",
        gridTemplateColumns: "110px 1fr 130px 130px",
        alignItems: "center",
        gap: 16,
        padding: "16px 20px",
        borderBottom: "1px solid var(--border-subtle)"
      }
    }, /*#__PURE__*/React.createElement(Badge, {
      tone: l.state
    }, l.type), /*#__PURE__*/React.createElement("span", {
      style: {
        font: "var(--type-ui)",
        color: "var(--text-primary)"
      }
    }, l.holder), /*#__PURE__*/React.createElement("span", {
      className: "n-numeric",
      style: {
        font: "var(--type-data)",
        color: "var(--text-primary)",
        textAlign: "right"
      }
    }, l.amount), /*#__PURE__*/React.createElement("span", {
      className: "n-numeric",
      style: {
        font: "var(--type-data-sm)",
        color: "var(--text-faint)",
        textAlign: "right"
      }
    }, l.filed))), /*#__PURE__*/React.createElement("div", {
      style: {
        padding: "16px 20px",
        font: "var(--type-body-sm)",
        color: "var(--text-muted)"
      }
    }, "Encumbrance total ", /*#__PURE__*/React.createElement("span", {
      className: "n-numeric",
      style: {
        font: "var(--type-data)",
        color: "var(--text-primary)"
      }
    }, "$16,148"), " \xB7 5.7% of assessed value")) : /*#__PURE__*/React.createElement(EmptyState, {
      variant: "unavailable",
      hatched: true,
      icon: "file-text",
      label: "Not specified in source package",
      title: "No tax-history layout"
    }, "Left intentionally blank rather than invented. Supply the layout and this panel renders against the same tokens.")));
  }
  Object.assign(window, {
    TitleChain,
    CHAIN,
    LIENS
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/deedsonar/TitleChain.jsx", error: String((e && e.message) || e) }); }

// ui_kits/field-scout/CaptureSheet.jsx
try { (() => {
(() => {
  const {
    Icon,
    Badge,
    Button,
    Field,
    Select,
    Switch,
    EvidenceChip,
    KeyValue,
    Progress,
    EmptyState,
    SoundToggle
  } = window.NeuruhDesignSystem_5cb7e4;
  function CaptureSheet({
    id,
    onBack,
    onSubmit,
    online
  }) {
    const [shots, setShots] = React.useState(2);
    const [condition, setCondition] = React.useState("Fair");
    const [occupied, setOccupied] = React.useState(true);
    const [voice, setVoice] = React.useState(false);
    const target = (window.ASSIGNED || []).find(a => a.id === id) || {
      addr: "3114 Nanticoke Rd",
      city: "Salisbury"
    };
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        flexDirection: "column",
        minHeight: "100%"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 8,
        padding: "10px 12px",
        borderBottom: "1px solid var(--border-subtle)"
      }
    }, /*#__PURE__*/React.createElement(Button, {
      size: "lg",
      variant: "ghost",
      icon: "arrow-right",
      onClick: onBack,
      style: {
        transform: "scaleX(-1)",
        minWidth: 44
      }
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        font: "var(--type-data)",
        color: "var(--text-accent)"
      }
    }, id), /*#__PURE__*/React.createElement("div", {
      style: {
        font: "var(--type-body-sm)",
        color: "var(--text-muted)",
        overflow: "hidden",
        textOverflow: "ellipsis",
        whiteSpace: "nowrap"
      }
    }, target.addr)), /*#__PURE__*/React.createElement(SoundToggle, {
      on: voice,
      onChange: setVoice,
      label: "Voice note"
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        padding: "16px 16px 8px"
      }
    }, /*#__PURE__*/React.createElement("span", {
      className: "n-label"
    }, "Photo set \xB7 ", shots, " of 6"), /*#__PURE__*/React.createElement(Progress, {
      value: shots / 6 * 100,
      tone: shots >= 4 ? "verified" : "caution",
      style: {
        marginTop: 8
      }
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "repeat(3, 1fr)",
        gap: 8,
        marginTop: 12
      }
    }, ["Front elevation", "Street view", "Rear", "Outbuilding", "Damage", "Boundary"].map((label, i) => {
      const taken = i < shots;
      return /*#__PURE__*/React.createElement("button", {
        key: label,
        type: "button",
        onClick: () => setShots(Math.max(shots, i + 1)),
        className: taken ? "" : "n-hatch",
        style: {
          aspectRatio: "1",
          minHeight: 88,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          gap: 6,
          cursor: "pointer",
          background: taken ? "var(--bg-surface-raised)" : undefined,
          border: `1px solid ${taken ? "var(--border-accent)" : "var(--border-default)"}`,
          borderRadius: "var(--radius-3)",
          padding: 6
        }
      }, /*#__PURE__*/React.createElement(Icon, {
        name: taken ? "circle-check" : "scan-line",
        size: 17,
        style: {
          color: taken ? "var(--status-verified)" : "var(--text-faint)"
        }
      }), /*#__PURE__*/React.createElement("span", {
        style: {
          font: "var(--type-data-sm)",
          fontSize: 9.5,
          letterSpacing: "0.06em",
          textTransform: "uppercase",
          color: taken ? "var(--text-muted)" : "var(--text-faint)",
          textAlign: "center",
          lineHeight: 1.25
        }
      }, label));
    }))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        flexDirection: "column",
        gap: 16,
        padding: "16px"
      }
    }, /*#__PURE__*/React.createElement(Field, {
      label: "Condition",
      htmlFor: "cond"
    }, /*#__PURE__*/React.createElement(Select, {
      id: "cond",
      size: "lg",
      value: condition,
      onChange: e => setCondition(e.target.value),
      options: ["Good", "Fair", "Poor", "Uninhabitable"]
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        minHeight: 44,
        gap: 12
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        font: "var(--type-body)",
        color: "var(--text-body)"
      }
    }, "Appears occupied"), /*#__PURE__*/React.createElement(Switch, {
      checked: occupied,
      onChange: e => setOccupied(e.target.checked)
    }))), /*#__PURE__*/React.createElement("div", {
      style: {
        margin: "0 16px",
        padding: "14px 16px",
        background: "var(--bg-inset)",
        border: "1px solid var(--border-default)",
        borderRadius: "var(--radius-3)"
      }
    }, /*#__PURE__*/React.createElement("span", {
      className: "n-label"
    }, "Capture signature"), /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 10
      }
    }, /*#__PURE__*/React.createElement(KeyValue, {
      items: [{
        key: "GPS",
        value: "38.3607°N 75.5994°W"
      }, {
        key: "Accuracy",
        value: "±3.2 m"
      }, {
        key: "Heading",
        value: "214° SW"
      }, {
        key: "Captured",
        value: "2026-07-31 14:08Z"
      }, {
        key: "Device",
        value: "FS-0142"
      }]
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 12
      }
    }, /*#__PURE__*/React.createElement(EvidenceChip, {
      state: "verified",
      source: "Field capture",
      id: "FS-0142"
    }))), /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: "auto",
        padding: "16px",
        paddingTop: 20,
        position: "sticky",
        bottom: 0,
        background: "linear-gradient(to top, var(--bg-sunken) 60%, transparent)"
      }
    }, /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      size: "lg",
      block: true,
      icon: online ? "check" : "clock",
      onClick: onSubmit,
      style: {
        minHeight: 48
      }
    }, online ? "Sign and submit" : "Sign and queue"), /*#__PURE__*/React.createElement("p", {
      style: {
        font: "var(--type-body-sm)",
        color: "var(--text-faint)",
        textAlign: "center",
        margin: "10px 0 0"
      }
    }, online ? "Uploads immediately and attaches to the record." : "Stored locally and reconciled when service returns.")));
  }
  Object.assign(window, {
    CaptureSheet
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/field-scout/CaptureSheet.jsx", error: String((e && e.message) || e) }); }

// ui_kits/field-scout/ScoutShell.jsx
try { (() => {
(() => {
  const {
    Icon,
    Badge,
    StatusDot,
    Wordmark
  } = window.NeuruhDesignSystem_5cb7e4;
  const TABS = [{
    id: "targets",
    icon: "layers",
    label: "Targets",
    count: 6
  }, {
    id: "capture",
    icon: "scan-line",
    label: "Capture"
  }, {
    id: "map",
    icon: "map-pin",
    label: "Map"
  }, {
    id: "queue",
    icon: "refresh-cw",
    label: "Queue",
    count: 3
  }];
  function ScoutShell({
    tab,
    onTab,
    online,
    queued,
    title,
    children
  }) {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        flexDirection: "column",
        height: "100%",
        background: "var(--bg-sunken)",
        overflow: "hidden"
      }
    }, /*#__PURE__*/React.createElement("header", {
      style: {
        flex: "none",
        padding: "10px 16px 12px",
        background: "var(--bg-canvas)",
        borderBottom: "1px solid var(--border-default)"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 10
      }
    }, /*#__PURE__*/React.createElement(Wordmark, {
      size: "sm",
      monogram: true,
      product: "Field Scout"
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        flex: 1
      }
    }), /*#__PURE__*/React.createElement(StatusDot, {
      state: online ? "live" : "caution",
      label: online ? "Online" : "Offline",
      pulse: online
    })), /*#__PURE__*/React.createElement("h1", {
      style: {
        font: "var(--type-h2)",
        letterSpacing: "var(--tracking-tight)",
        color: "var(--text-primary)",
        margin: "12px 0 0"
      }
    }, title)), !online ? /*#__PURE__*/React.createElement("div", {
      style: {
        flex: "none",
        display: "flex",
        alignItems: "center",
        gap: 10,
        padding: "10px 16px",
        background: "var(--status-caution-wash)",
        borderBottom: "1px solid var(--border-default)"
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "triangle-alert",
      size: 15,
      style: {
        color: "var(--status-caution)",
        flex: "none"
      }
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        font: "var(--type-body-sm)",
        color: "var(--status-caution)",
        flex: 1
      }
    }, "Working offline. ", queued, " capture", queued === 1 ? "" : "s", " queued locally.")) : null, /*#__PURE__*/React.createElement("main", {
      style: {
        flex: 1,
        minHeight: 0,
        overflow: "auto",
        WebkitOverflowScrolling: "touch"
      }
    }, children), /*#__PURE__*/React.createElement("nav", {
      style: {
        flex: "none",
        display: "grid",
        gridTemplateColumns: `repeat(${TABS.length}, 1fr)`,
        background: "var(--bg-canvas)",
        borderTop: "1px solid var(--border-default)",
        paddingBottom: 4
      }
    }, TABS.map(t => {
      const active = tab === t.id;
      return /*#__PURE__*/React.createElement("button", {
        key: t.id,
        type: "button",
        onClick: () => onTab(t.id),
        style: {
          position: "relative",
          minHeight: 56,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          gap: 4,
          background: "none",
          border: 0,
          cursor: "pointer",
          color: active ? "var(--text-accent)" : "var(--text-faint)",
          transition: "color var(--dur-fast) var(--ease-standard)"
        }
      }, active ? /*#__PURE__*/React.createElement("span", {
        style: {
          position: "absolute",
          top: 0,
          left: 12,
          right: 12,
          height: 2,
          background: "var(--accent-solid)"
        }
      }) : null, /*#__PURE__*/React.createElement("span", {
        style: {
          position: "relative"
        }
      }, /*#__PURE__*/React.createElement(Icon, {
        name: t.icon,
        size: 20
      }), t.count ? /*#__PURE__*/React.createElement("span", {
        style: {
          position: "absolute",
          top: -4,
          right: -9,
          minWidth: 15,
          height: 15,
          padding: "0 3px",
          display: "grid",
          placeItems: "center",
          borderRadius: 99,
          background: "var(--accent-solid)",
          font: "var(--type-data-sm)",
          fontSize: 9,
          color: "var(--text-on-accent)"
        }
      }, t.count) : null), /*#__PURE__*/React.createElement("span", {
        style: {
          font: "var(--type-data-sm)",
          fontSize: 10,
          letterSpacing: "0.06em"
        }
      }, t.label));
    })));
  }
  Object.assign(window, {
    ScoutShell,
    SCOUT_TABS: TABS
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/field-scout/ScoutShell.jsx", error: String((e && e.message) || e) }); }

// ui_kits/field-scout/SweepList.jsx
try { (() => {
(() => {
  const {
    Icon,
    Badge,
    Button,
    EvidenceChip,
    EmptyState,
    Card
  } = window.NeuruhDesignSystem_5cb7e4;
  const ASSIGNED = [{
    id: "04-118-227",
    addr: "3114 Nanticoke Rd",
    city: "Salisbury",
    dist: "0.4 mi",
    state: "conflict",
    sync: "queued",
    task: "Verify occupancy"
  }, {
    id: "04-118-231",
    addr: "3120 Nanticoke Rd",
    city: "Salisbury",
    dist: "0.4 mi",
    state: "clean",
    sync: "synced",
    task: "Photo set"
  }, {
    id: "07-402-009",
    addr: "812 Bay St",
    city: "Berlin",
    dist: "11.2 mi",
    state: "lien",
    sync: "pending",
    task: "Condition report"
  }, {
    id: "07-402-114",
    addr: "44 Commerce Way",
    city: "Berlin",
    dist: "11.8 mi",
    state: "clean",
    sync: "pending",
    task: "Boundary photos"
  }, {
    id: "11-006-882",
    addr: "9 Tull Rd",
    city: "Princess Anne",
    dist: "24.6 mi",
    state: "conflict",
    sync: "pending",
    task: "Owner contact"
  }, {
    id: "11-006-903",
    addr: "17 Tull Rd",
    city: "Princess Anne",
    dist: "24.7 mi",
    state: "probate",
    sync: "pending",
    task: "Verify occupancy"
  }];
  const FLAG = {
    clean: ["verified", "Clean"],
    conflict: ["critical", "Conflict"],
    lien: ["caution", "Lien"],
    probate: ["caution", "Probate"]
  };
  const SYNC = {
    synced: ["verified", "circle-check", "Synced"],
    queued: ["caution", "clock", "Queued"],
    pending: ["neutral", "circle-alert", "Not captured"]
  };
  function SweepList({
    onOpen,
    filter
  }) {
    const rows = filter === "all" ? ASSIGNED : ASSIGNED.filter(r => r.sync !== "synced");
    if (!rows.length) {
      return /*#__PURE__*/React.createElement(EmptyState, {
        icon: "circle-check",
        title: "Route complete"
      }, "Every assigned target has been captured and synced.");
    }
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        flexDirection: "column",
        gap: 10,
        padding: "14px 12px 24px"
      }
    }, rows.map(r => {
      const [tone, text] = FLAG[r.state];
      const [sTone, sIcon, sText] = SYNC[r.sync];
      return /*#__PURE__*/React.createElement("button", {
        key: r.id,
        type: "button",
        onClick: () => onOpen(r.id),
        style: {
          display: "flex",
          flexDirection: "column",
          gap: 10,
          textAlign: "left",
          width: "100%",
          minHeight: 88,
          padding: "14px 16px",
          cursor: "pointer",
          background: "var(--bg-surface)",
          backgroundImage: "var(--sheen-panel)",
          border: "1px solid var(--border-default)",
          borderLeft: `2px solid ${r.state === "clean" ? "transparent" : "var(--status-" + (tone === "critical" ? "critical" : "caution") + ")"}`,
          borderRadius: "var(--radius-3)",
          boxShadow: "var(--elevation-card)"
        }
      }, /*#__PURE__*/React.createElement("div", {
        style: {
          display: "flex",
          alignItems: "flex-start",
          gap: 12
        }
      }, /*#__PURE__*/React.createElement("div", {
        style: {
          flex: 1,
          minWidth: 0
        }
      }, /*#__PURE__*/React.createElement("div", {
        style: {
          font: "var(--type-data)",
          color: "var(--text-accent)"
        }
      }, r.id), /*#__PURE__*/React.createElement("div", {
        style: {
          font: "var(--type-body)",
          color: "var(--text-primary)",
          marginTop: 4
        }
      }, r.addr), /*#__PURE__*/React.createElement("div", {
        style: {
          font: "var(--type-body-sm)",
          color: "var(--text-faint)",
          marginTop: 2
        }
      }, r.city, " \xB7 ", r.dist)), /*#__PURE__*/React.createElement(Badge, {
        tone: tone
      }, text)), /*#__PURE__*/React.createElement("div", {
        style: {
          display: "flex",
          alignItems: "center",
          gap: 10,
          paddingTop: 10,
          borderTop: "1px solid var(--border-subtle)"
        }
      }, /*#__PURE__*/React.createElement(Icon, {
        name: "crosshair",
        size: 13,
        style: {
          color: "var(--text-faint)"
        }
      }), /*#__PURE__*/React.createElement("span", {
        style: {
          font: "var(--type-body-sm)",
          color: "var(--text-muted)",
          flex: 1
        }
      }, r.task), /*#__PURE__*/React.createElement("span", {
        style: {
          display: "inline-flex",
          alignItems: "center",
          gap: 5,
          font: "var(--type-data-sm)",
          color: `var(--status-${sTone === "neutral" ? "inert" : sTone})`
        }
      }, /*#__PURE__*/React.createElement(Icon, {
        name: sIcon,
        size: 12
      }), sText)));
    }));
  }
  Object.assign(window, {
    SweepList,
    ASSIGNED
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/field-scout/SweepList.jsx", error: String((e && e.message) || e) }); }

// ui_kits/find-sell-profit/FSPShell.jsx
try { (() => {
(() => {
  const {
    TopBar,
    NavItem,
    Breadcrumbs,
    Wordmark,
    Button,
    IconButton,
    Input,
    StatusDot,
    Badge
  } = window.NeuruhDesignSystem_5cb7e4;
  const NAV = [{
    group: "Scan",
    items: [["scan", "scan-line", "New scan", null], ["queue", "radar", "Queue", "3"]]
  }, {
    group: "Portfolio",
    items: [["board", "layers", "Inventory", "148"], ["sold", "trending-up", "Sold", null], ["stalled", "circle-alert", "Stalled", "12"]]
  }, {
    group: "Account",
    items: [["usage", "gauge", "Usage", null], ["settings", "settings", "Settings", null]]
  }];

  /**
   * FSP runs on the light spine — it is an all-day working tool, same rule as
   * DeedSonar. The scanner's live agent pipeline is the one dark island.
   */
  function FSPShell({
    view,
    onView,
    crumbs,
    credits,
    children
  }) {
    return /*#__PURE__*/React.createElement("div", {
      "data-surface": "light",
      style: {
        display: "flex",
        flexDirection: "column",
        height: "100%",
        background: "var(--bg-sunken)"
      }
    }, /*#__PURE__*/React.createElement(TopBar, {
      product: "Find Sell Profit",
      monogram: true,
      left: /*#__PURE__*/React.createElement(IconButton, {
        icon: "panel-left",
        label: "Toggle rail"
      }),
      right: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Badge, {
        tone: "accent",
        icon: "zap"
      }, credits, " scans left"), /*#__PURE__*/React.createElement(Input, {
        icon: "search",
        placeholder: "SKU, UPC, title",
        style: {
          width: 220
        }
      }), /*#__PURE__*/React.createElement(IconButton, {
        icon: "bell",
        label: "Alerts"
      }))
    }, /*#__PURE__*/React.createElement(Breadcrumbs, {
      items: crumbs
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        display: "flex",
        minHeight: 0
      }
    }, /*#__PURE__*/React.createElement("nav", {
      className: "n-nav",
      style: {
        width: "var(--rail-sidebar)",
        flex: "none",
        padding: "0 8px 8px",
        borderRight: "1px solid var(--border-default)",
        background: "var(--bg-surface)",
        overflow: "auto"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        padding: "12px 4px 8px"
      }
    }, /*#__PURE__*/React.createElement(Button, {
      variant: "command",
      icon: "scan-line",
      block: true,
      onClick: () => onView("scan")
    }, "Scan an item")), NAV.map(g => /*#__PURE__*/React.createElement(React.Fragment, {
      key: g.group
    }, /*#__PURE__*/React.createElement("div", {
      className: "n-nav__group"
    }, g.group), g.items.map(([id, icon, label, meta]) => /*#__PURE__*/React.createElement(NavItem, {
      key: id,
      icon: icon,
      label: label,
      meta: meta,
      active: view === id,
      onClick: () => onView(id)
    })))), /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 16,
        padding: "10px 12px",
        border: "1px solid var(--border-default)",
        borderRadius: "var(--radius-3)",
        background: "var(--bg-inset)",
        display: "flex",
        flexDirection: "column",
        gap: 6
      }
    }, /*#__PURE__*/React.createElement("span", {
      className: "n-label"
    }, "Plan"), /*#__PURE__*/React.createElement("span", {
      style: {
        font: "var(--type-ui)",
        color: "var(--text-primary)"
      }
    }, "Operator \xB7 monthly"), /*#__PURE__*/React.createElement("a", {
      href: "#",
      style: {
        font: "var(--type-data-sm)"
      }
    }, "Manage billing"))), /*#__PURE__*/React.createElement("main", {
      style: {
        flex: 1,
        minWidth: 0,
        overflow: "auto",
        background: "var(--bg-canvas)"
      }
    }, children)));
  }
  Object.assign(window, {
    FSPShell
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/find-sell-profit/FSPShell.jsx", error: String((e && e.message) || e) }); }

// ui_kits/find-sell-profit/OpportunityBoard.jsx
try { (() => {
(() => {
  const {
    Card,
    DataTable,
    Badge,
    Button,
    Stat,
    Sparkline,
    Tabs,
    Tag,
    EmptyState
  } = window.NeuruhDesignSystem_5cb7e4;
  const ROWS = [{
    sku: "FSP-1042",
    item: "Sony WH-1000XM4",
    cost: 62,
    ask: 148,
    net: 61,
    age: 3,
    conf: 0.86,
    state: "Listed",
    trend: [131, 138, 134, 142, 151, 147, 144, 155, 149, 146, 152, 148]
  }, {
    sku: "FSP-1039",
    item: "Dyson V8 Animal",
    cost: 95,
    ask: 219,
    net: 88,
    age: 11,
    conf: 0.79,
    state: "Listed",
    trend: [204, 211, 208, 215, 222, 219, 214, 221, 218, 216, 220, 219]
  }, {
    sku: "FSP-1031",
    item: "Nintendo Switch OLED",
    cost: 178,
    ask: 244,
    net: 39,
    age: 26,
    conf: 0.62,
    state: "Stalled",
    trend: [268, 261, 257, 252, 249, 251, 246, 244, 241, 243, 240, 244]
  }, {
    sku: "FSP-1028",
    item: "Patagonia Nano Puff · M",
    cost: 24,
    ask: 92,
    net: 51,
    age: 5,
    conf: 0.91,
    state: "Listed",
    trend: [84, 86, 88, 87, 90, 92, 91, 93, 92, 94, 92, 92]
  }, {
    sku: "FSP-1019",
    item: "KitchenAid Artisan 5qt",
    cost: 110,
    ask: 232,
    net: 79,
    age: 41,
    conf: 0.55,
    state: "Stalled",
    trend: [259, 254, 248, 244, 239, 241, 236, 234, 236, 233, 231, 232]
  }, {
    sku: "FSP-1007",
    item: "Canon EF 50mm f/1.8",
    cost: 41,
    ask: 96,
    net: 38,
    age: 2,
    conf: 0.88,
    state: "Listed",
    trend: [92, 94, 93, 95, 97, 96, 95, 98, 96, 97, 95, 96]
  }];
  const money = n => "$" + n.toFixed(0);
  function OpportunityBoard({
    selected,
    onSelect
  }) {
    const [tab, setTab] = React.useState("all");
    const rows = tab === "stalled" ? ROWS.filter(r => r.state === "Stalled") : ROWS;
    const columns = [{
      key: "sku",
      label: "SKU",
      mono: true,
      width: 96
    }, {
      key: "item",
      label: "Item",
      primary: true,
      sortable: true
    }, {
      key: "cost",
      label: "Cost",
      numeric: true,
      render: r => money(r.cost)
    }, {
      key: "ask",
      label: "Ask",
      numeric: true,
      render: r => money(r.ask)
    }, {
      key: "net",
      label: "Net",
      numeric: true,
      sortable: true,
      render: r => /*#__PURE__*/React.createElement("span", {
        style: {
          color: r.net >= 50 ? "var(--status-verified)" : "var(--text-body)",
          fontWeight: 600
        }
      }, money(r.net))
    }, {
      key: "trend",
      label: "90-day median",
      width: 120,
      render: r => /*#__PURE__*/React.createElement(Sparkline, {
        values: r.trend,
        width: 104,
        height: 22,
        tone: r.trend[11] >= r.trend[0] ? "verified" : "caution"
      })
    }, {
      key: "age",
      label: "Days",
      numeric: true,
      render: r => /*#__PURE__*/React.createElement("span", {
        style: {
          color: r.age > 21 ? "var(--status-caution)" : "var(--text-body)"
        }
      }, r.age)
    }, {
      key: "conf",
      label: "Conf.",
      numeric: true,
      render: r => Math.round(r.conf * 100) + "%"
    }, {
      key: "state",
      label: "State",
      render: r => /*#__PURE__*/React.createElement(Badge, {
        tone: r.state === "Stalled" ? "caution" : "neutral"
      }, r.state)
    }];
    return /*#__PURE__*/React.createElement("div", {
      style: {
        padding: 24,
        display: "flex",
        flexDirection: "column",
        gap: 20
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "repeat(4, 1fr)",
        gap: 16
      }
    }, /*#__PURE__*/React.createElement(Card, {
      variant: "inset"
    }, /*#__PURE__*/React.createElement(Stat, {
      label: "Capital deployed",
      value: "$8,412",
      foot: "148 units held"
    })), /*#__PURE__*/React.createElement(Card, {
      variant: "inset"
    }, /*#__PURE__*/React.createElement(Stat, {
      label: "Projected net",
      value: "$4,190",
      delta: "+12%",
      deltaDirection: "up",
      foot: "at current asks"
    })), /*#__PURE__*/React.createElement(Card, {
      variant: "inset"
    }, /*#__PURE__*/React.createElement(Stat, {
      label: "Median days held",
      value: "14",
      foot: "target \u2264 21"
    })), /*#__PURE__*/React.createElement(Card, {
      variant: "inset"
    }, /*#__PURE__*/React.createElement(Stat, {
      label: "Stalled capital",
      value: "$1,908",
      delta: "12 units",
      deltaDirection: "flat",
      foot: "over 21 days"
    }))), /*#__PURE__*/React.createElement(Card, {
      label: "Inventory",
      title: "Held units",
      flushBody: true,
      actions: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Tabs, {
        value: tab,
        onChange: setTab,
        items: [{
          id: "all",
          label: "All",
          count: ROWS.length
        }, {
          id: "stalled",
          label: "Stalled",
          count: 2
        }]
      }), /*#__PURE__*/React.createElement(Button, {
        variant: "secondary",
        icon: "download",
        size: "sm"
      }, "Export")),
      footer: /*#__PURE__*/React.createElement("span", {
        style: {
          font: "var(--type-data-sm)",
          color: "var(--text-faint)"
        }
      }, "Comps refreshed 14 minutes ago \xB7 eBay, Mercari, Poshmark")
    }, rows.length ? /*#__PURE__*/React.createElement(DataTable, {
      columns: columns,
      rows: rows,
      rowKey: "sku",
      density: "default",
      selectedKey: selected,
      onSelect: onSelect,
      flaggedKeys: ROWS.filter(r => r.state === "Stalled").map(r => r.sku)
    }) : /*#__PURE__*/React.createElement(EmptyState, {
      icon: "layers",
      title: "Nothing stalled"
    }, "Every held unit is inside the 21-day target.")));
  }
  Object.assign(window, {
    OpportunityBoard
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/find-sell-profit/OpportunityBoard.jsx", error: String((e && e.message) || e) }); }

// ui_kits/find-sell-profit/ScanPipeline.jsx
try { (() => {
(() => {
  const {
    Card,
    Badge,
    Button,
    Icon,
    Progress,
    StatusDot,
    Stat,
    ConfidenceMeter,
    EvidenceChip,
    KeyValue,
    EmptyState,
    Sparkline
  } = window.NeuruhDesignSystem_5cb7e4;

  /* The seven agents, in pipeline order. Each one states what it decided and
     what it decided it from — an agent that reports only a verdict is a
     black box, and FSP sells the opposite. */
  const AGENTS = [{
    id: "identify",
    icon: "scan-line",
    name: "Product identification",
    says: "Sony WH-1000XM4 · black · 2020",
    basis: "UPC 027242920200 · image match 0.94"
  }, {
    id: "market",
    icon: "globe",
    name: "Market research",
    says: "412 comps in 90 days",
    basis: "eBay sold · Mercari · Poshmark"
  }, {
    id: "price",
    icon: "trending-up",
    name: "Price comparison",
    says: "Median sold $148",
    basis: "IQR $131–$164 · n=412"
  }, {
    id: "profit",
    icon: "gauge",
    name: "Profit calculation",
    says: "$61 net at $148",
    basis: "cost $62 · fees $19 · ship $6"
  }, {
    id: "condition",
    icon: "eye",
    name: "Condition assessment",
    says: "Used — good",
    basis: "3 photos · earpad wear flagged"
  }, {
    id: "platform",
    icon: "signal",
    name: "Platform recommendation",
    says: "eBay auction, 7-day",
    basis: "sell-through 71% vs 44%"
  }, {
    id: "listing",
    icon: "file-text",
    name: "Listing optimization",
    says: "Title + 9 item specifics",
    basis: "top-quartile comp structure"
  }];
  function AgentRow({
    agent,
    state
  }) {
    const tone = state === "done" ? "verified" : state === "running" ? "live" : "inert";
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 12,
        alignItems: "flex-start",
        padding: "11px 14px",
        borderBottom: "1px solid var(--border-subtle)",
        opacity: state === "idle" ? 0.45 : 1,
        transition: "opacity var(--dur-fast) var(--ease-standard)"
      }
    }, /*#__PURE__*/React.createElement(StatusDot, {
      state: tone,
      pulse: state === "running"
    }), /*#__PURE__*/React.createElement(Icon, {
      name: agent.icon,
      size: 16,
      style: {
        color: state === "done" ? "var(--text-accent)" : "var(--text-faint)",
        marginTop: 1
      }
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        font: "var(--type-ui)",
        color: "var(--text-primary)"
      }
    }, agent.name), state === "done" ? /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        flexWrap: "wrap",
        gap: "2px 10px",
        marginTop: 3
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        font: "var(--type-data)",
        color: "var(--text-body)"
      }
    }, agent.says), /*#__PURE__*/React.createElement("span", {
      style: {
        font: "var(--type-data-sm)",
        color: "var(--text-faint)"
      }
    }, agent.basis)) : /*#__PURE__*/React.createElement("div", {
      style: {
        font: "var(--type-data-sm)",
        color: "var(--text-faint)",
        marginTop: 3
      }
    }, state === "running" ? "working…" : "queued")));
  }
  function ScanPipeline({
    running,
    step,
    onRun,
    onReset
  }) {
    const done = step >= AGENTS.length;
    return /*#__PURE__*/React.createElement("div", {
      style: {
        padding: 24,
        display: "grid",
        gridTemplateColumns: "1.35fr 1fr",
        gap: 20,
        alignItems: "start"
      }
    }, /*#__PURE__*/React.createElement("div", {
      "data-surface": "dark",
      style: {
        borderRadius: "var(--radius-4)",
        border: "1px solid var(--border-default)",
        overflow: "hidden",
        boxShadow: "var(--elevation-card)"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 12,
        padding: "12px 14px",
        borderBottom: "1px solid var(--border-default)",
        background: "var(--bg-surface)"
      }
    }, /*#__PURE__*/React.createElement("span", {
      className: "n-label"
    }, "Scanner \xB7 7 agents"), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1
      }
    }), running ? /*#__PURE__*/React.createElement(Badge, {
      tone: "accent"
    }, "Agent ", Math.min(step + 1, AGENTS.length), " of ", AGENTS.length) : done ? /*#__PURE__*/React.createElement(Badge, {
      tone: "verified",
      icon: "check"
    }, "Complete") : /*#__PURE__*/React.createElement(Badge, {
      tone: "neutral"
    }, "Idle")), running || done ? /*#__PURE__*/React.createElement(Progress, {
      value: Math.round(Math.min(step, AGENTS.length) / AGENTS.length * 100)
    }) : null, /*#__PURE__*/React.createElement("div", {
      style: {
        background: "var(--bg-canvas)"
      }
    }, AGENTS.map((a, i) => /*#__PURE__*/React.createElement(AgentRow, {
      key: a.id,
      agent: a,
      state: i < step ? "done" : i === step && running ? "running" : "idle"
    }))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 10,
        padding: 14,
        background: "var(--bg-surface)"
      }
    }, done ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      variant: "secondary",
      icon: "refresh-cw",
      onClick: onReset
    }, "Scan another"), /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      icon: "plus"
    }, "Add to inventory")) : /*#__PURE__*/React.createElement(Button, {
      variant: "command",
      icon: "zap",
      onClick: onRun,
      disabled: running
    }, running ? "Scanning…" : "Run scan"))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        flexDirection: "column",
        gap: 16
      }
    }, done ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Card, {
      label: "Verdict",
      title: "Buy at or below $86"
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "1fr 1fr",
        gap: 16,
        marginBottom: 14
      }
    }, /*#__PURE__*/React.createElement(Stat, {
      label: "Net profit",
      value: "$61",
      delta: "+98%",
      deltaDirection: "up",
      foot: "return on $62 cost"
    }), /*#__PURE__*/React.createElement(Stat, {
      label: "Days to sell",
      value: "9",
      foot: "median, this platform"
    })), /*#__PURE__*/React.createElement(ConfidenceMeter, {
      value: 86,
      label: "Confidence",
      basis: "412 comps \xB7 90-day window \xB7 3 platforms agree"
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 8,
        flexWrap: "wrap",
        marginTop: 14
      }
    }, /*#__PURE__*/React.createElement(EvidenceChip, {
      state: "verified",
      source: "eBay sold",
      id: "412 comps"
    }), /*#__PURE__*/React.createElement(EvidenceChip, {
      state: "verified",
      source: "Mercari",
      id: "88 comps"
    }), /*#__PURE__*/React.createElement(EvidenceChip, {
      state: "conflict",
      source: "Poshmark",
      id: "median $171"
    }))), /*#__PURE__*/React.createElement(Card, {
      label: "Price history",
      title: "Median sold, 12 weeks"
    }, /*#__PURE__*/React.createElement(Sparkline, {
      values: [131, 138, 134, 142, 151, 147, 144, 155, 149, 146, 152, 148],
      width: 300,
      height: 56,
      area: true,
      dot: true,
      baseline: true
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        justifyContent: "space-between",
        marginTop: 8,
        font: "var(--type-data-sm)",
        color: "var(--text-faint)"
      }
    }, /*#__PURE__*/React.createElement("span", null, "12 wk ago"), /*#__PURE__*/React.createElement("span", null, "$131 \u2192 $148"), /*#__PURE__*/React.createElement("span", null, "now"))), /*#__PURE__*/React.createElement(Card, {
      label: "Listing draft",
      title: "Ready to publish"
    }, /*#__PURE__*/React.createElement(KeyValue, {
      layout: "rows",
      items: [{
        key: "Title",
        value: "Sony WH-1000XM4 Wireless Noise Cancelling Headphones — Black"
      }, {
        key: "Format",
        value: "Auction · 7 day · $0.99 start"
      }, {
        key: "Ship",
        value: "Calculated · 2 lb · from 21804"
      }, {
        key: "Specifics",
        value: "9 of 9 filled"
      }]
    }))) : /*#__PURE__*/React.createElement(Card, {
      label: "Verdict",
      title: "Nothing scanned yet"
    }, /*#__PURE__*/React.createElement(EmptyState, {
      icon: "crosshair",
      title: "Run a scan"
    }, "The verdict panel fills in only after all seven agents report. FSP never shows a number before the evidence that produced it."))));
  }
  Object.assign(window, {
    ScanPipeline,
    AGENTS
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/find-sell-profit/ScanPipeline.jsx", error: String((e && e.message) || e) }); }

// ui_kits/founder-command/CommandBoard.jsx
try { (() => {
(() => {
  const {
    Card,
    Stat,
    Badge,
    Button,
    IconButton,
    DataTable,
    Sparkline,
    StatusDot,
    EvidenceChip,
    Tabs,
    EmptyState,
    Progress,
    KeyValue
  } = window.NeuruhDesignSystem_5cb7e4;
  const DECISIONS = [{
    id: "D-104",
    title: "Promote Galaxy to production",
    entity: "Neuruh Org",
    cost: "$6,200",
    age: "3d",
    tone: "critical",
    state: "Blocking release",
    conf: 78
  }, {
    id: "D-103",
    title: "Replace MLS bridge provider",
    entity: "DeedSonar LLC",
    cost: "$4,800",
    age: "5d",
    tone: "critical",
    state: "Feed down 41m",
    conf: 64
  }, {
    id: "D-101",
    title: "Approve LARIC compliance scope",
    entity: "Neuruh Org",
    cost: "$3,900",
    age: "8d",
    tone: "caution",
    state: "Awaiting counsel",
    conf: 52
  }, {
    id: "D-099",
    title: "Field Scout offline package size",
    entity: "DeedSonar LLC",
    cost: "$2,100",
    age: "11d",
    tone: "caution",
    state: "Over budget",
    conf: 81
  }, {
    id: "D-097",
    title: "Creator pod hiring plan",
    entity: "Find Sell Profit",
    cost: "$1,400",
    age: "14d",
    tone: "neutral",
    state: "Deferred once",
    conf: 70
  }];
  const DEPLOYS = [{
    t: "14:08",
    sys: "deedsonar",
    env: "production",
    state: "ok",
    note: "blue-green cutover complete · 0 downtime"
  }, {
    t: "13:41",
    sys: "galaxy",
    env: "staging",
    state: "ok",
    note: "build 0x9F2 · 412 KB gz · under budget"
  }, {
    t: "12:19",
    sys: "fieldscout",
    env: "production",
    state: "warn",
    note: "bundle 268 KB gz · exceeds 250 KB budget"
  }, {
    t: "11:02",
    sys: "laric",
    env: "staging",
    state: "error",
    note: "blocked · compliance scope unapproved"
  }, {
    t: "09:47",
    sys: "adaptive",
    env: "staging",
    state: "ok",
    note: "build 0x9F1 · 588 KB gz"
  }];
  const SEV = {
    ok: "verified",
    warn: "caution",
    error: "critical"
  };
  function CommandBoard({
    onOpen,
    live,
    entity
  }) {
    const [range, setRange] = React.useState("7D");
    const rows = entity === "all" ? DECISIONS : DECISIONS.filter(d => entity === "neuruh" && d.entity === "Neuruh Org" || entity === "deedsonar" && d.entity === "DeedSonar LLC" || entity === "fsp" && d.entity === "Find Sell Profit");
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        flexDirection: "column",
        gap: 18,
        maxWidth: 1120
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "flex-end",
        gap: 16
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1
      }
    }, /*#__PURE__*/React.createElement("span", {
      className: "n-label"
    }, "Operator cockpit \xB7 Thursday 31 July"), /*#__PURE__*/React.createElement("h1", {
      style: {
        font: "var(--type-h1)",
        letterSpacing: "var(--tracking-tight)",
        color: "var(--text-primary)",
        margin: "6px 0 0"
      }
    }, rows.length, " decision", rows.length === 1 ? "" : "s", " awaiting you")), /*#__PURE__*/React.createElement(Tabs, {
      variant: "enclosed",
      value: range,
      onChange: setRange,
      items: ["24H", "7D", "30D", "FY"]
    }), /*#__PURE__*/React.createElement(Button, {
      variant: "command",
      icon: "zap"
    }, "Open standup")), /*#__PURE__*/React.createElement(Card, {
      variant: "accent",
      flushBody: true,
      label: "Decision queue",
      title: "Ranked by cost of delay",
      actions: /*#__PURE__*/React.createElement(IconButton, {
        icon: "funnel",
        size: "sm",
        label: "Filters",
        bordered: true
      })
    }, rows.length ? /*#__PURE__*/React.createElement(DataTable, {
      density: "loose",
      onSelect: onOpen,
      flaggedKeys: rows.filter(d => d.tone === "critical").map(d => d.id),
      columns: [{
        key: "id",
        label: "Ref",
        mono: true,
        width: 76
      }, {
        key: "title",
        label: "Decision",
        primary: true
      }, {
        key: "entity",
        label: "Entity"
      }, {
        key: "state",
        label: "Status",
        render: d => /*#__PURE__*/React.createElement(Badge, {
          tone: d.tone
        }, d.state)
      }, {
        key: "cost",
        label: "Cost / wk",
        align: "right",
        numeric: true,
        sortable: true
      }, {
        key: "age",
        label: "Open",
        align: "right",
        numeric: true
      }],
      rows: rows,
      footer: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
        style: {
          flex: 1
        }
      }, "Total cost of delay ", /*#__PURE__*/React.createElement("span", {
        className: "n-numeric",
        style: {
          font: "var(--type-data)",
          color: "var(--status-caution)"
        }
      }, "$18.4k / wk")), /*#__PURE__*/React.createElement(Button, {
        size: "sm",
        variant: "secondary"
      }, "Export"))
    }) : /*#__PURE__*/React.createElement(EmptyState, {
      icon: "circle-check",
      title: "Nothing awaiting you"
    }, "No open decisions for this entity. The queue is the point \u2014 keep it empty.")), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "repeat(4, 1fr)",
        gap: 1,
        background: "var(--border-default)",
        border: "1px solid var(--border-default)",
        borderRadius: "var(--radius-3)",
        overflow: "hidden"
      }
    }, [{
      label: "Systems live",
      value: "6",
      foot: "of 9 commissioned",
      trend: [4, 4, 5, 5, 6, 6, 6],
      tone: "verified"
    }, {
      label: "Deploys 7d",
      value: "12",
      delta: "+4",
      dir: "up",
      foot: "0 rollbacks",
      trend: [1, 2, 2, 3, 2, 4, 3],
      tone: "accent"
    }, {
      label: "Budgets breached",
      value: "1",
      foot: "Field Scout bundle",
      trend: [0, 0, 0, 1, 1, 1, 1],
      tone: "caution"
    }, {
      label: "Evidence coverage",
      value: "74%",
      delta: "+6%",
      dir: "up",
      foot: "median across systems",
      trend: [5, 5, 6, 6, 7, 7, 8],
      tone: "verified"
    }].map(s => /*#__PURE__*/React.createElement("div", {
      key: s.label,
      className: "n-tex n-tex--grain",
      style: {
        background: "var(--bg-surface)",
        backgroundImage: "var(--sheen-panel)",
        padding: "14px 16px",
        display: "flex",
        flexDirection: "column",
        gap: 10
      }
    }, /*#__PURE__*/React.createElement(Stat, {
      label: s.label,
      value: s.value,
      delta: s.delta,
      deltaDirection: s.dir,
      foot: s.foot
    }), /*#__PURE__*/React.createElement(Sparkline, {
      values: s.trend,
      tone: s.tone,
      width: 120,
      height: 20,
      area: false
    })))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 18,
        alignItems: "flex-start"
      }
    }, /*#__PURE__*/React.createElement(Card, {
      style: {
        flex: 1
      },
      flushBody: true,
      label: "Deployment stream",
      title: "All entities",
      actions: /*#__PURE__*/React.createElement(StatusDot, {
        state: live ? "live" : "inert",
        label: live ? "Tailing" : "Paused",
        pulse: live
      })
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        background: "var(--bg-inset)"
      }
    }, DEPLOYS.map((d, i) => /*#__PURE__*/React.createElement("div", {
      key: d.t + i,
      style: {
        display: "grid",
        gridTemplateColumns: "58px 92px 88px 1fr",
        gap: 12,
        alignItems: "baseline",
        padding: "9px 16px",
        borderBottom: i < DEPLOYS.length - 1 ? "1px solid var(--border-subtle)" : 0
      }
    }, /*#__PURE__*/React.createElement("span", {
      className: "n-numeric",
      style: {
        font: "var(--type-data-sm)",
        color: "var(--text-faint)"
      }
    }, d.t), /*#__PURE__*/React.createElement("span", {
      style: {
        font: "var(--type-data-sm)",
        color: "var(--text-accent)"
      }
    }, d.sys), /*#__PURE__*/React.createElement(Badge, {
      tone: SEV[d.state]
    }, d.env), /*#__PURE__*/React.createElement("span", {
      style: {
        font: "var(--type-data-sm)",
        color: "var(--text-body)"
      }
    }, d.note))))), /*#__PURE__*/React.createElement(Card, {
      style: {
        width: 300
      },
      label: "Budget posture",
      title: "Bundle vs ceiling"
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        flexDirection: "column",
        gap: 16
      }
    }, [["Flagship hero", 82, "verified"], ["Galaxy", 92, "caution"], ["Field Scout", 107, "critical"], ["DeedSonar", 64, "verified"]].map(([l, v, t]) => /*#__PURE__*/React.createElement("div", {
      key: l,
      style: {
        display: "flex",
        flexDirection: "column",
        gap: 6
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        justifyContent: "space-between",
        gap: 12
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        font: "var(--type-body-sm)",
        color: "var(--text-body)"
      }
    }, l), /*#__PURE__*/React.createElement("span", {
      className: "n-numeric",
      style: {
        font: "var(--type-data-sm)",
        color: `var(--status-${t})`
      }
    }, v, "%")), /*#__PURE__*/React.createElement(Progress, {
      value: Math.min(100, v),
      tone: t
    })))))));
  }
  Object.assign(window, {
    CommandBoard,
    DECISIONS
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/founder-command/CommandBoard.jsx", error: String((e && e.message) || e) }); }

// ui_kits/founder-command/CommandShell.jsx
try { (() => {
(() => {
  const {
    TopBar,
    IconButton,
    StatusDot,
    NavItem,
    Breadcrumbs,
    Input,
    Switch,
    Badge,
    Icon,
    Dialog
  } = window.NeuruhDesignSystem_5cb7e4;
  const ENTITIES = [{
    id: "all",
    icon: "layers",
    label: "All entities",
    meta: "9"
  }, {
    id: "neuruh",
    icon: "building-2",
    label: "Neuruh Org",
    meta: "4"
  }, {
    id: "deedsonar",
    icon: "scan-line",
    label: "DeedSonar LLC",
    meta: "3"
  }, {
    id: "fsp",
    icon: "trending-up",
    label: "Find Sell Profit",
    meta: "2"
  }];
  function CommandPalette({
    open,
    onClose,
    onRun
  }) {
    const [q, setQ] = React.useState("");
    const ACTIONS = [{
      id: "sweep",
      icon: "zap",
      label: "Run full sweep",
      hint: "DeedSonar"
    }, {
      id: "deploy",
      icon: "git-branch",
      label: "Promote staging → production",
      hint: "Galaxy"
    }, {
      id: "report",
      icon: "file-text",
      label: "Generate title opinion",
      hint: "DeedSonar"
    }, {
      id: "invite",
      icon: "users",
      label: "Invite operator",
      hint: "Neuruh Org"
    }, {
      id: "budget",
      icon: "gauge",
      label: "Review performance budgets",
      hint: "All systems"
    }, {
      id: "audit",
      icon: "lock",
      label: "Open audit log",
      hint: "Compliance"
    }];
    const shown = q ? ACTIONS.filter(a => (a.label + a.hint).toLowerCase().includes(q.toLowerCase())) : ACTIONS;
    React.useEffect(() => {
      if (open) setQ("");
    }, [open]);
    if (!open) return null;
    return /*#__PURE__*/React.createElement("div", {
      className: "n-dialog__scrim",
      style: {
        alignItems: "flex-start",
        paddingTop: "12vh"
      },
      onClick: onClose
    }, /*#__PURE__*/React.createElement("div", {
      className: "n-dialog",
      style: {
        maxWidth: 560,
        padding: 0
      },
      onClick: e => e.stopPropagation(),
      role: "dialog",
      "aria-modal": "true"
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        padding: 12,
        borderBottom: "1px solid var(--border-default)"
      }
    }, /*#__PURE__*/React.createElement(Input, {
      icon: "terminal",
      size: "lg",
      autoFocus: true,
      placeholder: "Run a command or jump to an entity",
      value: q,
      onChange: e => setQ(e.target.value),
      style: {
        width: "100%"
      }
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        maxHeight: 320,
        overflow: "auto",
        padding: 6
      }
    }, shown.length ? shown.map(a => /*#__PURE__*/React.createElement("button", {
      key: a.id,
      type: "button",
      className: "n-navitem",
      onClick: () => {
        onRun(a);
        onClose();
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: a.icon,
      size: 16
    }), /*#__PURE__*/React.createElement("span", {
      className: "n-navitem__label"
    }, a.label), /*#__PURE__*/React.createElement("span", {
      className: "n-navitem__meta"
    }, a.hint))) : /*#__PURE__*/React.createElement("div", {
      style: {
        padding: "28px 16px",
        textAlign: "center",
        font: "var(--type-body-sm)",
        color: "var(--text-faint)"
      }
    }, "No command matches \"", q, "\".")), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 14,
        padding: "10px 14px",
        borderTop: "1px solid var(--border-default)",
        font: "var(--type-data-sm)",
        color: "var(--text-faint)"
      }
    }, /*#__PURE__*/React.createElement("span", null, "\u21B5 run"), /*#__PURE__*/React.createElement("span", null, "\u2191\u2193 navigate"), /*#__PURE__*/React.createElement("span", null, "esc close"))));
  }
  function CommandShell({
    entity,
    onEntity,
    live,
    onLive,
    onPalette,
    children,
    drawer
  }) {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        flexDirection: "column",
        height: "100%",
        background: "var(--bg-sunken)"
      }
    }, /*#__PURE__*/React.createElement(TopBar, {
      product: "Founder Command",
      monogram: true,
      right: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Switch, {
        label: "Live",
        checked: live,
        onChange: e => onLive(e.target.checked)
      }), /*#__PURE__*/React.createElement(StatusDot, {
        state: live ? "live" : "inert",
        label: live ? "Tailing" : "Paused",
        pulse: live
      }), /*#__PURE__*/React.createElement("span", {
        style: {
          width: 6
        }
      }), /*#__PURE__*/React.createElement("button", {
        type: "button",
        onClick: onPalette,
        style: {
          display: "inline-flex",
          alignItems: "center",
          gap: 8,
          height: 28,
          padding: "0 10px",
          background: "var(--bg-inset)",
          border: "1px solid var(--border-default)",
          borderRadius: "var(--radius-2)",
          cursor: "pointer",
          font: "var(--type-data-sm)",
          color: "var(--text-faint)"
        }
      }, /*#__PURE__*/React.createElement(Icon, {
        name: "terminal",
        size: 13
      }), "\u2318K"), /*#__PURE__*/React.createElement(IconButton, {
        icon: "bell",
        size: "sm",
        label: "Alerts"
      }))
    }, /*#__PURE__*/React.createElement(Breadcrumbs, {
      items: [{
        label: "Neuruh Org",
        href: "#"
      }, {
        label: "Command",
        href: "#"
      }, "Today"]
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        flex: 1,
        minHeight: 0
      }
    }, /*#__PURE__*/React.createElement("nav", {
      className: "n-nav",
      style: {
        width: "var(--rail-sidebar)",
        flex: "none",
        padding: "0 8px 8px",
        borderRight: "1px solid var(--border-default)",
        background: "var(--bg-canvas)",
        overflow: "auto"
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "n-nav__group"
    }, "Entities"), ENTITIES.map(e => /*#__PURE__*/React.createElement(NavItem, {
      key: e.id,
      icon: e.icon,
      label: e.label,
      meta: e.meta,
      active: entity === e.id,
      onClick: () => onEntity(e.id)
    })), /*#__PURE__*/React.createElement("div", {
      className: "n-nav__group"
    }, "Views"), /*#__PURE__*/React.createElement(NavItem, {
      icon: "crosshair",
      label: "Decisions",
      meta: "5",
      active: true
    }), /*#__PURE__*/React.createElement(NavItem, {
      icon: "git-branch",
      label: "Deployments",
      meta: "12"
    }), /*#__PURE__*/React.createElement(NavItem, {
      icon: "gauge",
      label: "Budgets"
    }), /*#__PURE__*/React.createElement(NavItem, {
      icon: "lock",
      label: "Audit log"
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 20,
        padding: "0 4px"
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "n-label",
      style: {
        marginBottom: 8
      }
    }, "Cost of delay"), /*#__PURE__*/React.createElement("div", {
      style: {
        font: "700 1.125rem/1 var(--font-mono)",
        color: "var(--status-caution)",
        fontVariantNumeric: "tabular-nums"
      }
    }, "$18.4k / wk"), /*#__PURE__*/React.createElement("div", {
      style: {
        font: "var(--type-body-sm)",
        color: "var(--text-faint)",
        marginTop: 6
      }
    }, "across 5 open decisions"))), /*#__PURE__*/React.createElement("main", {
      style: {
        flex: 1,
        minWidth: 0,
        overflow: "auto",
        padding: "20px 24px"
      }
    }, children), drawer));
  }
  Object.assign(window, {
    CommandShell,
    CommandPalette,
    ENTITIES
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/founder-command/CommandShell.jsx", error: String((e && e.message) || e) }); }

// ui_kits/founder-command/DecisionDrawer.jsx
try { (() => {
(() => {
  const {
    IconButton,
    Badge,
    Button,
    Tabs,
    KeyValue,
    ConfidenceMeter,
    EvidenceChip,
    ProvenanceTrail,
    Radio,
    Field,
    Input,
    Stat
  } = window.NeuruhDesignSystem_5cb7e4;
  const CONTEXT = {
    "D-104": {
      body: "Galaxy has been in staging for 34 days. Build 0x9F2 is 412 KB gz against a 450 KB ceiling and has passed every gate except a manual accessibility review. Holding it blocks the Q3 operator rollout.",
      options: ["Promote now, review post-release", "Hold for accessibility review", "Promote to limited cohort"],
      rows: [{
        source: "Deployment log",
        value: "staging 34d · build 0x9F2",
        stamp: "07-31 13:41Z",
        state: "verified"
      }, {
        source: "Budget check",
        value: "412 KB gz / 450 KB",
        stamp: "07-31 13:41Z",
        state: "verified"
      }, {
        source: "A11y review",
        value: "not started",
        stamp: "—",
        state: "unverified"
      }]
    },
    "D-103": {
      body: "The MLS bridge has been unreachable for 41 minutes and has failed 3 handshake attempts. 118 DeedSonar targets are running on assessor data alone, which drops their confidence below the 50% floor.",
      options: ["Switch to backup provider", "Retry with extended timeout", "Suspend affected targets"],
      rows: [{
        source: "Feed monitor",
        value: "unreachable 41m · 3 attempts",
        stamp: "07-31 14:02Z",
        state: "verified"
      }, {
        source: "Resolver",
        value: "118 targets below floor",
        stamp: "07-31 14:02Z",
        state: "verified"
      }, {
        source: "MLS bridge SLA",
        value: "99.5% contractual",
        stamp: "07-01 00:00Z",
        state: "verified"
      }]
    }
  };
  const FALLBACK = {
    body: "PLACEHOLDER — no decision context was supplied for this reference. Every decision in this queue should state what is known, what is unknown, and what the delay costs.",
    options: ["Commit", "Defer one week", "Delegate"],
    rows: []
  };
  function DecisionDrawer({
    id,
    onClose,
    onCommit
  }) {
    const d = (window.DECISIONS || []).find(x => x.id === id);
    const c = CONTEXT[id] || FALLBACK;
    const [choice, setChoice] = React.useState(0);
    const [tab, setTab] = React.useState("context");
    React.useEffect(() => {
      setChoice(0);
      setTab("context");
    }, [id]);
    if (!d) return null;
    return /*#__PURE__*/React.createElement("aside", {
      style: {
        width: 420,
        flex: "none",
        borderLeft: "1px solid var(--border-default)",
        background: "var(--bg-canvas)",
        overflow: "auto",
        display: "flex",
        flexDirection: "column"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 10,
        height: "var(--bar-height)",
        padding: "0 12px 0 16px",
        borderBottom: "1px solid var(--border-default)",
        flex: "none"
      }
    }, /*#__PURE__*/React.createElement("span", {
      className: "n-label",
      style: {
        flex: 1
      }
    }, "Decision ", d.id), /*#__PURE__*/React.createElement(IconButton, {
      icon: "external-link",
      size: "sm",
      label: "Open full record"
    }), /*#__PURE__*/React.createElement(IconButton, {
      icon: "x",
      size: "sm",
      label: "Close",
      onClick: onClose
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        padding: 16
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 8,
        marginBottom: 12
      }
    }, /*#__PURE__*/React.createElement(Badge, {
      tone: d.tone
    }, d.state), /*#__PURE__*/React.createElement(Badge, {
      tone: "outline"
    }, d.entity)), /*#__PURE__*/React.createElement("h2", {
      style: {
        font: "var(--type-h2)",
        letterSpacing: "var(--tracking-tight)",
        color: "var(--text-primary)",
        margin: 0
      }
    }, d.title), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 28,
        marginTop: 16
      }
    }, /*#__PURE__*/React.createElement(Stat, {
      size: "sm",
      label: "Cost of delay",
      value: d.cost + " / wk"
    }), /*#__PURE__*/React.createElement(Stat, {
      size: "sm",
      label: "Open",
      value: d.age
    }))), /*#__PURE__*/React.createElement("hr", {
      className: "n-rule"
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        padding: "0 16px"
      }
    }, /*#__PURE__*/React.createElement(Tabs, {
      value: tab,
      onChange: setTab,
      items: [{
        id: "context",
        label: "Context"
      }, {
        id: "evidence",
        label: "Evidence",
        count: c.rows.length
      }]
    })), tab === "context" ? /*#__PURE__*/React.createElement("div", {
      style: {
        padding: "16px"
      }
    }, /*#__PURE__*/React.createElement("p", {
      style: {
        font: "var(--type-body)",
        color: "var(--text-body)",
        margin: 0
      }
    }, c.body), /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 20
      }
    }, /*#__PURE__*/React.createElement("span", {
      className: "n-label"
    }, "Options"), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        flexDirection: "column",
        gap: 12,
        marginTop: 12
      }
    }, c.options.map((o, i) => /*#__PURE__*/React.createElement(Radio, {
      key: o,
      name: "opt-" + id,
      label: o,
      checked: choice === i,
      onChange: () => setChoice(i)
    })))), /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 20
      }
    }, /*#__PURE__*/React.createElement(Field, {
      label: "Rationale",
      hint: "Recorded in the audit log with your identity."
    }, /*#__PURE__*/React.createElement(Input, {
      placeholder: "One sentence on why"
    })))) : /*#__PURE__*/React.createElement("div", {
      style: {
        padding: "16px"
      }
    }, /*#__PURE__*/React.createElement(ConfidenceMeter, {
      value: d.conf,
      basis: `${c.rows.filter(r => r.state === "verified").length} of ${c.rows.length || 1} sources verified`
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 8,
        margin: "16px 0",
        flexWrap: "wrap"
      }
    }, c.rows.map(r => /*#__PURE__*/React.createElement(EvidenceChip, {
      key: r.source,
      state: r.state,
      source: r.source
    }))), c.rows.length ? /*#__PURE__*/React.createElement(ProvenanceTrail, {
      rows: c.rows
    }) : /*#__PURE__*/React.createElement("p", {
      style: {
        font: "var(--type-body-sm)",
        color: "var(--text-faint)",
        margin: 0
      }
    }, "No sources attached. A decision without evidence should not be in this queue.")), /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: "auto",
        display: "flex",
        gap: 8,
        padding: 16,
        borderTop: "1px solid var(--border-default)",
        flex: "none"
      }
    }, /*#__PURE__*/React.createElement(Button, {
      variant: "secondary",
      onClick: () => onCommit(d, "deferred")
    }, "Defer"), /*#__PURE__*/React.createElement("span", {
      style: {
        flex: 1
      }
    }), /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      icon: "check",
      onClick: () => onCommit(d, "committed", c.options[choice])
    }, "Commit")));
  }
  Object.assign(window, {
    DecisionDrawer
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/founder-command/DecisionDrawer.jsx", error: String((e && e.message) || e) }); }

// ui_kits/galaxy/GalaxyGraph.jsx
try { (() => {
(() => {
  const {
    SceneFrame,
    Badge,
    IconButton,
    EmptyState
  } = window.NeuruhDesignSystem_5cb7e4;

  /* Canvas force simulation — SPECIFICATION, not a production renderer.
     See README: production routes to Sigma.js + Graphology. */

  const NODES = [{
    id: "platform",
    label: "Execution platform",
    cluster: "Enterprise",
    r: 26,
    since: 2019,
    health: "healthy",
    stage: "live",
    evidence: 4
  }, {
    id: "deedsonar",
    label: "DeedSonar",
    cluster: "Real estate",
    r: 19,
    since: 2022,
    health: "healthy",
    stage: "live",
    evidence: 4
  }, {
    id: "fieldscout",
    label: "Field Scout",
    cluster: "Real estate",
    r: 14,
    since: 2024,
    health: "degraded",
    stage: "live",
    evidence: 3
  }, {
    id: "founder",
    label: "Founder Command",
    cluster: "Enterprise",
    r: 17,
    since: 2023,
    health: "healthy",
    stage: "live",
    evidence: 3
  }, {
    id: "galaxy",
    label: "Cockpit / Galaxy",
    cluster: "Enterprise",
    r: 15,
    since: 2025,
    health: "healthy",
    stage: "staging",
    evidence: 2
  }, {
    id: "adaptive",
    label: "Adaptive Intelligence",
    cluster: "Enterprise",
    r: 16,
    since: 2024,
    health: "degraded",
    stage: "staging",
    evidence: 2
  }, {
    id: "laric",
    label: "LARIC",
    cluster: "Defense",
    r: 15,
    since: 2025,
    health: "blocked",
    stage: "staging",
    evidence: 1
  }, {
    id: "fsp",
    label: "Find Sell Profit",
    cluster: "Creator",
    r: 13,
    since: 2023,
    health: "healthy",
    stage: "live",
    evidence: 3
  }, {
    id: "leadrecipe",
    label: "Lead Recipe OS",
    cluster: "Creator",
    r: 12,
    since: 2026,
    health: "planned",
    stage: "planned",
    evidence: 1
  }];
  const EDGES = [["platform", "deedsonar", 3], ["platform", "founder", 3], ["platform", "galaxy", 2], ["platform", "adaptive", 3], ["platform", "laric", 2], ["platform", "fsp", 2], ["platform", "leadrecipe", 1], ["deedsonar", "fieldscout", 3], ["deedsonar", "laric", 1], ["founder", "galaxy", 2], ["adaptive", "fsp", 1], ["fsp", "leadrecipe", 2], ["founder", "adaptive", 2]];
  const RAMP = {
    healthy: "--data-1",
    degraded: "--data-2",
    staging: "--data-3",
    blocked: "--data-4",
    planned: "--data-5"
  };
  const CLUSTER_RAMP = {
    Enterprise: "--data-1",
    "Real estate": "--data-2",
    Creator: "--data-3",
    Defense: "--data-4"
  };
  const STAGE_RAMP = {
    live: "--data-1",
    staging: "--data-3",
    planned: "--data-5"
  };
  function colorFor(n, lens) {
    if (lens === "domain") return CLUSTER_RAMP[n.cluster] || "--data-5";
    if (lens === "stage") return STAGE_RAMP[n.stage] || "--data-5";
    if (lens === "evidence") return ["--data-4", "--data-4", "--data-3", "--data-2", "--data-1"][n.evidence] || "--data-5";
    return RAMP[n.health] || "--data-5";
  }
  function GalaxyGraph({
    lens,
    era,
    collapsed,
    selected,
    onSelect
  }) {
    const ref = React.useRef(null);
    const wrapRef = React.useRef(null);
    const state = React.useRef({
      nodes: [],
      edges: [],
      hover: null,
      css: {}
    });
    const visible = React.useMemo(() => {
      const shown = NODES.filter(n => n.since <= era);
      const hidden = new Set();
      const proxies = [];
      collapsed.forEach(c => {
        const members = shown.filter(n => n.cluster === c && n.id !== "platform");
        if (members.length < 2) return;
        members.forEach(m => hidden.add(m.id));
        proxies.push({
          id: "cluster:" + c,
          label: c,
          cluster: c,
          r: 22 + members.length * 2,
          since: Math.min(...members.map(m => m.since)),
          health: members.some(m => m.health === "blocked") ? "blocked" : members.some(m => m.health === "degraded") ? "degraded" : "healthy",
          stage: "live",
          evidence: Math.round(members.reduce((a, m) => a + m.evidence, 0) / members.length),
          isCluster: true,
          count: members.length
        });
      });
      const nodes = shown.filter(n => !hidden.has(n.id)).concat(proxies);
      const idOf = x => hidden.has(x) ? "cluster:" + NODES.find(n => n.id === x).cluster : x;
      const seen = new Set();
      const edges = [];
      EDGES.forEach(([a, b, w]) => {
        const na = NODES.find(n => n.id === a),
          nb = NODES.find(n => n.id === b);
        if (na.since > era || nb.since > era) return;
        const A = idOf(a),
          B = idOf(b);
        if (A === B) return;
        const k = [A, B].sort().join("|");
        if (seen.has(k)) return;
        seen.add(k);
        edges.push([A, B, w]);
      });
      return {
        nodes,
        edges
      };
    }, [era, collapsed]);
    React.useEffect(() => {
      const cs = getComputedStyle(document.documentElement);
      const keys = ["--data-1", "--data-2", "--data-3", "--data-4", "--data-5", "--data-6", "--border-default", "--border-strong", "--text-primary", "--text-faint", "--accent-solid", "--scene-void", "--scene-haze"];
      const css = {};
      keys.forEach(k => {
        css[k] = cs.getPropertyValue(k).trim();
      });
      state.current.css = css;
    }, []);
    React.useEffect(() => {
      const prev = new Map(state.current.nodes.map(n => [n.id, n]));
      state.current.nodes = visible.nodes.map(n => {
        const p = prev.get(n.id);
        return {
          ...n,
          x: p ? p.x : 0.5 + (Math.random() - 0.5) * 0.4,
          y: p ? p.y : 0.5 + (Math.random() - 0.5) * 0.4,
          vx: 0,
          vy: 0
        };
      });
      state.current.edges = visible.edges;
    }, [visible]);
    React.useEffect(() => {
      const canvas = ref.current;
      if (!canvas) return;
      let raf,
        alive = true;
      const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
      function step() {
        const {
          nodes,
          edges,
          css
        } = state.current;
        const map = new Map(nodes.map(n => [n.id, n]));
        // repulsion
        for (let i = 0; i < nodes.length; i++) {
          for (let j = i + 1; j < nodes.length; j++) {
            const a = nodes[i],
              b = nodes[j];
            let dx = b.x - a.x,
              dy = b.y - a.y;
            let d2 = dx * dx + dy * dy || 0.0001;
            const f = 0.00022 / d2;
            const d = Math.sqrt(d2);
            a.vx -= dx / d * f;
            a.vy -= dy / d * f;
            b.vx += dx / d * f;
            b.vy += dy / d * f;
          }
        }
        // springs
        edges.forEach(([A, B, w]) => {
          const a = map.get(A),
            b = map.get(B);
          if (!a || !b) return;
          const dx = b.x - a.x,
            dy = b.y - a.y;
          const d = Math.sqrt(dx * dx + dy * dy) || 0.0001;
          const target = 0.19 + (4 - w) * 0.045;
          const f = (d - target) * 0.014;
          a.vx += dx / d * f;
          a.vy += dy / d * f;
          b.vx -= dx / d * f;
          b.vy -= dy / d * f;
        });
        // centering + integrate
        nodes.forEach(n => {
          n.vx += (0.5 - n.x) * 0.006;
          n.vy += (0.5 - n.y) * 0.006;
          n.vx *= 0.86;
          n.vy *= 0.86;
          n.x = Math.min(0.94, Math.max(0.06, n.x + n.vx));
          n.y = Math.min(0.92, Math.max(0.08, n.y + n.vy));
        });
      }
      function draw() {
        const {
          nodes,
          edges,
          css,
          hover
        } = state.current;
        const dpr = window.devicePixelRatio || 1;
        const W = canvas.clientWidth,
          H = canvas.clientHeight;
        if (canvas.width !== W * dpr || canvas.height !== H * dpr) {
          canvas.width = W * dpr;
          canvas.height = H * dpr;
        }
        const g = canvas.getContext("2d");
        g.setTransform(dpr, 0, 0, dpr, 0, 0);
        g.clearRect(0, 0, W, H);
        const map = new Map(nodes.map(n => [n.id, n]));
        const neighbours = new Set();
        if (selected) {
          neighbours.add(selected);
          edges.forEach(([a, b]) => {
            if (a === selected) neighbours.add(b);
            if (b === selected) neighbours.add(a);
          });
        }
        const dim = id => selected && !neighbours.has(id);
        // edges
        edges.forEach(([A, B, w]) => {
          const a = map.get(A),
            b = map.get(B);
          if (!a || !b) return;
          const faded = dim(A) || dim(B);
          g.strokeStyle = faded ? css["--border-default"] : selected ? css["--accent-solid"] : css["--border-strong"];
          g.globalAlpha = faded ? 0.28 : selected ? 0.7 : 0.55;
          g.lineWidth = 0.6 + w * 0.5;
          g.beginPath();
          g.moveTo(a.x * W, a.y * H);
          g.lineTo(b.x * W, b.y * H);
          g.stroke();
        });
        g.globalAlpha = 1;
        // nodes
        const zoomedIn = W > 620;
        nodes.forEach(n => {
          const faded = dim(n.id);
          const col = css[colorFor(n, lens)] || css["--data-5"];
          const x = n.x * W,
            y = n.y * H;
          g.globalAlpha = faded ? 0.3 : 1;
          if (n.id === selected) {
            g.beginPath();
            g.arc(x, y, n.r + 7, 0, Math.PI * 2);
            g.strokeStyle = css["--accent-solid"];
            g.lineWidth = 1.5;
            g.stroke();
          }
          g.beginPath();
          g.arc(x, y, n.r, 0, Math.PI * 2);
          g.fillStyle = col;
          g.globalAlpha = faded ? 0.16 : 0.22;
          g.fill();
          g.globalAlpha = faded ? 0.4 : 1;
          g.strokeStyle = col;
          g.lineWidth = n.isCluster ? 2 : 1.4;
          g.stroke();
          if (n.isCluster) {
            g.beginPath();
            g.arc(x, y, n.r - 5, 0, Math.PI * 2);
            g.setLineDash([2, 3]);
            g.lineWidth = 1;
            g.stroke();
            g.setLineDash([]);
          }
          // semantic zoom: labels only when there is room
          if (zoomedIn || n.r > 18 || n.id === selected || hover === n.id) {
            g.globalAlpha = faded ? 0.35 : 1;
            g.fillStyle = n.id === selected || hover === n.id ? css["--text-primary"] : css["--text-faint"];
            g.font = `500 ${n.isCluster ? 12 : 11}px "JetBrains Mono", monospace`;
            g.textAlign = "center";
            g.fillText(n.isCluster ? `${n.label} · ${n.count}` : n.label, x, y + n.r + 15);
          }
        });
        g.globalAlpha = 1;
      }
      function loop() {
        if (!alive) return;
        if (!reduced) step();
        draw();
        raf = requestAnimationFrame(loop);
      }
      if (reduced) {
        for (let i = 0; i < 260; i++) step();
        draw();
      } else loop();
      return () => {
        alive = false;
        cancelAnimationFrame(raf);
      };
    }, [lens, selected, visible]);
    function hit(e) {
      const canvas = ref.current;
      const rect = canvas.getBoundingClientRect();
      const x = (e.clientX - rect.left) / rect.width,
        y = (e.clientY - rect.top) / rect.height;
      let best = null,
        bestD = Infinity;
      state.current.nodes.forEach(n => {
        const dx = (n.x - x) * rect.width,
          dy = (n.y - y) * rect.height;
        const d = Math.sqrt(dx * dx + dy * dy);
        if (d < n.r + 8 && d < bestD) {
          best = n;
          bestD = d;
        }
      });
      return best;
    }
    return /*#__PURE__*/React.createElement("div", {
      ref: wrapRef,
      style: {
        position: "absolute",
        inset: 0,
        background: "var(--scene-void)"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        position: "absolute",
        inset: 0,
        background: "radial-gradient(90% 70% at 50% 55%, var(--scene-haze), transparent 70%)",
        pointerEvents: "none"
      }
    }), /*#__PURE__*/React.createElement("canvas", {
      ref: ref,
      style: {
        position: "absolute",
        inset: 0,
        width: "100%",
        height: "100%",
        cursor: "pointer"
      },
      onClick: e => {
        const n = hit(e);
        onSelect(n ? n.id : null);
      },
      onMouseMove: e => {
        const n = hit(e);
        state.current.hover = n ? n.id : null;
        e.currentTarget.style.cursor = n ? "pointer" : "default";
      }
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        position: "absolute",
        left: 16,
        top: 16,
        display: "flex",
        gap: 8,
        pointerEvents: "none"
      }
    }, /*#__PURE__*/React.createElement(Badge, {
      tone: "outline"
    }, visible.nodes.length, " nodes"), /*#__PURE__*/React.createElement(Badge, {
      tone: "outline"
    }, visible.edges.length, " edges"), selected ? /*#__PURE__*/React.createElement(Badge, {
      tone: "accent"
    }, "Isolated") : null), /*#__PURE__*/React.createElement("div", {
      style: {
        position: "absolute",
        right: 16,
        bottom: 16,
        font: "var(--type-data-sm)",
        color: "var(--text-faint)",
        pointerEvents: "none"
      }
    }, "Specification renderer \xB7 production routes to Sigma.js"));
  }
  Object.assign(window, {
    GalaxyGraph,
    GALAXY_NODES: NODES,
    GALAXY_EDGES: EDGES
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/galaxy/GalaxyGraph.jsx", error: String((e && e.message) || e) }); }

// ui_kits/galaxy/GalaxyScene3D.jsx
try { (() => {
(() => {
  const {
    SceneFrame,
    Badge,
    EmptyState
  } = window.NeuruhDesignSystem_5cb7e4;

  /* 3D Galaxy — the spatial lens on the same graph the 2D view renders.
     Three.js directly (nine nodes; R3F would be ceremony), force-directed in
     three dimensions, mounted inside SceneFrame so the WebGL requirement,
     reduced-motion route and poster fallback are handled once.
     Production routes to Three Force Graph per guidelines/spatial-stack.md;
     the layout math and the material language here are the specification. */

  const THREE_URL = "https://unpkg.com/three@0.160.0/build/three.module.js";

  /* three.js arrives as an ES module loaded once by the host page, which sets
     window.THREE. Babel-transpiled kit scripts cannot use dynamic import(). */
  function waitForThree() {
    if (window.THREE) return Promise.resolve(window.THREE);
    return new Promise((resolve, reject) => {
      const t = setTimeout(() => reject(new Error("timeout")), 12000);
      window.addEventListener("three-ready", () => {
        clearTimeout(t);
        resolve(window.THREE);
      }, {
        once: true
      });
    });
  }
  function cssVar(name, fallback) {
    const v = getComputedStyle(document.documentElement).getPropertyValue(name).trim();
    return v || fallback;
  }
  function GalaxyScene3D({
    lens,
    era,
    selected,
    onSelect,
    autorotate = true
  }) {
    const hostRef = React.useRef(null);
    const apiRef = React.useRef(null);
    const [ready, setReady] = React.useState(false);
    const [failed, setFailed] = React.useState(null);
    const [labels, setLabels] = React.useState([]);
    const RAMP = {
      healthy: "--data-1",
      degraded: "--data-2",
      staging: "--data-3",
      blocked: "--data-4",
      planned: "--data-5"
    };
    const CLUSTER_RAMP = {
      Enterprise: "--data-1",
      "Real estate": "--data-2",
      Creator: "--data-3",
      Defense: "--data-4"
    };
    const STAGE_RAMP = {
      live: "--data-1",
      staging: "--data-3",
      planned: "--data-5"
    };
    const colorKey = React.useCallback(n => {
      if (lens === "domain") return CLUSTER_RAMP[n.cluster] || "--data-5";
      if (lens === "stage") return STAGE_RAMP[n.stage] || "--data-5";
      if (lens === "evidence") return ["--data-4", "--data-4", "--data-3", "--data-2", "--data-1"][n.evidence] || "--data-5";
      return RAMP[n.health] || "--data-5";
    }, [lens]);
    React.useEffect(() => {
      let alive = true,
        cleanup = null;
      (async () => {
        let THREE;
        try {
          THREE = await waitForThree();
        } catch (e) {
          if (alive) setFailed("three.js could not be loaded from the CDN.");
          return;
        }
        if (!alive || !hostRef.current) return;
        const host = hostRef.current;
        const scene = new THREE.Scene();
        const camera = new THREE.PerspectiveCamera(42, 1, 0.1, 200);
        camera.position.set(0, 1.4, 26);
        const renderer = new THREE.WebGLRenderer({
          antialias: true,
          alpha: true
        });
        renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
        renderer.setClearAlpha(0);
        host.appendChild(renderer.domElement);
        Object.assign(renderer.domElement.style, {
          position: "absolute",
          inset: 0,
          width: "100%",
          height: "100%",
          cursor: "grab"
        });

        /* Studio: one key, one cool fill, a warm rim. Nothing animated — the
           graph moves, the light does not. */
        scene.add(new THREE.AmbientLight(0xffffff, 0.55));
        const key = new THREE.DirectionalLight(0xfffdf8, 1.15);
        key.position.set(6, 9, 7);
        scene.add(key);
        const fill = new THREE.DirectionalLight(0x9fd4dc, 0.4);
        fill.position.set(-8, -2, 5);
        scene.add(fill);
        const rim = new THREE.DirectionalLight(0xc9a567, 0.5);
        rim.position.set(-3, 4, -8);
        scene.add(rim);
        const group = new THREE.Group();
        scene.add(group);
        const api = {
          THREE,
          scene,
          camera,
          renderer,
          group,
          nodes: [],
          edges: [],
          meshes: new Map(),
          lines: [],
          raf: 0,
          drag: null,
          rot: {
            x: -0.12,
            y: 0.4
          },
          spin: autorotate,
          selected: null,
          lens
        };
        apiRef.current = api;
        api.build = function build(era) {
          api.group.clear();
          api.meshes.clear();
          api.lines = [];
          const src = (window.GALAXY_NODES || []).filter(n => n.since <= era);
          const ids = new Set(src.map(n => n.id));
          api.nodes = src.map((n, i) => {
            const phi = Math.acos(1 - 2 * (i + 0.5) / src.length);
            const theta = Math.PI * (1 + Math.sqrt(5)) * i;
            const r = 4.4;
            return {
              ...n,
              x: r * Math.sin(phi) * Math.cos(theta),
              y: r * Math.cos(phi) * 0.7,
              z: r * Math.sin(phi) * Math.sin(theta),
              vx: 0,
              vy: 0,
              vz: 0
            };
          });
          api.edges = (window.GALAXY_EDGES || []).filter(([a, b]) => ids.has(a) && ids.has(b));
          const geo = new THREE.IcosahedronGeometry(1, 3);
          api.nodes.forEach(n => {
            const col = new THREE.Color(cssVar(colorKey(n), "#7cc0c8"));
            const mat = new THREE.MeshStandardMaterial({
              color: col,
              roughness: 0.42,
              metalness: 0.18,
              emissive: col.clone().multiplyScalar(0.22),
              transparent: true,
              opacity: 0.95
            });
            const mesh = new THREE.Mesh(geo, mat);
            mesh.scale.setScalar(n.r / 30 + 0.24);
            mesh.userData.id = n.id;
            api.group.add(mesh);
            // Halo: a wire shell that reads as reach, not as decoration.
            const halo = new THREE.Mesh(geo, new THREE.MeshBasicMaterial({
              color: col,
              wireframe: true,
              transparent: true,
              opacity: 0.16
            }));
            halo.scale.setScalar(1.55);
            mesh.add(halo);
            api.meshes.set(n.id, mesh);
          });
          api.edges.forEach(([a, b, w]) => {
            const g = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(), new THREE.Vector3()]);
            const line = new THREE.Line(g, new THREE.LineBasicMaterial({
              color: new THREE.Color(cssVar("--border-strong", "#3a4442")),
              transparent: true,
              opacity: 0.18 + w * 0.12
            }));
            line.userData = {
              a,
              b,
              w
            };
            api.group.add(line);
            api.lines.push(line);
          });
        };
        api.step = function step() {
          const N = api.nodes;
          for (let i = 0; i < N.length; i++) {
            for (let j = i + 1; j < N.length; j++) {
              const a = N[i],
                b = N[j];
              let dx = b.x - a.x,
                dy = b.y - a.y,
                dz = b.z - a.z;
              const d2 = dx * dx + dy * dy + dz * dz || 0.001;
              const d = Math.sqrt(d2);
              const f = 16 / d2;
              a.vx -= dx / d * f;
              a.vy -= dy / d * f;
              a.vz -= dz / d * f;
              b.vx += dx / d * f;
              b.vy += dy / d * f;
              b.vz += dz / d * f;
            }
          }
          const map = new Map(N.map(n => [n.id, n]));
          api.edges.forEach(([A, B, w]) => {
            const a = map.get(A),
              b = map.get(B);
            if (!a || !b) return;
            const dx = b.x - a.x,
              dy = b.y - a.y,
              dz = b.z - a.z;
            const d = Math.sqrt(dx * dx + dy * dy + dz * dz) || 0.001;
            const target = 3.1 + (4 - w) * 0.7;
            const f = (d - target) * 0.012;
            a.vx += dx / d * f;
            a.vy += dy / d * f;
            a.vz += dz / d * f;
            b.vx -= dx / d * f;
            b.vy -= dy / d * f;
            b.vz -= dz / d * f;
          });
          N.forEach(n => {
            const pull = n.id === "platform" ? 0.06 : 0.018;
            n.vx -= n.x * pull;
            n.vy -= n.y * pull * 1.6;
            n.vz -= n.z * pull;
            n.vx *= 0.84;
            n.vy *= 0.84;
            n.vz *= 0.84;
            n.x += n.vx;
            n.y += n.vy;
            n.z += n.vz;
          });
          // Soft containment: the cloud may not grow past the framed volume.
          let far = 0;
          N.forEach(n => {
            far = Math.max(far, Math.hypot(n.x, n.y, n.z));
          });
          if (far > 7.2) {
            const k = 7.2 / far;
            N.forEach(n => {
              n.x *= k;
              n.y *= k;
              n.z *= k;
            });
          }
          N.forEach(n => {
            const m = api.meshes.get(n.id);
            if (m) m.position.set(n.x, n.y, n.z);
          });
          api.lines.forEach(l => {
            const a = map.get(l.userData.a),
              b = map.get(l.userData.b);
            if (!a || !b) return;
            l.geometry.setFromPoints([new THREE.Vector3(a.x, a.y, a.z), new THREE.Vector3(b.x, b.y, b.z)]);
          });
        };
        api.applySelection = function applySelection() {
          const sel = api.selected;
          const near = new Set();
          if (sel) {
            near.add(sel);
            api.edges.forEach(([a, b]) => {
              if (a === sel) near.add(b);
              if (b === sel) near.add(a);
            });
          }
          api.meshes.forEach((m, id) => {
            const dim = sel && !near.has(id);
            m.material.opacity = dim ? 0.16 : 0.95;
            m.material.emissiveIntensity = id === sel ? 1.6 : 1;
            m.children[0].material.opacity = dim ? 0.04 : id === sel ? 0.42 : 0.16;
          });
          api.lines.forEach(l => {
            const on = !sel || near.has(l.userData.a) && near.has(l.userData.b);
            l.material.opacity = on ? 0.18 + l.userData.w * 0.12 : 0.05;
            l.material.color.set(cssVar(on && sel ? "--accent-solid" : "--border-strong", "#3a4442"));
          });
        };
        api.recolor = function recolor() {
          api.meshes.forEach((m, id) => {
            const n = api.nodes.find(x => x.id === id);
            if (!n) return;
            const col = new THREE.Color(cssVar(colorKey(n), "#7cc0c8"));
            m.material.color.copy(col);
            m.material.emissive.copy(col).multiplyScalar(0.22);
            m.children[0].material.color.copy(col);
          });
        };
        function resize() {
          const w = host.clientWidth,
            h = host.clientHeight;
          if (!w || !h) return;
          renderer.setSize(w, h, false);
          camera.aspect = w / h;
          camera.updateProjectionMatrix();
        }
        const ro = new ResizeObserver(resize);
        ro.observe(host);
        resize();

        /* Labels live in the DOM, not the scene — crisper, and they inherit the
           type tokens instead of re-implementing them in a texture. */
        function projectLabels() {
          const w = host.clientWidth,
            h = host.clientHeight;
          const v = new THREE.Vector3();
          const out = [];
          api.meshes.forEach((m, id) => {
            const n = api.nodes.find(x => x.id === id);
            if (!n) return;
            v.setFromMatrixPosition(m.matrixWorld).project(camera);
            if (v.z > 1) return;
            out.push({
              id,
              label: n.label,
              x: (v.x * 0.5 + 0.5) * w,
              y: (-v.y * 0.5 + 0.5) * h + m.scale.x * 26 + 10,
              z: v.z,
              dim: api.selected && api.selected !== id
            });
          });
          return out;
        }
        let frames = 0;
        const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
        function loop() {
          api.raf = requestAnimationFrame(loop);
          if (!reduced || frames < 240) api.step();
          if (api.spin && !api.drag && !reduced) api.rot.y += 0.0016;
          api.group.rotation.set(api.rot.x, api.rot.y, 0);
          renderer.render(scene, camera);
          if (++frames % 3 === 0) setLabels(projectLabels());
        }

        // Pointer: drag to orbit, click to isolate.
        let down = null;
        const el = renderer.domElement;
        const onDown = e => {
          down = {
            x: e.clientX,
            y: e.clientY,
            rx: api.rot.x,
            ry: api.rot.y,
            moved: false
          };
          api.drag = true;
          el.style.cursor = "grabbing";
          el.setPointerCapture(e.pointerId);
        };
        const onMove = e => {
          if (!down) return;
          const dx = e.clientX - down.x,
            dy = e.clientY - down.y;
          if (Math.abs(dx) + Math.abs(dy) > 4) down.moved = true;
          api.rot.y = down.ry + dx * 0.006;
          api.rot.x = Math.max(-1.1, Math.min(1.1, down.rx + dy * 0.005));
        };
        const onUp = e => {
          el.style.cursor = "grab";
          api.drag = false;
          if (down && !down.moved) {
            const rect = el.getBoundingClientRect();
            const ndc = new THREE.Vector2((e.clientX - rect.left) / rect.width * 2 - 1, -((e.clientY - rect.top) / rect.height) * 2 + 1);
            const rc = new THREE.Raycaster();
            rc.setFromCamera(ndc, camera);
            const hits = rc.intersectObjects([...api.meshes.values()], false);
            onSelect(hits.length ? hits[0].object.userData.id : null);
          }
          down = null;
        };
        const onWheel = e => {
          e.preventDefault();
          camera.position.z = Math.max(13, Math.min(46, camera.position.z + e.deltaY * 0.02));
        };
        el.addEventListener("pointerdown", onDown);
        el.addEventListener("pointermove", onMove);
        el.addEventListener("pointerup", onUp);
        el.addEventListener("wheel", onWheel, {
          passive: false
        });
        api.build(era);
        api.selected = selected;
        api.applySelection();
        loop();
        if (alive) setReady(true);
        cleanup = () => {
          cancelAnimationFrame(api.raf);
          ro.disconnect();
          el.removeEventListener("pointerdown", onDown);
          el.removeEventListener("pointermove", onMove);
          el.removeEventListener("pointerup", onUp);
          el.removeEventListener("wheel", onWheel);
          renderer.dispose();
          if (el.parentNode) el.parentNode.removeChild(el);
          apiRef.current = null;
        };
      })();
      return () => {
        alive = false;
        if (cleanup) cleanup();
      };
    }, []);
    React.useEffect(() => {
      const a = apiRef.current;
      if (!a) return;
      a.build(era);
      a.selected = selected;
      a.applySelection();
    }, [era]);
    React.useEffect(() => {
      const a = apiRef.current;
      if (!a) return;
      a.selected = selected;
      a.applySelection();
    }, [selected]);
    React.useEffect(() => {
      const a = apiRef.current;
      if (!a) return;
      a.recolor();
      a.applySelection();
    }, [lens, colorKey]);
    React.useEffect(() => {
      const a = apiRef.current;
      if (a) a.spin = autorotate;
    }, [autorotate]);
    if (failed) {
      return /*#__PURE__*/React.createElement("div", {
        style: {
          position: "absolute",
          inset: 0,
          display: "grid",
          placeItems: "center",
          background: "var(--scene-void)",
          padding: 32
        }
      }, /*#__PURE__*/React.createElement(EmptyState, {
        icon: "triangle-alert",
        label: "Spatial route unavailable",
        title: "3D lens could not start"
      }, failed, " The 2D lens carries the same graph \u2014 switch lenses in the toolbar."));
    }
    return /*#__PURE__*/React.createElement("div", {
      style: {
        position: "absolute",
        inset: 0,
        overflow: "hidden",
        background: "var(--scene-void)"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        position: "absolute",
        inset: 0,
        background: "radial-gradient(85% 65% at 50% 50%, var(--scene-haze), transparent 72%)",
        pointerEvents: "none"
      }
    }), /*#__PURE__*/React.createElement("div", {
      ref: hostRef,
      style: {
        position: "absolute",
        inset: 0
      }
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        position: "absolute",
        inset: 0,
        pointerEvents: "none"
      }
    }, labels.map(l => /*#__PURE__*/React.createElement("span", {
      key: l.id,
      style: {
        position: "absolute",
        left: l.x,
        top: l.y,
        transform: "translateX(-50%)",
        font: "var(--type-data-sm)",
        whiteSpace: "nowrap",
        color: l.dim ? "var(--text-faint)" : "var(--text-primary)",
        opacity: l.dim ? 0.35 : 1,
        textShadow: "0 1px 3px rgba(8,10,10,0.85)"
      }
    }, l.label))), /*#__PURE__*/React.createElement("div", {
      style: {
        position: "absolute",
        left: 16,
        top: 16,
        display: "flex",
        gap: 8,
        pointerEvents: "none"
      }
    }, /*#__PURE__*/React.createElement(Badge, {
      tone: "outline"
    }, "3D lens"), selected ? /*#__PURE__*/React.createElement(Badge, {
      tone: "accent"
    }, "Isolated") : null, !ready ? /*#__PURE__*/React.createElement(Badge, {
      tone: "neutral"
    }, "Starting\u2026") : null), /*#__PURE__*/React.createElement("div", {
      style: {
        position: "absolute",
        right: 16,
        bottom: 16,
        font: "var(--type-data-sm)",
        color: "var(--text-faint)",
        pointerEvents: "none"
      }
    }, "Drag to orbit \xB7 scroll to dolly \xB7 click to isolate"));
  }
  Object.assign(window, {
    GalaxyScene3D
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/galaxy/GalaxyScene3D.jsx", error: String((e && e.message) || e) }); }

// ui_kits/galaxy/GalaxyShell.jsx
try { (() => {
(() => {
  const {
    TopBar,
    IconButton,
    StatusDot,
    NavItem,
    Breadcrumbs,
    Tabs,
    Badge,
    Tag,
    Icon
  } = window.NeuruhDesignSystem_5cb7e4;
  const LENSES = [{
    id: "domain",
    icon: "layers",
    label: "Domain",
    meta: "4"
  }, {
    id: "health",
    icon: "activity",
    label: "Health",
    meta: "9"
  }, {
    id: "stage",
    icon: "git-branch",
    label: "Deployment stage"
  }, {
    id: "evidence",
    icon: "shield",
    label: "Evidence coverage"
  }];
  function GalaxyShell({
    lens,
    onLens,
    era,
    onEra,
    collapsed,
    onCollapse,
    playing,
    onPlay,
    dim,
    onDim,
    children,
    inspector
  }) {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        flexDirection: "column",
        height: "100%",
        background: "var(--scene-void)"
      }
    }, /*#__PURE__*/React.createElement(TopBar, {
      product: "Galaxy",
      right: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Tabs, {
        value: dim,
        onChange: onDim,
        variant: "enclosed",
        items: [{
          id: "2d",
          label: "2D"
        }, {
          id: "3d",
          label: "3D"
        }]
      }), /*#__PURE__*/React.createElement(StatusDot, {
        state: "live",
        label: "9 nodes",
        pulse: true
      }), /*#__PURE__*/React.createElement(IconButton, {
        icon: "settings",
        size: "sm",
        label: "Settings"
      }))
    }, /*#__PURE__*/React.createElement(Breadcrumbs, {
      items: [{
        label: "Neuruh Org",
        href: "#"
      }, {
        label: "Portfolio",
        href: "#"
      }, "Galaxy"]
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        flex: 1,
        minHeight: 0
      }
    }, /*#__PURE__*/React.createElement("nav", {
      className: "n-nav n-tex n-tex--grid",
      style: {
        width: "var(--rail-sidebar)",
        flex: "none",
        padding: "0 8px 8px",
        borderRight: "1px solid var(--border-default)",
        background: "var(--bg-canvas)",
        overflow: "auto"
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "n-nav__group"
    }, "Ontology lens"), LENSES.map(l => /*#__PURE__*/React.createElement(NavItem, {
      key: l.id,
      icon: l.icon,
      label: l.label,
      meta: l.meta,
      active: lens === l.id,
      onClick: () => onLens(l.id)
    })), /*#__PURE__*/React.createElement("div", {
      className: "n-nav__group"
    }, "Clusters"), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        flexWrap: "wrap",
        gap: 6,
        padding: "2px 4px 10px"
      }
    }, ["Defense", "Real estate", "Enterprise", "Creator"].map(c => /*#__PURE__*/React.createElement(Tag, {
      key: c,
      selected: collapsed.includes(c),
      onClick: () => onCollapse(c),
      style: {
        cursor: "pointer"
      }
    }, c))), /*#__PURE__*/React.createElement("div", {
      className: "n-nav__group"
    }, "Legend"), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        flexDirection: "column",
        gap: 8,
        padding: "2px 6px 12px"
      }
    }, [["--data-1", "Live · healthy"], ["--data-2", "Live · degraded"], ["--data-3", "Staging"], ["--data-4", "Blocked"], ["--data-5", "Planned"]].map(([v, l]) => /*#__PURE__*/React.createElement("div", {
      key: v,
      style: {
        display: "flex",
        alignItems: "center",
        gap: 9
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        width: 9,
        height: 9,
        borderRadius: 99,
        background: `var(${v})`,
        flex: "none"
      }
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        font: "var(--type-body-sm)",
        color: "var(--text-muted)"
      }
    }, l))))), /*#__PURE__*/React.createElement("main", {
      style: {
        flex: 1,
        minWidth: 0,
        position: "relative",
        display: "flex",
        flexDirection: "column"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minHeight: 0,
        position: "relative"
      }
    }, children), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: "none",
        display: "flex",
        alignItems: "center",
        gap: 14,
        padding: "10px 16px",
        borderTop: "1px solid var(--border-default)",
        background: "var(--bg-canvas)"
      }
    }, /*#__PURE__*/React.createElement(IconButton, {
      icon: playing ? "pause" : "play",
      size: "sm",
      label: "Replay portfolio history",
      bordered: true,
      onClick: onPlay
    }), /*#__PURE__*/React.createElement("span", {
      className: "n-label",
      style: {
        flex: "none"
      }
    }, "Era"), /*#__PURE__*/React.createElement("input", {
      type: "range",
      min: "2019",
      max: "2026",
      step: "1",
      value: era,
      onChange: e => onEra(Number(e.target.value)),
      style: {
        flex: 1,
        accentColor: "var(--accent-solid)",
        height: 4
      }
    }), /*#__PURE__*/React.createElement("span", {
      className: "n-numeric",
      style: {
        font: "var(--type-data)",
        color: "var(--text-primary)",
        width: 44,
        textAlign: "right"
      }
    }, era))), inspector));
  }
  Object.assign(window, {
    GalaxyShell,
    LENSES
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/galaxy/GalaxyShell.jsx", error: String((e && e.message) || e) }); }

// ui_kits/galaxy/NodeInspector.jsx
try { (() => {
(() => {
  const {
    IconButton,
    Badge,
    Button,
    Tabs,
    KeyValue,
    ConfidenceMeter,
    EvidenceChip,
    ProvenanceTrail,
    Stat,
    Sparkline,
    EmptyState,
    Icon
  } = window.NeuruhDesignSystem_5cb7e4;
  const DETAIL = {
    platform: {
      domain: "Enterprise",
      stage: "Live",
      since: "2019",
      owner: "Core",
      budget: "—",
      uptime: "99.98%",
      trend: [8, 8, 9, 9, 9, 10, 10]
    },
    deedsonar: {
      domain: "Real estate",
      stage: "Live",
      since: "2022",
      owner: "RE pod",
      budget: "450 KB gz",
      uptime: "99.91%",
      trend: [4, 5, 6, 7, 8, 9, 11]
    },
    fieldscout: {
      domain: "Real estate",
      stage: "Live",
      since: "2024",
      owner: "RE pod",
      budget: "250 KB gz",
      uptime: "98.40%",
      trend: [6, 6, 5, 5, 4, 4, 3]
    },
    founder: {
      domain: "Enterprise",
      stage: "Live",
      since: "2023",
      owner: "Ops",
      budget: "450 KB gz",
      uptime: "99.86%",
      trend: [5, 6, 6, 7, 7, 8, 8]
    },
    galaxy: {
      domain: "Enterprise",
      stage: "Staging",
      since: "2025",
      owner: "Ops",
      budget: "450 KB gz",
      uptime: "—",
      trend: [1, 2, 3, 4, 5, 6, 8]
    },
    adaptive: {
      domain: "Enterprise",
      stage: "Staging",
      since: "2024",
      owner: "Core",
      budget: "600 KB gz",
      uptime: "—",
      trend: [7, 6, 6, 6, 5, 5, 5]
    },
    laric: {
      domain: "Defense",
      stage: "Staging",
      since: "2025",
      owner: "Legal",
      budget: "250 KB gz",
      uptime: "—",
      trend: [3, 3, 2, 2, 2, 1, 1]
    },
    fsp: {
      domain: "Creator",
      stage: "Live",
      since: "2023",
      owner: "Creator pod",
      budget: "250 KB gz",
      uptime: "99.72%",
      trend: [4, 5, 5, 6, 7, 7, 9]
    },
    leadrecipe: {
      domain: "Creator",
      stage: "Planned",
      since: "2026",
      owner: "Creator pod",
      budget: "—",
      uptime: "—",
      trend: [1, 1, 1, 2, 2, 2, 2]
    }
  };
  function NodeInspector({
    id,
    onClose
  }) {
    const [tab, setTab] = React.useState("health");
    const node = (window.GALAXY_NODES || []).find(n => n.id === id);
    const isCluster = id && id.startsWith("cluster:");
    const d = DETAIL[id];
    return /*#__PURE__*/React.createElement("aside", {
      style: {
        width: "var(--rail-inspector)",
        flex: "none",
        borderLeft: "1px solid var(--border-default)",
        background: "var(--bg-canvas)",
        overflow: "auto"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 10,
        height: "var(--bar-height)",
        padding: "0 12px 0 16px",
        borderBottom: "1px solid var(--border-default)"
      }
    }, /*#__PURE__*/React.createElement("span", {
      className: "n-label",
      style: {
        flex: 1
      }
    }, "Node"), /*#__PURE__*/React.createElement(IconButton, {
      icon: "x",
      size: "sm",
      label: "Close inspector",
      onClick: onClose
    })), !id ? /*#__PURE__*/React.createElement(EmptyState, {
      icon: "crosshair",
      title: "No node selected"
    }, "Click any node to isolate its neighbourhood and read its health, dependencies, and evidence coverage.") : isCluster ? /*#__PURE__*/React.createElement("div", {
      style: {
        padding: 16
      }
    }, /*#__PURE__*/React.createElement(Badge, {
      tone: "accent"
    }, "Collapsed cluster"), /*#__PURE__*/React.createElement("h2", {
      style: {
        font: "var(--type-h2)",
        letterSpacing: "var(--tracking-tight)",
        color: "var(--text-primary)",
        margin: "12px 0 6px"
      }
    }, id.replace("cluster:", "")), /*#__PURE__*/React.createElement("p", {
      style: {
        font: "var(--type-body-sm)",
        color: "var(--text-muted)",
        margin: 0
      }
    }, "Expand this cluster from the rail to inspect member systems individually.")) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
      className: "n-tex n-tex--grid",
      style: {
        padding: 16
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        font: "var(--type-data)",
        color: "var(--text-accent)"
      }
    }, id), /*#__PURE__*/React.createElement("h2", {
      style: {
        font: "var(--type-h2)",
        letterSpacing: "var(--tracking-tight)",
        color: "var(--text-primary)",
        margin: "6px 0 4px"
      }
    }, node ? node.label : id), /*#__PURE__*/React.createElement("div", {
      style: {
        font: "var(--type-body-sm)",
        color: "var(--text-muted)"
      }
    }, d ? `${d.domain} · commissioned ${d.since}` : ""), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 8,
        marginTop: 14,
        flexWrap: "wrap"
      }
    }, /*#__PURE__*/React.createElement(Badge, {
      tone: node && node.health === "healthy" ? "verified" : node && node.health === "blocked" ? "critical" : "caution"
    }, node ? node.health : "unknown"), /*#__PURE__*/React.createElement(Badge, {
      tone: "outline"
    }, d ? d.stage : ""))), /*#__PURE__*/React.createElement("hr", {
      className: "n-rule"
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        padding: "0 16px"
      }
    }, /*#__PURE__*/React.createElement(Tabs, {
      value: tab,
      onChange: setTab,
      items: [{
        id: "health",
        label: "Health"
      }, {
        id: "deps",
        label: "Dependencies"
      }, {
        id: "evidence",
        label: "Evidence"
      }]
    })), tab === "health" ? /*#__PURE__*/React.createElement("div", {
      style: {
        padding: "16px"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 24,
        marginBottom: 18
      }
    }, /*#__PURE__*/React.createElement(Stat, {
      size: "sm",
      label: "Uptime 90d",
      value: d ? d.uptime : "—"
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        flexDirection: "column",
        gap: 6
      }
    }, /*#__PURE__*/React.createElement("span", {
      className: "n-label"
    }, "Trend"), /*#__PURE__*/React.createElement(Sparkline, {
      values: d ? d.trend : [1, 1],
      tone: node && node.health === "healthy" ? "verified" : node && node.health === "blocked" ? "critical" : "caution"
    }))), /*#__PURE__*/React.createElement(KeyValue, {
      items: [{
        key: "Domain",
        value: d ? d.domain : "—"
      }, {
        key: "Stage",
        value: d ? d.stage : "—"
      }, {
        key: "Owner",
        value: d ? d.owner : "—"
      }, {
        key: "Bundle budget",
        value: d ? d.budget : "—"
      }, {
        key: "Commissioned",
        value: d ? d.since : "—"
      }]
    })) : tab === "deps" ? /*#__PURE__*/React.createElement("div", {
      style: {
        padding: "12px 16px 20px",
        display: "flex",
        flexDirection: "column",
        gap: 2
      }
    }, (window.GALAXY_EDGES || []).filter(([a, b]) => a === id || b === id).map(([a, b, w]) => {
      const other = a === id ? b : a;
      const on = (window.GALAXY_NODES || []).find(n => n.id === other);
      return /*#__PURE__*/React.createElement("div", {
        key: other,
        style: {
          display: "flex",
          alignItems: "center",
          gap: 12,
          minHeight: "var(--row-height)",
          borderBottom: "1px solid var(--border-subtle)"
        }
      }, /*#__PURE__*/React.createElement(Icon, {
        name: "link-2",
        size: 14,
        style: {
          color: "var(--text-faint)",
          flex: "none"
        }
      }), /*#__PURE__*/React.createElement("span", {
        style: {
          flex: 1,
          font: "var(--type-ui)",
          color: "var(--text-primary)",
          overflow: "hidden",
          textOverflow: "ellipsis",
          whiteSpace: "nowrap"
        }
      }, on ? on.label : other), /*#__PURE__*/React.createElement("span", {
        style: {
          display: "flex",
          gap: 2
        }
      }, [1, 2, 3].map(i => /*#__PURE__*/React.createElement("span", {
        key: i,
        style: {
          width: 4,
          height: 10,
          borderRadius: 1,
          background: i <= w ? "var(--accent-solid)" : "var(--bg-surface-active)"
        }
      }))));
    })) : /*#__PURE__*/React.createElement("div", {
      style: {
        padding: "16px"
      }
    }, /*#__PURE__*/React.createElement(ConfidenceMeter, {
      value: node ? node.evidence * 25 : 0,
      label: "Evidence coverage",
      basis: node ? `${node.evidence} of 4 required source classes attached` : ""
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 8,
        margin: "16px 0",
        flexWrap: "wrap"
      }
    }, /*#__PURE__*/React.createElement(EvidenceChip, {
      state: "verified",
      source: "Deployment log"
    }), /*#__PURE__*/React.createElement(EvidenceChip, {
      state: node && node.evidence >= 3 ? "verified" : "unverified",
      source: "Telemetry"
    })), /*#__PURE__*/React.createElement(ProvenanceTrail, {
      rows: [{
        source: "Deployment log",
        value: d ? `${d.stage} since ${d.since}` : "—",
        stamp: "07-31 09:14Z",
        state: "verified"
      }, {
        source: "Telemetry",
        value: d ? `uptime ${d.uptime}` : "—",
        stamp: "07-31 09:12Z",
        state: node && node.evidence >= 3 ? "verified" : "unverified"
      }, {
        source: "Asset manifest",
        value: d ? `budget ${d.budget}` : "—",
        stamp: "07-28 00:00Z",
        state: "verified"
      }]
    }))));
  }
  Object.assign(window, {
    NodeInspector
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/galaxy/NodeInspector.jsx", error: String((e && e.message) || e) }); }

// ui_kits/neuruh-com/CapabilityIndex.jsx
try { (() => {
(() => {
  const {
    Card,
    Badge,
    Button,
    Icon,
    Tag
  } = window.NeuruhDesignSystem_5cb7e4;
  const PRODUCTS = [{
    name: "DeedSonar",
    domain: "Real estate intelligence",
    icon: "scan-line",
    thesis: "Title chains, liens, and owner conflicts resolved against nine public sources."
  }, {
    name: "Founder Command",
    domain: "Operator cockpit",
    icon: "gauge",
    thesis: "One surface for every entity, deployment, and open decision."
  }, {
    name: "Cockpit / Galaxy",
    domain: "Portfolio spatial view",
    icon: "globe",
    thesis: "The conglomerate rendered as navigable space, not a list of tabs."
  }, {
    name: "Adaptive Intelligence",
    domain: "Recursive automation",
    icon: "cpu",
    thesis: "Workflows that revise themselves against measured outcomes."
  }, {
    name: "Field Scout",
    domain: "Mobile capture",
    icon: "map-pin",
    thesis: "Ground truth captured on site, signed, and attached to the record."
  }, {
    name: "LARIC",
    domain: "Legal & compliance",
    icon: "shield",
    thesis: "Contract and compliance posture, continuously assessed."
  }, {
    name: "Find Sell Profit",
    domain: "Resale intelligence",
    icon: "trending-up",
    thesis: "Scan, price, and route inventory with live comp data."
  }, {
    name: "Lead Recipe OS",
    domain: "Pipeline construction",
    icon: "funnel",
    thesis: "Repeatable acquisition sequences, versioned like code."
  }];
  function CapabilityIndex() {
    const [open, setOpen] = React.useState(null);
    return /*#__PURE__*/React.createElement("section", {
      id: "products",
      className: "reveal",
      style: {
        padding: "clamp(64px, 10vh, 120px) clamp(20px, 4vw, 56px)",
        borderTop: "1px solid var(--border-default)"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        maxWidth: "var(--page-max)",
        margin: "0 auto"
      }
    }, /*#__PURE__*/React.createElement("span", {
      className: "n-label"
    }, "The index"), /*#__PURE__*/React.createElement("h2", {
      style: {
        font: "var(--type-cinema-2)",
        letterSpacing: "var(--tracking-cinema)",
        color: "var(--text-primary)",
        margin: "12px 0 18px",
        maxWidth: "20ch"
      }
    }, "Nine systems. One spine."), /*#__PURE__*/React.createElement("p", {
      style: {
        font: "var(--type-body-lg)",
        color: "var(--text-muted)",
        margin: "0 0 44px",
        maxWidth: "var(--measure-editorial)"
      }
    }, "Each product independently defines its metaphor, signature interaction, motion language, and vocabulary. They share authentication, telemetry, and the evidence model \u2014 nothing else."), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))",
        gap: 14
      }
    }, PRODUCTS.map(p => /*#__PURE__*/React.createElement(Card, {
      key: p.name,
      interactive: true,
      variant: "default",
      onMouseEnter: () => setOpen(p.name),
      onMouseLeave: () => setOpen(null),
      onFocus: () => setOpen(p.name),
      onBlur: () => setOpen(null),
      tabIndex: 0
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "flex-start",
        gap: 14
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        width: 36,
        height: 36,
        flex: "none",
        display: "grid",
        placeItems: "center",
        background: "var(--bg-inset)",
        border: "1px solid var(--border-default)",
        borderRadius: "var(--radius-2)",
        color: "var(--text-accent)"
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: p.icon,
      size: 18
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        font: "var(--type-h3)",
        color: "var(--text-primary)",
        letterSpacing: "var(--tracking-tight)"
      }
    }, p.name), /*#__PURE__*/React.createElement("div", {
      className: "n-label",
      style: {
        marginTop: 5
      }
    }, p.domain)), /*#__PURE__*/React.createElement(Icon, {
      name: "arrow-up-right",
      size: 15,
      style: {
        color: "var(--text-faint)"
      }
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        overflow: "hidden",
        maxHeight: open === p.name ? 90 : 0,
        opacity: open === p.name ? 1 : 0,
        transition: "max-height var(--dur-slow) var(--ease-out), opacity var(--dur-base) var(--ease-standard)"
      }
    }, /*#__PURE__*/React.createElement("p", {
      style: {
        font: "var(--type-body-sm)",
        color: "var(--text-muted)",
        margin: "14px 0 0"
      }
    }, p.thesis))))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 8,
        marginTop: 28,
        flexWrap: "wrap"
      }
    }, /*#__PURE__*/React.createElement("span", {
      className: "n-label",
      style: {
        alignSelf: "center",
        marginRight: 6
      }
    }, "Shared foundation"), ["Authentication", "Permissions", "Data access", "Telemetry", "Testing", "Deployment", "Accessibility primitives"].map(t => /*#__PURE__*/React.createElement(Tag, {
      key: t
    }, t)))));
  }
  Object.assign(window, {
    CapabilityIndex,
    PRODUCTS
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/neuruh-com/CapabilityIndex.jsx", error: String((e && e.message) || e) }); }

// ui_kits/neuruh-com/EditorialSection.jsx
try { (() => {
(() => {
  const {
    Button,
    Badge,
    Icon,
    Wordmark,
    Seal
  } = window.NeuruhDesignSystem_5cb7e4;
  const RULES = [{
    k: "01",
    t: "Central metaphor",
    d: "What the product is, before it is a screen."
  }, {
    k: "02",
    t: "Signature interaction",
    d: "The one motion nobody else has."
  }, {
    k: "03",
    t: "Evidence model",
    d: "How a claim proves itself."
  }, {
    k: "04",
    t: "Performance budget",
    d: "The number the build is held to."
  }];
  function EditorialSection() {
    return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("section", {
      id: "platform",
      className: "reveal",
      style: {
        borderTop: "1px solid var(--border-default)",
        display: "grid",
        gridTemplateColumns: "repeat(auto-fit, minmax(420px, 1fr))"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        padding: "clamp(56px, 9vh, 104px) clamp(20px, 4vw, 56px)",
        display: "flex",
        flexDirection: "column",
        justifyContent: "center",
        gap: 24
      }
    }, /*#__PURE__*/React.createElement("span", {
      className: "n-label"
    }, "The core rule"), /*#__PURE__*/React.createElement("h2", {
      style: {
        font: "var(--type-cinema-3)",
        letterSpacing: "var(--tracking-cinema)",
        color: "var(--text-primary)",
        margin: 0,
        maxWidth: "24ch"
      }
    }, "A shared foundation is infrastructure. A shared face is a liability."), /*#__PURE__*/React.createElement("p", {
      style: {
        font: "var(--type-body-lg)",
        color: "var(--text-muted)",
        margin: 0,
        maxWidth: "var(--measure-editorial)"
      }
    }, "Most platforms ship one design and rename it nine times. We ship one spine and make every product defend its own identity in writing before a pixel is drawn."), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gap: 1,
        background: "var(--border-default)",
        marginTop: 12
      }
    }, RULES.map(r => /*#__PURE__*/React.createElement("div", {
      key: r.k,
      style: {
        background: "var(--bg-canvas)",
        display: "flex",
        gap: 18,
        padding: "16px 0"
      }
    }, /*#__PURE__*/React.createElement("span", {
      className: "n-numeric",
      style: {
        font: "var(--type-data)",
        color: "var(--text-accent)",
        width: 28
      }
    }, r.k), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        font: "var(--type-h4)",
        color: "var(--text-primary)"
      }
    }, r.t), /*#__PURE__*/React.createElement("div", {
      style: {
        font: "var(--type-body-sm)",
        color: "var(--text-muted)",
        marginTop: 3
      }
    }, r.d))))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Button, {
      variant: "secondary",
      iconAfter: "arrow-right"
    }, "Read the underwrite process"))), /*#__PURE__*/React.createElement("div", {
      style: {
        position: "relative",
        minHeight: 460,
        borderLeft: "1px solid var(--border-default)"
      }
    }, /*#__PURE__*/React.createElement("image-slot", {
      id: "flagship-editorial",
      shape: "rect",
      fit: "cover",
      placeholder: "Editorial still \u2014 authored spatial scene or product capture"
    }))), /*#__PURE__*/React.createElement("section", {
      id: "defense",
      className: "reveal n-tex n-tex--contour",
      style: {
        padding: "clamp(64px, 10vh, 120px) clamp(20px, 4vw, 56px)",
        borderTop: "1px solid var(--border-default)",
        background: "linear-gradient(180deg, var(--pine-900), var(--scene-void))"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        maxWidth: "var(--page-max)",
        margin: "0 auto",
        display: "flex",
        gap: 48,
        flexWrap: "wrap",
        alignItems: "flex-end"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 300
      }
    }, /*#__PURE__*/React.createElement("span", {
      className: "n-label"
    }, "Defense & regulated environments"), /*#__PURE__*/React.createElement("h2", {
      style: {
        font: "var(--type-cinema-3)",
        letterSpacing: "var(--tracking-cinema)",
        color: "var(--text-primary)",
        margin: "12px 0 18px",
        maxWidth: "22ch"
      }
    }, "Built to be audited, not admired."), /*#__PURE__*/React.createElement("p", {
      style: {
        font: "var(--type-body)",
        color: "var(--text-muted)",
        margin: 0,
        maxWidth: "44ch"
      }
    }, "Access control, audit logging, and redaction policy are v1 requirements across every system. Compliance posture is surfaced, not asserted.")), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 10,
        flexWrap: "wrap"
      }
    }, ["SOC 2 track", "ISO 27001 track", "Audit logging", "Data residency", "Reduced motion", "WCAG AA"].map(b => /*#__PURE__*/React.createElement(Badge, {
      key: b,
      tone: "outline"
    }, b))))), /*#__PURE__*/React.createElement("footer", {
      id: "company",
      style: {
        padding: "clamp(48px, 7vh, 80px) clamp(20px, 4vw, 56px) 40px",
        borderTop: "1px solid var(--border-default)"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        maxWidth: "var(--page-max)",
        margin: "0 auto",
        display: "flex",
        gap: 48,
        flexWrap: "wrap"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 260
      }
    }, /*#__PURE__*/React.createElement(Wordmark, {
      size: "lg",
      monogram: true
    }), /*#__PURE__*/React.createElement("p", {
      style: {
        font: "var(--type-body-sm)",
        color: "var(--text-faint)",
        margin: "14px 0 0",
        maxWidth: "34ch"
      }
    }, "Modular AI execution platform. Nine systems, one foundation, no shared face.")), [["Products", ["DeedSonar", "Founder Command", "Field Scout", "LARIC"]], ["Platform", ["Evidence model", "Telemetry", "Deployment", "Access control"]], ["Company", ["Underwrite process", "Design system", "Careers", "Contact"]]].map(([h, items]) => /*#__PURE__*/React.createElement("div", {
      key: h,
      style: {
        minWidth: 150
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "n-label",
      style: {
        marginBottom: 14
      }
    }, h), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        flexDirection: "column",
        gap: 9
      }
    }, items.map(i => /*#__PURE__*/React.createElement("a", {
      key: i,
      href: "#",
      style: {
        font: "var(--type-body-sm)",
        color: "var(--text-muted)",
        textDecoration: "none"
      }
    }, i)))))), /*#__PURE__*/React.createElement("div", {
      style: {
        maxWidth: "var(--page-max)",
        margin: "48px auto 0",
        paddingTop: 20,
        borderTop: "1px solid var(--border-subtle)",
        display: "flex",
        gap: 20,
        flexWrap: "wrap",
        font: "var(--type-data-sm)",
        color: "var(--text-faint)"
      }
    }, /*#__PURE__*/React.createElement("span", null, "\xA9 2026 Neuruh"), /*#__PURE__*/React.createElement("span", null, "\xB7"), /*#__PURE__*/React.createElement("span", null, "Mark set in Archivo \u2014 no logo file supplied"))));
  }
  Object.assign(window, {
    EditorialSection
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/neuruh-com/EditorialSection.jsx", error: String((e && e.message) || e) }); }

// ui_kits/neuruh-com/EvidenceBand.jsx
try { (() => {
(() => {
  const {
    Stat,
    EvidenceChip,
    Badge
  } = window.NeuruhDesignSystem_5cb7e4;
  const NUMBERS = [{
    label: "Systems in production",
    value: "9",
    foot: "defense · real estate · enterprise · creator",
    src: "Internal registry"
  }, {
    label: "GPT deployments",
    value: "60+",
    foot: "shipped to client environments",
    src: "Deployment log"
  }, {
    label: "IP under management",
    value: "1TB+",
    foot: "documented, versioned, licensable",
    src: "Asset manifest"
  }, {
    label: "Blue-green cutovers",
    value: "100%",
    foot: "zero-downtime releases to date",
    src: "Release record"
  }];
  function EvidenceBand() {
    return /*#__PURE__*/React.createElement("section", {
      id: "evidence",
      className: "reveal",
      style: {
        padding: "clamp(64px, 10vh, 120px) clamp(20px, 4vw, 56px)",
        borderTop: "1px solid var(--border-default)",
        background: "var(--ink-900)"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        maxWidth: "var(--page-max)",
        margin: "0 auto"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "flex-end",
        gap: 24,
        marginBottom: 48,
        flexWrap: "wrap"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 280
      }
    }, /*#__PURE__*/React.createElement("span", {
      className: "n-label"
    }, "Evidence"), /*#__PURE__*/React.createElement("h2", {
      style: {
        font: "var(--type-cinema-3)",
        letterSpacing: "var(--tracking-cinema)",
        color: "var(--text-primary)",
        margin: "10px 0 0",
        maxWidth: "22ch"
      }
    }, "Every number carries its source.")), /*#__PURE__*/React.createElement("p", {
      style: {
        font: "var(--type-body)",
        color: "var(--text-muted)",
        margin: 0,
        maxWidth: "38ch"
      }
    }, "Evidence, authority, and lineage are brand-level properties, not a feature of one product. If a claim cannot be traced, it does not ship.")), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))",
        gap: 1,
        background: "var(--border-default)"
      }
    }, NUMBERS.map(n => /*#__PURE__*/React.createElement("div", {
      key: n.label,
      className: "n-tex n-tex--grain",
      style: {
        background: "var(--ink-900)",
        padding: "28px 24px 24px",
        display: "flex",
        flexDirection: "column",
        gap: 16
      }
    }, /*#__PURE__*/React.createElement(Stat, {
      size: "hero",
      label: n.label,
      value: n.value,
      foot: n.foot
    }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(EvidenceChip, {
      source: n.src,
      state: "verified"
    })))))));
  }
  Object.assign(window, {
    EvidenceBand,
    NUMBERS
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/neuruh-com/EvidenceBand.jsx", error: String((e && e.message) || e) }); }

// ui_kits/neuruh-com/FlagshipHero.jsx
try { (() => {
(() => {
  const {
    Button,
    Badge,
    StatusDot,
    SceneFrame,
    SoundToggle
  } = window.NeuruhDesignSystem_5cb7e4;

  /* The hero is a spatial surface, so it is composed through SceneFrame rather
     than by dropping a canvas into the page. Until a real scene lands, the
     image-slot stands in as the poster and the tier badge shows which route
     the current device would take. */
  function FlagshipHero() {
    const [sound, setSound] = React.useState(false);
    const [tier, setTier] = React.useState("static");
    React.useEffect(() => {
      setTier(SceneFrame.detectTier());
    }, []);
    return /*#__PURE__*/React.createElement("section", {
      style: {
        position: "relative",
        minHeight: "min(92vh, 860px)",
        display: "flex",
        alignItems: "flex-end",
        overflow: "hidden",
        background: "var(--scene-void)"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        position: "absolute",
        top: 0,
        right: 0,
        bottom: 0,
        left: "40%"
      }
    }, /*#__PURE__*/React.createElement(SceneFrame, {
      fill: true,
      requires: "webgpu",
      scrim: false,
      caption: "Spatial index scene \u2014 R3F mounts here on the WebGL route."
    }, /*#__PURE__*/React.createElement("image-slot", {
      id: "flagship-hero",
      shape: "rect",
      fit: "cover",
      placeholder: "Spatial hero scene \u2014 Spline/Blender still or R3F capture"
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        position: "absolute",
        inset: 0,
        pointerEvents: "none",
        background: "radial-gradient(120% 90% at 70% 100%, var(--scene-haze), transparent 68%)"
      }
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        position: "absolute",
        inset: 0,
        background: "linear-gradient(100deg, var(--scene-void) 0%, var(--scene-void) 32%, rgba(8,10,10,0.86) 47%, rgba(8,10,10,0.26) 72%, rgba(8,10,10,0.08) 100%)",
        pointerEvents: "none"
      }
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        position: "absolute",
        inset: 0,
        background: "var(--scrim-protection)",
        pointerEvents: "none"
      }
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        position: "absolute",
        left: "clamp(20px, 4vw, 56px)",
        top: 96,
        display: "flex",
        gap: 8,
        zIndex: 2
      }
    }, /*#__PURE__*/React.createElement(Badge, {
      tone: "outline"
    }, "Spatial index"), /*#__PURE__*/React.createElement(Badge, {
      tone: "neutral"
    }, tier, " route")), /*#__PURE__*/React.createElement("div", {
      style: {
        position: "absolute",
        right: "clamp(20px, 4vw, 56px)",
        bottom: "clamp(48px, 7vh, 88px)",
        zIndex: 2
      }
    }, /*#__PURE__*/React.createElement(SoundToggle, {
      on: sound,
      onChange: setSound,
      label: "Scene audio",
      bars: 6
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        position: "relative",
        padding: "0 clamp(20px, 4vw, 56px) clamp(48px, 7vh, 88px)",
        maxWidth: 880,
        pointerEvents: "none"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 14,
        marginBottom: 22
      }
    }, /*#__PURE__*/React.createElement(StatusDot, {
      state: "live",
      label: "9 systems deployed",
      pulse: true
    }), /*#__PURE__*/React.createElement(Badge, {
      tone: "outline"
    }, "Sovereign conglomerate")), /*#__PURE__*/React.createElement("h1", {
      style: {
        font: "var(--type-cinema-1)",
        letterSpacing: "var(--tracking-cinema)",
        color: "var(--paper-000)",
        margin: 0,
        maxWidth: "15ch",
        textWrap: "balance"
      }
    }, "Share the foundation. Never share the face."), /*#__PURE__*/React.createElement("p", {
      style: {
        font: "var(--type-body-lg)",
        color: "var(--ink-100)",
        margin: "26px 0 0",
        maxWidth: "var(--measure-editorial)"
      }
    }, "Nine products on one execution platform. Shared auth, telemetry, and evidence model. Zero shared identity. Every system defends its own metaphor."), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 12,
        marginTop: 34,
        pointerEvents: "auto",
        flexWrap: "wrap"
      }
    }, /*#__PURE__*/React.createElement(Button, {
      size: "lg",
      variant: "primary",
      iconAfter: "arrow-right"
    }, "Request access"), /*#__PURE__*/React.createElement(Button, {
      size: "lg",
      variant: "secondary",
      icon: "play"
    }, "See the platform"))));
  }
  Object.assign(window, {
    FlagshipHero
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/neuruh-com/FlagshipHero.jsx", error: String((e && e.message) || e) }); }

// ui_kits/neuruh-com/FlagshipNav.jsx
try { (() => {
(() => {
  const {
    Button,
    IconButton,
    Wordmark
  } = window.NeuruhDesignSystem_5cb7e4;
  const LINKS = ["Platform", "Products", "Defense", "Evidence", "Company"];
  function FlagshipNav({
    solid,
    sheet,
    onSheet
  }) {
    return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("header", {
      style: {
        position: "fixed",
        top: 0,
        left: 0,
        right: 0,
        zIndex: 50,
        display: "flex",
        alignItems: "center",
        gap: 28,
        height: 64,
        padding: "0 clamp(20px, 4vw, 56px)",
        background: solid ? "rgba(10,10,15,0.82)" : "transparent",
        backdropFilter: solid ? "blur(14px) saturate(140%)" : "none",
        borderBottom: solid ? "1px solid var(--border-default)" : "1px solid transparent",
        transition: "background var(--dur-slow) var(--ease-standard), border-color var(--dur-slow) var(--ease-standard)"
      }
    }, /*#__PURE__*/React.createElement(Wordmark, {
      size: "md",
      monogram: solid,
      tone: "inverse",
      href: "#"
    }), /*#__PURE__*/React.createElement("nav", {
      className: "fs-links",
      style: {
        display: "flex",
        gap: 22,
        flex: 1
      }
    }, LINKS.map(l => /*#__PURE__*/React.createElement("a", {
      key: l,
      href: "#" + l.toLowerCase(),
      style: {
        font: "var(--type-ui)",
        color: "var(--ink-100)",
        textDecoration: "none"
      }
    }, l))), /*#__PURE__*/React.createElement("div", {
      className: "fs-cta",
      style: {
        display: "flex",
        alignItems: "center",
        gap: 10
      }
    }, /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      variant: "ghost"
    }, "Sign in"), /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      variant: "primary",
      iconAfter: "arrow-right"
    }, "Request access")), /*#__PURE__*/React.createElement("span", {
      className: "fs-burger",
      style: {
        display: "none"
      }
    }, /*#__PURE__*/React.createElement(IconButton, {
      icon: sheet ? "x" : "menu",
      label: "Menu",
      onClick: onSheet
    }))), sheet ? /*#__PURE__*/React.createElement("div", {
      style: {
        position: "fixed",
        inset: "64px 0 auto",
        zIndex: 49,
        background: "var(--ink-900)",
        borderBottom: "1px solid var(--border-strong)",
        padding: "12px 20px 20px",
        display: "flex",
        flexDirection: "column",
        gap: 4
      }
    }, LINKS.map(l => /*#__PURE__*/React.createElement("a", {
      key: l,
      href: "#" + l.toLowerCase(),
      onClick: onSheet,
      style: {
        font: "var(--type-h3)",
        color: "var(--paper-050)",
        textDecoration: "none",
        padding: "10px 0",
        borderBottom: "1px solid var(--border-subtle)"
      }
    }, l)), /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      block: true,
      iconAfter: "arrow-right",
      style: {
        marginTop: 12
      }
    }, "Request access")) : null);
  }
  Object.assign(window, {
    FlagshipNav
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/neuruh-com/FlagshipNav.jsx", error: String((e && e.message) || e) }); }

// ui_kits/neuruh-com/image-slot.js
try { (() => {
// @ds-adherence-ignore -- omelette starter scaffold (raw elements/hex/px by design)
// Copied omelette starter. Re-running copy_starter_component with this kind overwrites this file with the latest version (page content is unaffected).
/* BEGIN USAGE */
/**
 * <image-slot> — user-fillable image placeholder.
 *
 * Drop this into a deck, mockup, or page wherever a design needs an image.
 * You control the slot's shape; it sizes to its container by default. When the search_stock_photos tool
 * is available, prefill the slot by default — write the photo's URL into
 * src (with credit/credit-href); the user can still fill or replace it
 * by dragging an image file onto it (or clicking to browse). The dropped
 * image persists across reloads via a .image-slots.state.json sidecar —
 * same read-via-fetch / write-via-window.omelette pattern as
 * design_canvas.jsx, so the filled slot shows on share links, downloaded
 * zips, and PPTX export. Outside the omelette runtime the slot is read-only.
 *
 * The sidecar is a SIBLING of the HTML file that uses this component: the
 * read is a document-relative fetch, and the host resolves the bridge's
 * sidecar writes into the previewed file's directory to match (same
 * contract as design_canvas.jsx). Pages in the same directory share one
 * sidecar; keep slot ids distinct across them.
 *
 * Attributes:
 *   id           Persistence key. REQUIRED for the drop to survive reload —
 *                every slot on the page needs a distinct id.
 *   shape        'rect' | 'rounded' | 'circle' | 'pill'   (default 'rounded')
 *                'circle' applies 50% border-radius; on a non-square slot
 *                that's an ellipse — set equal width and height for a true
 *                circle.
 *   radius       Corner radius in px for 'rounded'.       (default 12)
 *   mask         Any CSS clip-path value. Overrides `shape` — use this for
 *                hexagons, blobs, arbitrary polygons.
 *   fit          Initial framing baseline: cover | contain.   (default 'cover')
 *                cover starts the image filling the frame (overflow cropped);
 *                contain starts it fully visible (letterboxed). Either way the
 *                user can always pan/scale from there — double-click, or the
 *                Edit control, enters reframe mode (drag to move, scroll or
 *                corner-handles to scale; Escape / click-out commits). The
 *                crop persists alongside the image in the sidecar.
 *   placeholder  Empty-state caption.                      (default 'Drop an image')
 *   src          Optional initial/fallback image URL. Prefill it with a real
 *                photo via search_stock_photos when that tool is available
 *                (set credit/credit-href from the result). A user drop
 *                overrides it; clearing the drop reveals src again.
 *   credit       Attribution text shown as a small overlay at the
 *                bottom-left of the filled slot. REQUIRED whenever src
 *                points at any Unsplash host (images.unsplash.com,
 *                plus.unsplash.com, …): an Unsplash src with no credit
 *                renders an error tile INSTEAD of the photo (Unsplash
 *                terms forbid showing their photos unattributed). Use the
 *                exact form 'Photo by {photographer name} on Unsplash' —
 *                the overlay then links the name to credit-href and
 *                'Unsplash' to the Unsplash homepage, and links back to
 *                unsplash.com automatically get the required utm referral
 *                params appended at render time. The credit belongs to
 *                the src image, so it only shows while src is what's
 *                displayed — a user-dropped image hides it.
 *   credit-href  Link for the photographer's name in the credit overlay
 *                (their Unsplash profile URL from the stock-photo search
 *                results). http(s) URLs only — anything else renders the
 *                name as plain text.
 *
 * Sizing: the slot fills its container by default (width/height 100%).
 * Put it in a sized wrapper — absolutely positioned, a grid cell, a fixed
 * frame — and it takes exactly that box. When the parent's height is
 * indefinite (ordinary flow), it falls back to full width at a 3:2 aspect
 * ratio instead of collapsing. In a shrink-to-fit parent (a float,
 * width:max-content, an unsized absolute wrapper), percentages have
 * nothing to resolve against — size the slot or its wrapper explicitly
 * there. For a fixed-size slot, set
 * width/height on the element itself (inline style), which overrides the
 * default. When
 * layering content above a slot (full-bleed layouts), make the overlay
 * click-through — pointer-events: none on scrims/text plates, re-enabled
 * on interactive children — so the slot's hover controls stay reachable.
 * Keep the slot's bottom-left corner visually clear as well: the credit
 * overlay renders there, and a dark fade or text plate covering it hides
 * the attribution Unsplash's terms require — end the fade above that
 * corner, or keep it nearly transparent where the credit sits.
 *
 * Usage:
 *   <div style="position:relative;width:100%;height:100%">      <!-- full-bleed: -->
 *     <image-slot id="bg" shape="rect"></image-slot>            <!-- fills the wrapper -->
 *   </div>
 *   <image-slot id="hero"   style="width:800px;height:450px" shape="rounded" radius="20"
 *               placeholder="Drop a hero image"></image-slot>
 *   <image-slot id="avatar" style="width:120px;height:120px" shape="circle"></image-slot>
 *   <image-slot id="kite"   style="width:300px;height:300px"
 *               mask="polygon(50% 0, 100% 50%, 50% 100%, 0 50%)"></image-slot>
 */
/* END USAGE */

(() => {
  const STATE_FILE = '.image-slots.state.json';

  // Unsplash terms require visible attribution wherever their photos
  // display, and every link back to unsplash.com must carry utm referral
  // params. Two render-time rules enforce that here:
  //  - an Unsplash-src slot with NO credit attribute renders an error
  //    tile INSTEAD of the photo (an uncredited Unsplash photo on screen
  //    is itself the terms violation, so it never renders bare);
  //  - rendered credit links pointing at unsplash.com get the referral
  //    params appended when absent (credit-href values live in page
  //    content that can't be edited after the fact).
  // Keep the utm_source value in sync with UTM_SOURCE in
  // platform/web-agent/unsplash.ts — this file is a project-local
  // artifact and cannot import it (equality is pinned by tests).
  const UNSPLASH_HOMEPAGE_HREF = 'https://unsplash.com/?utm_source=claude_design&utm_medium=referral';
  // Host rule mirrors the hotlink validator that admits Unsplash srcs into
  // pages in the first place (cdn$ in unsplash.ts: apex or any subdomain)
  // — Unsplash+ results serve from plus.unsplash.com, not just images.*,
  // and an admitted-but-uncredited photo must error whatever unsplash
  // host it rides on.
  // Trailing-dot FQDNs (images.unsplash.com.) are the same host to the
  // browser but would miss the regex — strip one dot so the check fails
  // CLOSED (unrecognized-but-real Unsplash srcs must error, not render).
  const isUnsplashHost = u => {
    try {
      return /(^|\.)unsplash\.com$/.test(new URL(u, document.baseURI).hostname.replace(/\.$/, ''));
    } catch {
      return false;
    }
  };
  // Render-time referral normalization for links back to Unsplash:
  // appends utm_source/utm_medium when absent, preserves every existing
  // query param, never overwrites an existing utm_source, and passes
  // non-Unsplash URLs through untouched. Input is an ABSOLUTE validated
  // http(s) URL (the credit render funnel resolves + validates first).
  const withReferral = href => {
    try {
      const u = new URL(href);
      if (!/(^|\.)unsplash\.com$/.test(u.hostname.replace(/\.$/, ''))) {
        return href;
      }
      if (!u.searchParams.has('utm_source')) {
        u.searchParams.set('utm_source', 'claude_design');
      }
      if (!u.searchParams.has('utm_medium')) {
        u.searchParams.set('utm_medium', 'referral');
      }
      return u.toString();
    } catch (e) {
      return href;
    }
  };
  // 2× a ~600px slot in a 1920-wide deck — retina-sharp without making the
  // sidecar enormous. A 1200px WebP at q=0.85 is ~150-300KB.
  const MAX_DIM = 1200;
  // Raster formats only. SVG is excluded (can carry script; createImageBitmap
  // on SVG blobs is inconsistent). GIF is excluded because the canvas
  // re-encode keeps only the first frame, so an animated GIF would silently
  // go still — better to reject than surprise.
  const ACCEPT = ['image/png', 'image/jpeg', 'image/webp', 'image/avif'];

  // ── Shared sidecar store ────────────────────────────────────────────────
  // One fetch + immediate write-on-change for every <image-slot> on the
  // page. Reads via fetch() so viewing works anywhere the HTML and sidecar
  // are served together; writes go through window.omelette.writeFile, which
  // the host allowlists to *.state.json basenames only.
  const subs = new Set();
  let slots = {};
  // ids explicitly cleared before the sidecar fetch resolved — otherwise
  // the merge below can't tell "never set" from "just deleted" and would
  // resurrect the sidecar's stale value.
  const tombstones = new Set();
  let loaded = false;
  let loadP = null;
  function load() {
    if (loadP) return loadP;
    loadP = fetch(STATE_FILE).then(r => r.ok ? r.json() : null).then(j => {
      // Merge: sidecar loses to any in-memory change that raced ahead of
      // the fetch (drop or clear) so neither is clobbered by hydration.
      if (j && typeof j === 'object') {
        const merged = Object.assign({}, j, slots);
        // A framing-only write that raced ahead of hydration must not
        // drop a user image that's only on disk — inherit u from the
        // sidecar for any in-memory entry that lacks one.
        for (const k in slots) {
          if (merged[k] && !merged[k].u && j[k]) {
            merged[k].u = typeof j[k] === 'string' ? j[k] : j[k].u;
          }
        }
        for (const id of tombstones) delete merged[id];
        slots = merged;
      }
      tombstones.clear();
    }).catch(() => {}).then(() => {
      loaded = true;
      subs.forEach(fn => fn());
    });
    return loadP;
  }

  // Serialize writes so two near-simultaneous drops on different slots
  // can't reorder at the backend and leave the sidecar with only the
  // first. A save requested mid-flight just marks dirty and re-fires on
  // completion with the then-current slots.
  let saving = false;
  let saveDirty = false;
  // Unload-time flush: save()'s serialization defers a mid-RTT re-fire to a
  // .then that never runs in an unloading document, silently dropping a
  // pagehide commit. Post the current slots immediately instead — content
  // is a superset snapshot of any in-flight save's, the write is a
  // whole-file last-writer-wins replace, and postMessage FIFO delivers it
  // to the host after the in-flight one, so a backend-side reorder at
  // worst reproduces the dropped-commit outcome this flush improves on.
  // Guarded on the initial sidecar read: pre-hydration slots can miss
  // other slots' persisted entries, and flushing it would clobber them —
  // that narrow case stays best-effort (the in-memory merge in load()
  // cannot happen in an unloading document anyway).
  function flushNow() {
    if (!loaded) return;
    const w = window.omelette && window.omelette.writeFile;
    if (!w) return;
    try {
      Promise.resolve(w(STATE_FILE, JSON.stringify(slots))).catch(() => {});
    } catch (e) {}
  }
  function save() {
    if (saving) {
      saveDirty = true;
      return;
    }
    const w = window.omelette && window.omelette.writeFile;
    if (!w) return;
    saving = true;
    Promise.resolve(w(STATE_FILE, JSON.stringify(slots))).catch(() => {}).then(() => {
      saving = false;
      if (saveDirty) {
        saveDirty = false;
        save();
      }
    });
  }
  const S_MAX = 5;
  const clampS = s => Math.max(1, Math.min(S_MAX, s));

  // Normalize a stored slot value. Pre-reframe sidecars stored a bare
  // data-URL string; newer ones store {u, s, x, y}. Either shape is valid.
  function getSlot(id) {
    const v = slots[id];
    if (!v) return null;
    return typeof v === 'string' ? {
      u: v,
      s: 1,
      x: 0,
      y: 0
    } : v;
  }
  function setSlot(id, val) {
    if (!id) return;
    if (val) {
      slots[id] = val;
      tombstones.delete(id);
    } else {
      delete slots[id];
      if (!loaded) tombstones.add(id);
    }
    subs.forEach(fn => fn());
    // A drop is rare + high-value — write immediately so nav-away can't lose
    // it. Gate on the initial read so we don't overwrite a sidecar we haven't
    // merged yet; the merge in load() keeps this change once the read lands.
    if (loaded) save();else load().then(save);
  }

  // ── Image downscale ─────────────────────────────────────────────────────
  // Encode through a canvas so the sidecar carries resized bytes, not the
  // raw upload. Longest side is capped at 2× the slot's rendered width
  // (retina) and at MAX_DIM. WebP keeps alpha and is ~10× smaller than PNG
  // for photos, so there's no need for per-image format picking.
  async function toDataUrl(file, targetW) {
    const bitmap = await createImageBitmap(file);
    try {
      const cap = Math.min(MAX_DIM, Math.max(1, Math.round(targetW * 2)) || MAX_DIM);
      const scale = Math.min(1, cap / Math.max(bitmap.width, bitmap.height));
      const w = Math.max(1, Math.round(bitmap.width * scale));
      const h = Math.max(1, Math.round(bitmap.height * scale));
      const canvas = document.createElement('canvas');
      canvas.width = w;
      canvas.height = h;
      canvas.getContext('2d').drawImage(bitmap, 0, 0, w, h);
      return canvas.toDataURL('image/webp', 0.85);
    } finally {
      bitmap.close && bitmap.close();
    }
  }

  // ── Custom element ──────────────────────────────────────────────────────
  const stylesheet =
  // Fill the container by default: slots are usually placed inside a
  // sized wrapper (a hero frame, a grid cell, an inset:0 layer) and are
  // expected to take that box — a fixed intrinsic size would render as
  // a small tile in the corner of a full-bleed wrapper instead.
  // aspect-ratio is the companion fallback that keeps a bare slot
  // visible when the parent's height is indefinite: height:100%
  // resolves to auto there, and the ratio then derives height from
  // width instead of letting the slot collapse to zero height.
  // Explicit width/height on the element override all of this.
  // color:inherit (not a fixed near-black): the placeholder chrome —
  // empty-state icon/caption (currentColor) and the dashed ring — must
  // read on dark decks too, and the slide's own text color is the one
  // color guaranteed to contrast with the slide background. The soft
  // look comes from opacity on those parts, not from a baked-in alpha.
  ':host{display:block;position:relative;' + '  font:13px/1.3 system-ui,-apple-system,sans-serif;' + '  width:100%;height:100%;aspect-ratio:3/2}' + '.empty .cap,.empty .sub{opacity:.75}' + '.frame{position:absolute;inset:0;overflow:hidden;background:rgba(127,127,127,.08)}' +
  // .frame img (clipped) and .spill (unclipped ghost + handles) share the
  // same left/top/width/height in frame-%, computed by _applyView(), so the
  // inside-mask crop and the outside-mask spill stay pixel-aligned.
  '.frame img{position:absolute;max-width:none;transform:translate(-50%,-50%);' + '  -webkit-user-drag:none;user-select:none;touch-action:none}' +
  // Reframe mode (double-click): the full image spills past the mask. The
  // spill layer is sized to the IMAGE bounds so its corners are where the
  // resize handles belong. The ghost <img> inside is translucent; the real
  // clipped <img> underneath shows the opaque in-mask crop.
  // popover=manual promotes the spill to the top layer on reframe, so it is
  // not clipped by any overflow:hidden / clip-path / scroll-container
  // ancestor (a plain z-index can't escape overflow clipping). UA popover
  // defaults (inset:0;margin:auto) are reset; _applyView sets viewport px.
  '.spill{position:fixed;margin:0;inset:auto;border:0;padding:0;background:transparent;' + '  overflow:visible;transform:translate(-50%,-50%);z-index:1;cursor:grab;touch-action:none}' + ':host([data-panning]) .spill{cursor:grabbing}' + '.spill .ghost{position:absolute;inset:0;width:100%;height:100%;opacity:.35;' + '  pointer-events:none;-webkit-user-drag:none;user-select:none;' + '  box-shadow:0 0 0 1px rgba(0,0,0,.2),0 12px 32px rgba(0,0,0,.2)}' + '.spill .handle{position:absolute;width:12px;height:12px;border-radius:50%;' + '  background:#fff;box-shadow:0 0 0 1.5px #c96442,0 1px 3px rgba(0,0,0,.3);' + '  transform:translate(-50%,-50%)}' + '.spill .handle[data-c=nw]{left:0;top:0;cursor:nwse-resize}' + '.spill .handle[data-c=ne]{left:100%;top:0;cursor:nesw-resize}' + '.spill .handle[data-c=sw]{left:0;top:100%;cursor:nesw-resize}' + '.spill .handle[data-c=se]{left:100%;top:100%;cursor:nwse-resize}' + ':host([data-reframe]){z-index:10}' + ':host([data-reframe]) .frame{box-shadow:0 0 0 2px #c96442}' + '.empty{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;' + '  justify-content:center;gap:6px;text-align:center;padding:12px;box-sizing:border-box;' + '  cursor:pointer;user-select:none}' + '.empty svg{opacity:.45}' + '.empty .cap{max-width:90%;font-weight:500;letter-spacing:.01em}' + '.empty .sub{font-size:11px}' + '.empty .sub u{text-underline-offset:2px}' + '.empty:hover .sub{opacity:1}' + ':host([data-over]) .frame{outline:2px solid #c96442;outline-offset:-2px;' + '  background:rgba(201,100,66,.10)}' + '.ring{position:absolute;inset:0;pointer-events:none;border:1.5px dashed currentColor;' + '  opacity:.35;transition:border-color .12s,opacity .12s}' + ':host([data-over]) .ring{border-color:#c96442;opacity:1}' + ':host([data-filled]) .ring{display:none}' +
  // Controls overlay INSIDE the frame, pinned to the top-right corner, so
  // a full-bleed slot in an overflow:hidden container still shows them
  // (the old below-mask placement got clipped). Credit sits bottom-left,
  // so top-right avoids collision. The blurred pill background keeps them
  // legible over the image.
  // The UA [popover] base rule styles the element in EVERY state (only
  // display:none is gated on :not(:popover-open), and the display:flex
  // below overrides that) — so the UA resets live HERE, like .spill's,
  // or the ordinary hover-state strip renders as a bordered Canvas box
  // centered by margin:auto. inset:auto precedes top/right (shorthand).
  '.ctl{position:absolute;inset:auto;top:8px;right:8px;margin:0;border:0;padding:0;' + '  background:transparent;overflow:visible;' + '  display:flex;gap:6px;opacity:0;pointer-events:none;transition:opacity .12s;z-index:2;' + '  white-space:nowrap}' +
  // While reframing, the spill owns the top layer and would swallow every
  // click on the in-frame controls. Promoting .ctl into the top layer
  // ABOVE the spill (shown after it — later popovers stack higher) keeps
  // Edit-as-toggle and Replace clickable mid-reframe. _applyView pins it
  // to the frame's top-right in viewport px (translateX(-100%)
  // right-aligns against the computed left edge); inset:auto clears the
  // base rule's top/right so the inline left/top position it alone.
  '.ctl:popover-open{position:fixed;inset:auto;transform:translateX(-100%)}' + ':host([data-filled][data-editable]:hover) .ctl,:host([data-reframe]) .ctl' + '  {opacity:1;pointer-events:auto}' + '.ctl button{appearance:none;border:0;border-radius:6px;padding:5px 10px;cursor:pointer;' + '  background:rgba(0,0,0,.65);color:#fff;font:11px/1 system-ui,-apple-system,sans-serif;' + '  backdrop-filter:blur(6px)}' + '.ctl button:hover{background:rgba(0,0,0,.8)}' + '.err{position:absolute;left:8px;bottom:8px;right:8px;color:#b3261e;font-size:11px;' + '  background:rgba(255,255,255,.85);padding:4px 6px;border-radius:5px;pointer-events:none}' +
  // Replacement in flight: after a src swap the browser keeps painting
  // the PREVIOUS image until the new one decodes, so a Replace would
  // flash the old photo and then pop. Hide the stale frame (visibility,
  // not display — _applyView geometry still applies) and spin until the
  // new image reports in (load/error clears data-swapping).
  ':host([data-swapping]) .frame img{visibility:hidden}' + '.loading{position:absolute;inset:0;display:none;align-items:center;' + '  justify-content:center;pointer-events:none}' + ':host([data-swapping]) .loading{display:flex}' + '.loading::after{content:"";width:22px;height:22px;border-radius:50%;' + '  border:2px solid rgba(127,127,127,.25);border-top-color:currentColor;' + '  animation:om-slot-spin .7s linear infinite}' + '@keyframes om-slot-spin{to{transform:rotate(360deg)}}' +
  // Reduced motion: the static two-tone ring still reads as "working".
  '@media (prefers-reduced-motion:reduce){.loading::after{animation:none}}' + '.credit{position:absolute;left:6px;bottom:6px;max-width:calc(100% - 12px);display:none;' + '  padding:3px 7px;border-radius:5px;background:rgba(0,0,0,.55);color:#fff;' + '  font:10px/1.2 system-ui,-apple-system,sans-serif;text-decoration:none;' + '  white-space:nowrap;overflow:hidden;text-overflow:ellipsis;backdrop-filter:blur(6px)}' +
  // The credit is a SPAN holding one or two <a>s (Unsplash's prescribed
  // form links the photographer AND Unsplash) — anchors style inline so
  // the overlay reads as one line of text.
  '.credit a{color:inherit;text-decoration:none}' + '.credit a:hover,.credit a:focus-visible{text-decoration:underline}' + ':host([data-filled][data-credit]) .credit{display:block}' +
  // Exports must ship JUST the image — no hover controls, no credit chip
  // (the host marks <html data-om-exporting> for the capture window; the
  // page-level hide script can't reach shadow DOM, this rule can).
  ':host-context([data-om-exporting]) .ctl,' + ':host-context([data-om-exporting]) .credit{display:none !important}' +
  // Print must ship just the image too: the hover-gated controls can be
  // mid-hover when print() fires, and the credit chip is screen chrome —
  // the same rule the capture window gets, keyed on print media instead
  // of the host's data-om-exporting mark (the print path sets no mark).
  '@media print{.ctl,.credit{display:none !important}}' +
  // No export-window mask rules here on purpose: the export capture
  // releases the replacement mask by REMOVING data-swapping (the
  // shadow-root pass in pages/export/shared.ts HIDE_EXPORT_CHROME_SCRIPT)
  // — attribute removal works in every engine (:host-context is
  // Chromium-only), is scoped by construction to slots actually
  // mid-swap, and hides the spinner through the same gate. A masked img
  // would otherwise be silently dropped from PPTX decks (the capture
  // walk skips visibility:hidden imgs).
  // Attribution error tile: REPLACES the photo when an Unsplash src has
  // no credit attribute — rendering the photo uncredited is the terms
  // violation, so the photo must not appear at all.
  // Calm and neutral on purpose (review feedback): the tile informs the
  // user; the fix instructions are machine-facing (usage docblock, tool
  // description, and the turn-end scan's bounce copy name the attributes
  // for the agent).
  '.attr-error{position:absolute;inset:0;display:none;flex-direction:column;align-items:center;' + '  justify-content:center;gap:6px;text-align:center;padding:12px;box-sizing:border-box;' + '  background:#f2f1ef;color:#6e6c66;user-select:none;' + '  font:13px/1.45 system-ui,-apple-system,sans-serif}' + '.attr-error svg{opacity:.55}' + '.attr-error .cap{max-width:92%;font-weight:500;letter-spacing:.01em}' + ':host([data-attribution-error]) .attr-error{display:flex}' + ':host([data-attribution-error]) .ring{display:none}';
  const icon = '<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" ' + 'stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">' + '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/>' + '<path d="m21 15-5-5L5 21"/></svg>';
  const warnIcon = '<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" ' + 'stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">' + '<path d="m21.73 18-8-14a2 2 0 0 0-3.46 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3"/>' + '<path d="M12 9v4"/><path d="M12 17h.01"/></svg>';
  class ImageSlot extends HTMLElement {
    static get observedAttributes() {
      return ['shape', 'radius', 'mask', 'fit', 'placeholder', 'src', 'id', 'credit', 'credit-href'];
    }

    /** Duplicate-slide hook (called by deck-stage, see its
     *  _remintDuplicateIds): copy this id's stored image, if any, under a
     *  freshly minted key and return that key — so a duplicated slide's
     *  slot keeps its dropped photo instead of reverting to the
     *  placeholder. 'isFree' is the caller's uniqueness check (document
     *  ids); candidates must ALSO be unused in the sidecar, which can
     *  hold keys from other pages sharing the project root. (An EMPTY
     *  slot on another page leaves no sidecar entry, so its id is not
     *  detectable here — a minted key can collide with it and that slot
     *  would show this photo. Same blast radius as two pages reusing an
     *  id by hand, which the shared sidecar already permits.) Returns null
     *  when no id could be minted (caller strips the id, today's
     *  behavior). */
    static cloneSlot(fromId, isFree) {
      if (typeof fromId !== 'string' || !fromId) return null;
      // Pre-hydration the store can't veto candidates or source the copy
      // — degrade to the strip (today's behavior) rather than mint
      // against keys we can't see yet. Any rendered (= droppable) slot
      // means load() has already settled.
      if (!loaded) return null;
      const stem = fromId.replace(/-\d+$/, '') || fromId;
      for (let n = 2; n < 100; n++) {
        const toId = stem + '-' + n;
        if (toId === fromId) continue;
        if (slots[toId] !== undefined) {
          // Reuse a key holding this exact value (bytes AND crop) if no
          // live element here owns it — a duplicate op the host refused
          // after minting leaves such a key behind, and reusing keeps
          // refused retries from accumulating one orphaned copy per
          // attempt. Full equality (not just bytes) so a byte-identical
          // key another PAGE owns with its own crop is stepped past, not
          // adopted or rewritten. (Entries without .u never match.)
          const prev = getSlot(toId);
          const cur = getSlot(fromId);
          if (!(prev && cur && prev.u && prev.u === cur.u && prev.s === cur.s && prev.x === cur.x && prev.y === cur.y && (typeof isFree !== 'function' || isFree(toId)))) continue;
          return toId;
        }
        if (typeof isFree === 'function' && !isFree(toId)) continue;
        const v = getSlot(fromId);
        if (v) setSlot(toId, Object.assign({}, v));
        return toId;
      }
      return null;
    }
    constructor() {
      super();
      // clonable: rail thumbnails deep-clone slides and carry this shadow
      // along; reuse an already-cloned root so upgrade-after-clone works.
      // (Deliberately NOT serializable — a getHTML consumer would embed
      // multi-MB sidecar data-URLs into serialized page HTML.)
      const root = this.shadowRoot || this.attachShadow({
        mode: 'open',
        clonable: true
      });
      // .spill and .ctl sit OUTSIDE .frame so overflow:hidden + border-radius
      // on the frame (circle, pill, rounded) can't clip them.
      root.innerHTML = '<style>' + stylesheet + '</style>' + '<div class="frame" part="frame">' + '  <img part="image" alt="" draggable="false" style="display:none">' + '  <div class="empty" part="empty">' + icon + '    <div class="cap"></div>' + '    <div class="sub">or <u>browse files</u></div></div>' + '  <div class="attr-error" part="attribution-error">' + warnIcon + '    <div class="cap">This photo needs attribution</div></div>' + '  <div class="loading" part="loading"></div>' + '  <div class="ring" part="ring"></div>' + '</div>' +
      // Outside .frame, like .spill/.ctl — the frame's overflow:hidden +
      // border-radius/clip-path would cut the credit off on circle/pill/mask.
      // A SPAN, not an <a>: the prescribed Unsplash credit holds two links
      // (photographer + Unsplash), built per-render in _render().
      '<span class="credit" part="credit"></span>' + '<div class="spill" popover="manual" data-dc-edit-transparent>' + '  <img class="ghost" alt="" draggable="false">' + '  <div class="handle" data-c="nw"></div><div class="handle" data-c="ne"></div>' + '  <div class="handle" data-c="sw"></div><div class="handle" data-c="se"></div>' + '</div>' +
      // data-dc-edit-transparent: the DC editor's edit-mode picker lets
      // clicks through for chrome marked with it (EDIT_TRANSPARENT_SEL)
      // — without it, Replace/Edit clicks in Edit mode are swallowed by
      // element selection and the controls look dead.
      '<div class="ctl" popover="manual" data-dc-edit-transparent><button data-act="replace" title="Replace image">Replace</button>' + '  <button data-act="edit" title="Reframe image">Edit</button></div>' + '<input type="file" accept="' + ACCEPT.join(',') + '" hidden>';
      this._frame = root.querySelector('.frame');
      this._ring = root.querySelector('.ring');
      this._img = root.querySelector('.frame img');
      this._empty = root.querySelector('.empty');
      this._cap = root.querySelector('.cap');
      this._sub = root.querySelector('.sub');
      this._spill = root.querySelector('.spill');
      this._ctl = root.querySelector('.ctl');
      this._credit = root.querySelector('.credit');
      this._attrError = root.querySelector('.attr-error');
      // Credit clicks open the link, not browse/reframe.
      this._credit.addEventListener('click', e => e.stopPropagation());
      this._credit.addEventListener('dblclick', e => e.stopPropagation());
      this._ghost = root.querySelector('.ghost');
      this._err = null;
      this._input = root.querySelector('input');
      this._depth = 0;
      this._gen = 0;
      // Encode-in-flight marker (the owning _ingest generation): while set,
      // the same-src "nothing in flight" clear in _render must not fire —
      // the stored value still points at the OLD image until the encode
      // lands, so that clear would unmask the stale image mid-replace.
      this._swapGen = 0;
      // Render-owned swap in flight: set when _render assigns a new src,
      // cleared only by the img's own load/error (or the empty branch).
      // img.complete CANNOT stand in for this — setting src only QUEUES
      // the current-request swap (a microtask), so synchronously after an
      // assignment, complete still reports the OLD settled request. The
      // pick path does exactly that: the host sets src, credit, and
      // credit-href back-to-back in one task, and renders #2/#3 would
      // read the stale complete === true and drop the mask one render
      // after it was set.
      this._loadPending = false;
      // See _render's empty branch: a transient attribution-error wipe of a
      // showing image must make the follow-up render a replacement (spinner),
      // not a first fill (blank frame).
      this._hidShowing = false;
      this._view = {
        s: 1,
        x: 0,
        y: 0
      };
      this._subFn = () => this._render();
      // Shadow-DOM listeners live with the shadow DOM — bound once here so
      // disconnect/reconnect (e.g. React remount) doesn't stack handlers.
      this._empty.addEventListener('click', () => this._input.click());
      root.addEventListener('click', e => {
        const act = e.target && e.target.getAttribute && e.target.getAttribute('data-act');
        if (!act) return;
        // The hidden controls are opacity-0 but still tabbable — without
        // this gate a keyboard user could drive them on a read-only share
        // link (mirrors the dblclick handler's editable gate).
        if (!this.hasAttribute('data-editable')) return;
        if (act === 'replace') {
          this._exitReframe(true);
          // Host-owned picker (Unsplash modal; it also offers local import).
          this.dispatchEvent(new CustomEvent('image-slot:pick', {
            bubbles: true,
            composed: true,
            detail: {
              id: this.id || null
            }
          }));
        }
        if (act === 'edit') {
          if (!this._reframes()) return;
          if (this.hasAttribute('data-reframe')) this._exitReframe(true);else this._enterReframe();
        }
      });
      this._input.addEventListener('change', () => {
        const f = this._input.files && this._input.files[0];
        if (f) this._ingest(f);
        this._input.value = '';
      });
      // naturalWidth/Height aren't known until load — re-apply so the cover
      // baseline is computed from real dimensions, not the 100%×100% fallback.
      // load/error also release the replacement-in-flight mask (via the
      // single discipline in _releaseMask): the swap is only revealed once
      // the new image can actually paint (on error the frame shows its
      // background, same as a fresh slot with a broken src).
      this._img.addEventListener('load', () => {
        this._loadPending = false;
        this._releaseMask(true);
        this._applyView();
      });
      this._img.addEventListener('error', () => {
        this._loadPending = false;
        this._releaseMask(true);
      });
      // Gated only on editable — any filled slot can be repositioned/scaled,
      // regardless of fit. Share links (no writeFile) stay static.
      this.addEventListener('dblclick', e => {
        if (!this.hasAttribute('data-editable') || !this._reframes()) return;
        e.preventDefault();
        if (this.hasAttribute('data-reframe')) this._exitReframe(true);else this._enterReframe();
      });
      // Pan + resize both originate on the spill layer. A handle pointerdown
      // drives an aspect-locked resize anchored at the opposite corner; any
      // other pointerdown on the spill pans. Offsets are frame-% so a
      // reframed slot survives responsive resize / PPTX export.
      this._spill.addEventListener('pointerdown', e => {
        if (e.button !== 0 || !this.hasAttribute('data-reframe')) return;
        e.preventDefault();
        e.stopPropagation();
        this._spill.setPointerCapture(e.pointerId);
        const rect = this.getBoundingClientRect();
        const fw = rect.width || 1,
          fh = rect.height || 1;
        const corner = e.target.getAttribute && e.target.getAttribute('data-c');
        let move;
        if (corner) {
          // Resize about the OPPOSITE corner. Viewport-px throughout (rect
          // fw/fh, not clientWidth) so the math survives a transform:scale()
          // ancestor — deck_stage renders slides scaled-to-fit.
          const iw = this._img.naturalWidth || 1,
            ih = this._img.naturalHeight || 1;
          const contain = (this.getAttribute('fit') || 'cover').toLowerCase() === 'contain';
          const base = contain ? Math.min(fw / iw, fh / ih) : Math.max(fw / iw, fh / ih);
          const sx = corner.includes('e') ? 1 : -1;
          const sy = corner.includes('s') ? 1 : -1;
          const s0 = this._view.s;
          const w0 = iw * base * s0,
            h0 = ih * base * s0;
          const cx0 = (50 + this._view.x) / 100 * fw;
          const cy0 = (50 + this._view.y) / 100 * fh;
          const ox = cx0 - sx * w0 / 2,
            oy = cy0 - sy * h0 / 2;
          const diag0 = Math.hypot(w0, h0);
          const ux = sx * w0 / diag0,
            uy = sy * h0 / diag0;
          move = ev => {
            const proj = (ev.clientX - rect.left - ox) * ux + (ev.clientY - rect.top - oy) * uy;
            const s = clampS(s0 * proj / diag0);
            const d = diag0 * s / s0;
            this._view.s = s;
            this._view.x = (ox + ux * d / 2) / fw * 100 - 50;
            this._view.y = (oy + uy * d / 2) / fh * 100 - 50;
            this._clampView();
            this._applyView();
          };
        } else {
          this.setAttribute('data-panning', '');
          const start = {
            px: e.clientX,
            py: e.clientY,
            x: this._view.x,
            y: this._view.y
          };
          move = ev => {
            this._view.x = start.x + (ev.clientX - start.px) / fw * 100;
            this._view.y = start.y + (ev.clientY - start.py) / fh * 100;
            this._clampView();
            this._applyView();
          };
        }
        const up = () => {
          try {
            this._spill.releasePointerCapture(e.pointerId);
          } catch {}
          this._spill.removeEventListener('pointermove', move);
          this._spill.removeEventListener('pointerup', up);
          this._spill.removeEventListener('pointercancel', up);
          this.removeAttribute('data-panning');
          this._dragUp = null;
        };
        // Stashed so _exitReframe (Escape / outside-click mid-drag) can
        // tear the capture + listeners down synchronously.
        this._dragUp = up;
        this._spill.addEventListener('pointermove', move);
        this._spill.addEventListener('pointerup', up);
        this._spill.addEventListener('pointercancel', up);
      });
      // Wheel zoom stays available inside reframe mode as a trackpad nicety —
      // zooms toward the cursor (offset' = cursor·(1-k) + offset·k).
      this.addEventListener('wheel', e => {
        if (!this.hasAttribute('data-reframe')) return;
        e.preventDefault();
        const r = this.getBoundingClientRect();
        const cx = (e.clientX - r.left) / r.width * 100 - 50;
        const cy = (e.clientY - r.top) / r.height * 100 - 50;
        const prev = this._view.s;
        const next = clampS(prev * Math.pow(1.0015, -e.deltaY));
        if (next === prev) return;
        const k = next / prev;
        this._view.s = next;
        this._view.x = cx * (1 - k) + this._view.x * k;
        this._view.y = cy * (1 - k) + this._view.y * k;
        this._clampView();
        this._applyView();
      }, {
        passive: false
      });
    }
    connectedCallback() {
      // Warn once per page — an id-less slot works for the session but
      // cannot persist, and two id-less slots would share nothing.
      if (!this.id && !ImageSlot._warned) {
        ImageSlot._warned = true;
        console.warn('<image-slot> without an id will not persist its dropped image.');
      }
      this.addEventListener('dragenter', this);
      this.addEventListener('dragover', this);
      this.addEventListener('dragleave', this);
      this.addEventListener('drop', this);
      subs.add(this._subFn);
      // The host may inject window.omelette.writeFile AFTER the first render;
      // re-render on hover so the editable-gated controls reliably appear.
      this.addEventListener('pointerenter', this._subFn);
      // width%/height% in _applyView encode the frame aspect at call time —
      // a host resize (responsive grid, pane divider) would stretch the
      // image until the next _render. Re-render on size change: _render()
      // re-seeds _view from stored before clamp/apply, so a shrink→grow
      // cycle round-trips instead of ratcheting x/y toward the narrower
      // frame's clamp range.
      this._ro = new ResizeObserver(() => this._render());
      this._ro.observe(this);
      load();
      this._render();
    }
    disconnectedCallback() {
      subs.delete(this._subFn);
      this.removeEventListener('pointerenter', this._subFn);
      this.removeEventListener('dragenter', this);
      this.removeEventListener('dragover', this);
      this.removeEventListener('dragleave', this);
      this.removeEventListener('drop', this);
      if (this._ro) {
        this._ro.disconnect();
        this._ro = null;
      }
      // commit=false: a disconnect is not a user intent — committing here
      // would persist whatever half-finished drag a React remount or DOM
      // splice happened to interrupt. Deliberate exits commit on their own
      // paths (Escape/click-out/toggle), and unloads commit via pagehide.
      this._exitReframe(false);
    }
    _enterReframe() {
      if (this.hasAttribute('data-reframe')) return;
      this.setAttribute('data-reframe', '');
      this._signalReframe(true);
      // Best-effort commit when the document unloads mid-reframe (a host
      // navigation racing the enter signal, a manual reload, tab close):
      // the sidecar write rides the host bridge, which outlives this
      // document, so the crop survives even though the mode dies with the
      // DOM. Held on the instance so _exitReframe detaches exactly what
      // was attached.
      this._pagehide = () => {
        this._exitReframe(true);
        flushNow();
      };
      window.addEventListener('pagehide', this._pagehide);
      // Promote spill to the top layer, then keep it pinned over the frame:
      // scroll/resize cover the common cases, and a per-frame rect check
      // catches layout shifts that fire neither (an image above finishing
      // load, streamed DOM pushing the slot down, an ancestor transform
      // change) so the overlay can't detach from the frame.
      try {
        this._spill.showPopover();
      } catch {}
      // After the spill, so the controls stack above it in the top layer.
      try {
        this._ctl.showPopover();
      } catch {}
      this._reposition = () => {
        if (this.hasAttribute('data-reframe')) this._applyView();
      };
      window.addEventListener('scroll', this._reposition, true);
      window.addEventListener('resize', this._reposition);
      this._lastRect = '';
      this._watch = () => {
        if (!this.hasAttribute('data-reframe')) return;
        const r = this.getBoundingClientRect();
        const key = r.left + ',' + r.top + ',' + r.width + ',' + r.height;
        if (key !== this._lastRect) {
          this._lastRect = key;
          this._applyView();
        }
        this._watchId = requestAnimationFrame(this._watch);
      };
      this._watchId = requestAnimationFrame(this._watch);
      this._applyView();
      // Close on click outside (the spill handler stopPropagation()s so
      // in-image drags don't reach this) and on Escape. Listeners are held
      // on the instance so _exitReframe / disconnectedCallback can detach
      // exactly what was attached.
      this._outside = e => {
        if (e.composedPath && e.composedPath().includes(this)) return;
        this._exitReframe(true);
      };
      this._esc = e => {
        if (e.key === 'Escape') this._exitReframe(true);
      };
      document.addEventListener('pointerdown', this._outside, true);
      document.addEventListener('keydown', this._esc, true);
    }
    _exitReframe(commit) {
      if (!this.hasAttribute('data-reframe')) return;
      if (this._dragUp) this._dragUp();
      this.removeAttribute('data-reframe');
      this.removeAttribute('data-panning');
      if (this._outside) document.removeEventListener('pointerdown', this._outside, true);
      if (this._esc) document.removeEventListener('keydown', this._esc, true);
      this._outside = this._esc = null;
      if (this._reposition) {
        window.removeEventListener('scroll', this._reposition, true);
        window.removeEventListener('resize', this._reposition);
        this._reposition = null;
      }
      if (this._watchId) {
        cancelAnimationFrame(this._watchId);
        this._watchId = 0;
      }
      if (this._pagehide) {
        window.removeEventListener('pagehide', this._pagehide);
        this._pagehide = null;
      }
      try {
        this._spill.hidePopover();
      } catch {}
      try {
        this._ctl.hidePopover();
      } catch {}
      this._ctl.style.left = '';
      this._ctl.style.top = '';
      if (commit) this._commitView();
      this._signalReframe(false);
    }

    // Reframe state lives only in this DOM until commit, invisible to the
    // host's dirty signals — announce enter/exit so the host can hold
    // auto-reloads for exactly the gesture (the guest bundle forwards
    // image-slot:reframe to the host as imageSlotReframe). Dispatched on
    // the element (composed, so it escapes shadow roots) while connected;
    // a disconnected exit (disconnectedCallback) falls back to document so
    // the host still hears it.
    _signalReframe(active) {
      const target = this.isConnected ? this : document;
      target.dispatchEvent(new CustomEvent('image-slot:reframe', {
        bubbles: true,
        composed: true,
        detail: {
          active: active,
          id: this.id || null
        }
      }));
    }

    // Public: host's "Import from computer" calls this to run local browse.
    openFilePicker() {
      this._exitReframe(true);
      this._input.click();
    }

    // A src write is a newer intent for this slot's content — the host
    // pick path (setImageSlotImage) or an agent edit — so it must win
    // over any encode still in flight from an earlier drop: left live,
    // that encode lands later, passes _ingest's gen guard, and its
    // setSlot silently overwrites the pick (the stored value shadows
    // src in _render). Bumping _gen kills the encode before its own
    // _swapGen clear runs, so clear the dead claim here too — otherwise
    // _releaseMask (gated on !_swapGen) never fires and the pick's
    // spinner is stranded. src ONLY: the pick sets credit/credit-href
    // in the same task, and clearing _swapGen on those would let the
    // same-src branch unmask the old image mid-encode.
    attributeChangedCallback(name, oldVal, newVal) {
      if (name === 'src' && oldVal !== newVal) {
        this._gen++;
        this._swapGen = 0;
      }
      if (this.shadowRoot) this._render();
    }

    // handleEvent — one listener object for all four drag events keeps the
    // add/remove symmetric and the depth counter correct.
    handleEvent(e) {
      if (e.type === 'dragenter' || e.type === 'dragover') {
        // Without preventDefault the browser never fires 'drop'.
        e.preventDefault();
        e.stopPropagation();
        if (e.dataTransfer) e.dataTransfer.dropEffect = 'copy';
        if (e.type === 'dragenter') this._depth++;
        this.setAttribute('data-over', '');
      } else if (e.type === 'dragleave') {
        // dragenter/leave fire for every descendant crossing — count depth
        // so hovering the icon inside the empty state doesn't flicker.
        if (--this._depth <= 0) {
          this._depth = 0;
          this.removeAttribute('data-over');
        }
      } else if (e.type === 'drop') {
        e.preventDefault();
        e.stopPropagation();
        this._depth = 0;
        this.removeAttribute('data-over');
        const f = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
        if (f) this._ingest(f);
      }
    }
    async _ingest(file) {
      this._setError(null);
      if (!file || ACCEPT.indexOf(file.type) < 0) {
        this._setError('Drop a PNG, JPEG, WebP, or AVIF image.');
        return;
      }
      // toDataUrl can take hundreds of ms on a large photo. A Clear or a
      // newer drop during that window would be clobbered when this await
      // resumes — bump + capture a generation so stale encodes bail.
      const gen = ++this._gen;
      // Replacing a shown image: surface the swap through the encode too,
      // not just the decode — otherwise the old photo sits there with no
      // feedback while the canvas re-encode runs. An empty slot keeps its
      // placeholder (no spinner) until the encode lands, as before.
      // _swapGen guards the mask against re-renders DURING the encode
      // (pointerenter, ResizeObserver, another slot's store write): the
      // stored value still resolves to the old image there, so _render's
      // same-src clear would otherwise unmask it mid-replace.
      if (this.hasAttribute('data-filled')) {
        this.setAttribute('data-swapping', '');
        this._swapGen = gen;
      }
      try {
        const w = this.clientWidth || this.offsetWidth || MAX_DIM;
        const url = await toDataUrl(file, w);
        if (gen !== this._gen) return;
        // Only exit reframe once the new image is in hand — a rejected type
        // or decode failure leaves the in-progress crop untouched.
        this._exitReframe(false);
        // Clear BEFORE setSlot: its synchronous re-render must see no
        // pending encode, so a byte-identical re-upload (same data URL, no
        // load event coming) still clears the mask via the complete branch.
        this._swapGen = 0;
        const val = {
          u: url,
          s: 1,
          x: 0,
          y: 0
        };
        setSlot(this.id || '', val);
        // Keep a session-local copy for id-less slots so the drop still
        // shows, even though it cannot persist.
        if (!this.id) {
          this._local = val;
          this._render();
        }
      } catch (err) {
        if (gen !== this._gen) return;
        this._swapGen = 0;
        // Reveal the kept old image — unless another replacement (a
        // remote pick's src swap) is still in flight, in which case the
        // mask stays until THAT image settles (its load/error releases).
        this._releaseMask();
        this._setError('Could not read that image.');
        console.warn('<image-slot> ingest failed:', err);
      }
    }
    _setError(msg) {
      if (this._err) {
        this._err.remove();
        this._err = null;
      }
      if (!msg) return;
      const d = document.createElement('div');
      d.className = 'err';
      d.textContent = msg;
      this.shadowRoot.appendChild(d);
      this._err = d;
      setTimeout(() => {
        if (this._err === d) {
          d.remove();
          this._err = null;
        }
      }, 3000);
    }

    // Reframing (pan/resize) is available on any filled slot — the user can
    // always reposition/scale. `fit` only sets the initial baseline (see
    // _geom): contain starts fully-visible, cover starts frame-filling.
    _reframes() {
      return this.hasAttribute('data-filled');
    }

    // The single release discipline for the replacement-in-flight mask
    // (data-swapping). The mask comes off only when BOTH hold:
    //  - no encode is pending (_swapGen) — mid-encode the stored value
    //    still resolves to the old image, so any reveal paints it;
    //  - the frame img has settled on its current src — an unsettled src
    //    means some replacement is still in flight (e.g. a remote pick),
    //    whoever started it, and revealing would paint the previous
    //    frame. The load/error listeners pass settled=true (the event IS
    //    the settlement signal, per spec complete is true by then);
    //    other callers rely on the complete flag (covers loaded AND
    //    failed).
    // Every release path funnels through here EXCEPT _render's empty
    // branch (the img is being cleared — nothing will ever settle).
    _releaseMask(settled) {
      if (!this._swapGen && !this._loadPending && (settled || this._img.complete)) {
        this.removeAttribute('data-swapping');
      }
    }

    // Baseline geometry, shared by clamp/apply/resize. `base` is the scale at
    // view-scale s=1: cover = fill the frame (overflow on the looser axis),
    // contain = fit fully inside (letterboxed). Zooming a contain image past
    // s where it overflows naturally becomes a crop. Null until the img has
    // loaded (naturalWidth is 0 before that) or when the slot has no layout
    // box — ResizeObserver fires with a 0×0 rect under display:none, and
    // clamping against a degenerate 1×1 frame would silently pull the stored
    // pan toward zero.
    _geom() {
      const iw = this._img.naturalWidth,
        ih = this._img.naturalHeight;
      const fw = this.clientWidth,
        fh = this.clientHeight;
      if (!iw || !ih || !fw || !fh) return null;
      const contain = (this.getAttribute('fit') || 'cover').toLowerCase() === 'contain';
      const base = contain ? Math.min(fw / iw, fh / ih) : Math.max(fw / iw, fh / ih);
      return {
        iw,
        ih,
        fw,
        fh,
        base
      };
    }
    _clampView() {
      // Pan range on each axis is half the overflow past the frame edge.
      const g = this._geom();
      if (!g) return;
      const mx = Math.max(0, (g.iw * g.base * this._view.s / g.fw - 1) * 50);
      const my = Math.max(0, (g.ih * g.base * this._view.s / g.fh - 1) * 50);
      this._view.x = Math.max(-mx, Math.min(mx, this._view.x));
      this._view.y = Math.max(-my, Math.min(my, this._view.y));
    }
    _applyView() {
      const g = this._geom();
      // Top-layer controls: pin to the frame's top-right in viewport px
      // (the same 8px inset as the in-frame layout; unscaled — top-layer UI
      // reads as chrome, not page content). BEFORE the geometry branch:
      // placement needs only the frame rect, and a not-yet-loaded or broken
      // src must not leave the promoted strip floating unpositioned. Gated
      // on the popover actually being open: without the Popover API,
      // showPopover() threw (swallowed in _enterReframe), .ctl stays in
      // its in-frame absolute layout, and viewport-px coordinates would
      // shove it off-frame — and matches(':popover-open') itself throws
      // there (unknown pseudo-class), hence the try/catch.
      if (this.hasAttribute('data-reframe')) {
        let onTop = false;
        try {
          onTop = this._ctl.matches(':popover-open');
        } catch {}
        if (onTop) {
          const r = this.getBoundingClientRect();
          this._ctl.style.left = r.right - 8 + 'px';
          this._ctl.style.top = r.top + 8 + 'px';
        }
      }
      if (!g) {
        // Dimensions not known yet (before img load) — centered fit so there
        // is no flash of an unpositioned image before the geometry lands.
        const contain = (this.getAttribute('fit') || 'cover').toLowerCase() === 'contain';
        this._img.style.width = '100%';
        this._img.style.height = '100%';
        this._img.style.left = '50%';
        this._img.style.top = '50%';
        this._img.style.objectFit = contain ? 'contain' : 'cover';
        return;
      }
      // Baseline (cover-fill or contain-fit) × view scale. Width/height and
      // left/top are all frame-% — depends only on the frame aspect ratio, so
      // a responsive resize keeps the same crop. The spill layer mirrors the
      // same box so its corners = image corners.
      const k = g.base * this._view.s;
      const w = g.iw * k / g.fw * 100 + '%';
      const h = g.ih * k / g.fh * 100 + '%';
      const l = 50 + this._view.x + '%';
      const t = 50 + this._view.y + '%';
      this._img.style.width = w;
      this._img.style.height = h;
      this._img.style.left = l;
      this._img.style.top = t;
      this._img.style.objectFit = '';
      if (this.hasAttribute('data-reframe')) {
        // Top-layer spill: position in viewport px over the frame. The top
        // layer escapes ancestor transforms entirely, so EVERY term must be
        // in viewport units: getBoundingClientRect gives the frame's scaled
        // origin AND size, and the rect/layout ratio rescales the ghost —
        // sizing from layout px alone renders it 1/scale too large under a
        // scaled deck slide. Inner ghost + handles stay box-relative.
        const r = this.getBoundingClientRect();
        const sx = g.fw ? r.width / g.fw : 1;
        const sy = g.fh ? r.height / g.fh : 1;
        this._spill.style.width = g.iw * k * sx + 'px';
        this._spill.style.height = g.ih * k * sy + 'px';
        this._spill.style.left = r.left + (50 + this._view.x) / 100 * r.width + 'px';
        this._spill.style.top = r.top + (50 + this._view.y) / 100 * r.height + 'px';
      }
    }
    _commitView() {
      const v = {
        s: this._view.s,
        x: this._view.x,
        y: this._view.y
      };
      if (this._userUrl) v.u = this._userUrl;
      // Framing-only (no u) persists too so an author-src slot remembers its
      // crop; clearing the sidecar still falls through to src=.
      if (this.id) setSlot(this.id, v);else {
        this._local = v;
      }
    }
    _render() {
      // Shape / mask. Presets use border-radius so the dashed ring can
      // follow the rounded outline; clip-path is only applied for an
      // explicit `mask` (the ring is hidden there since a rectangle
      // dashed border chopped by an arbitrary polygon looks broken).
      const mask = this.getAttribute('mask');
      const shape = (this.getAttribute('shape') || 'rounded').toLowerCase();
      let radius = '';
      if (shape === 'circle') radius = '50%';else if (shape === 'pill') radius = '9999px';else if (shape === 'rounded') {
        const n = parseFloat(this.getAttribute('radius'));
        radius = (Number.isFinite(n) ? n : 12) + 'px';
      }
      this._frame.style.borderRadius = mask ? '' : radius;
      this._frame.style.clipPath = mask || '';
      this._ring.style.borderRadius = mask ? '' : radius;
      this._ring.style.display = mask ? 'none' : '';

      // Controls and reframe entry gate on this so share links stay read-only.
      const editable = !!(window.omelette && window.omelette.writeFile);
      this.toggleAttribute('data-editable', editable);
      this._sub.style.display = editable ? '' : 'none';

      // Content. The sidecar is also writable by the agent's write_file
      // tool, so its value isn't guaranteed canvas-originated — only accept
      // data:image/ URLs from it. The `src` attribute is author-controlled
      // (Claude wrote it into the HTML) so it passes through unchanged.
      let stored = this.id ? getSlot(this.id) : this._local;
      if (stored && stored.u && !/^data:image\//i.test(stored.u)) stored = null;
      const srcAttr = this.getAttribute('src') || '';
      this._userUrl = stored && stored.u || null;
      const url = this._userUrl || srcAttr;
      // Don't clobber an in-flight reframe with a store-triggered re-render.
      if (!this.hasAttribute('data-reframe')) {
        this._view = {
          s: stored && Number.isFinite(stored.s) ? clampS(stored.s) : 1,
          x: stored && Number.isFinite(stored.x) ? stored.x : 0,
          y: stored && Number.isFinite(stored.y) ? stored.y : 0
        };
      }
      this._cap.textContent = this.getAttribute('placeholder') || 'Drop an image';
      // Toggle via style.display — the [hidden] attribute alone loses to
      // the display:flex / display:block rules in the stylesheet above.
      // An Unsplash src with no credit attribute must NOT render — showing
      // the photo uncredited is the Unsplash-terms violation itself. The
      // error tile replaces the photo until the credit is written. A
      // user-dropped image is the user's own content and always renders.
      // Trimmed: credit is agent/user-editable content, and a whitespace-
      // only value must count as missing — otherwise it would suppress the
      // error tile AND render an empty credit box (no text, no links),
      // exactly the unattributed state this gate exists to prevent.
      const credit = (this.getAttribute('credit') || '').trim();
      const attrError = !!(!credit && !this._userUrl && srcAttr && isUnsplashHost(srcAttr));
      this.toggleAttribute('data-attribution-error', attrError);
      if (url && !attrError) {
        const prev = this._img.getAttribute('src');
        if (prev !== url) {
          // Replacing an already-shown image: mark the swap BEFORE setting
          // src so the stale frame is never revealed (see the data-swapping
          // stylesheet rules). First fill (prev empty) keeps the existing
          // placeholder-until-load behavior — no spinner. _hidShowing
          // covers the pick path's transient attribution-error wipe: prev
          // is gone, but an image WAS showing, so this is a replacement.
          if (prev || this._hidShowing) this.setAttribute('data-swapping', '');
          // Mark the swap BEFORE assigning src: complete keeps reporting
          // the old settled request until the browser's
          // update-the-image-data microtask runs, so same-task re-renders
          // (the pick path's credit/credit-href setAttributes) need this
          // flag, not complete, to know a load is in flight.
          this._loadPending = true;
          this._img.src = url;
          this._ghost.src = url;
        } else {
          // Same-src re-render — release if settled, so an ingest-set
          // spinner can't stick after a byte-identical re-upload (same
          // data URL, no further load event ever fires).
          this._releaseMask();
        }
        this._hidShowing = false;
        this._img.style.display = 'block';
        this._empty.style.display = 'none';
        this.setAttribute('data-filled', '');
        this._clampView();
        this._applyView();
      } else {
        this.removeAttribute('data-swapping');
        // The src is being removed — no load/error will ever fire for it.
        this._loadPending = false;
        // A transient attribution-error wipe of a showing image happens on
        // the pick path: the host sets src one setAttribute before credit,
        // so render N hides the old image (attrError) and render N+1
        // restores a URL. Remember the wipe so that restore renders as a
        // replacement (spinner), not a first fill (blank frame).
        this._hidShowing = attrError && !!this._img.getAttribute('src');
        this._img.style.display = 'none';
        this._img.removeAttribute('src');
        this._ghost.removeAttribute('src');
        // The error tile owns the blocked-photo state; .empty stays for
        // the genuinely-empty slot.
        this._empty.style.display = attrError ? 'none' : 'flex';
        this.removeAttribute('data-filled');
      }

      // Credit belongs to the author src, so a user drop hides it.
      // textContent + the http(s)-only funnel keep external strings inert.
      const showCredit = !!(url && credit && !this._userUrl && !attrError);
      this._credit.textContent = '';
      if (showCredit) {
        // Validate once (resolved against the document, http(s) only),
        // then append the terms-required utm referral params to links
        // that point back at unsplash.com.
        let href = '';
        const rawHref = this.getAttribute('credit-href') || '';
        if (rawHref) {
          try {
            const u = new URL(rawHref, document.baseURI);
            if (u.protocol === 'http:' || u.protocol === 'https:') {
              href = withReferral(u.href);
            }
          } catch {}
        }
        const mkLink = (text, linkHref) => {
          const a = document.createElement('a');
          a.setAttribute('target', '_blank');
          a.setAttribute('rel', 'noopener noreferrer');
          a.setAttribute('href', linkHref);
          a.textContent = text;
          return a;
        };
        // Unsplash's prescribed credit is TWO links — the photographer's
        // name to their profile (credit-href) and 'Unsplash' to the
        // homepage. Render that split whenever the text has the canonical
        // shape; other text keeps the legacy single-link rendering.
        const m = /^Photo by (.+) on Unsplash$/.exec(credit);
        if (m) {
          this._credit.appendChild(document.createTextNode('Photo by '));
          this._credit.appendChild(href ? mkLink(m[1], href) : document.createTextNode(m[1]));
          this._credit.appendChild(document.createTextNode(' on '));
          this._credit.appendChild(mkLink('Unsplash', UNSPLASH_HOMEPAGE_HREF));
        } else if (href) {
          this._credit.appendChild(mkLink(credit, href));
        } else {
          this._credit.textContent = credit;
        }
      }
      this.toggleAttribute('data-credit', showCredit);
    }
  }
  if (!customElements.get('image-slot')) {
    customElements.define('image-slot', ImageSlot);
  }
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/neuruh-com/image-slot.js", error: String((e && e.message) || e) }); }

__ds_ns.ICON_NAMES = __ds_scope.ICON_NAMES;

__ds_ns.ICON_PATHS = __ds_scope.ICON_PATHS;

__ds_ns.Wordmark = __ds_scope.Wordmark;

__ds_ns.Seal = __ds_scope.Seal;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.DataTable = __ds_scope.DataTable;

__ds_ns.EmptyState = __ds_scope.EmptyState;

__ds_ns.KeyValue = __ds_scope.KeyValue;

__ds_ns.Sparkline = __ds_scope.Sparkline;

__ds_ns.ConfidenceMeter = __ds_scope.ConfidenceMeter;

__ds_ns.EvidenceChip = __ds_scope.EvidenceChip;

__ds_ns.ProvenanceTrail = __ds_scope.ProvenanceTrail;

__ds_ns.Stat = __ds_scope.Stat;

__ds_ns.Dialog = __ds_scope.Dialog;

__ds_ns.Progress = __ds_scope.Progress;

__ds_ns.StatusDot = __ds_scope.StatusDot;

__ds_ns.Toast = __ds_scope.Toast;

__ds_ns.Tooltip = __ds_scope.Tooltip;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Field = __ds_scope.Field;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Radio = __ds_scope.Radio;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.Breadcrumbs = __ds_scope.Breadcrumbs;

__ds_ns.NavItem = __ds_scope.NavItem;

__ds_ns.Tabs = __ds_scope.Tabs;

__ds_ns.TopBar = __ds_scope.TopBar;

__ds_ns.SceneFrame = __ds_scope.SceneFrame;

__ds_ns.SoundToggle = __ds_scope.SoundToggle;

})();
