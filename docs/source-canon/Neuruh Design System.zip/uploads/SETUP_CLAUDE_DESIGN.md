# Claude Design Setup — Prevent Generic Output

## Principle

Claude Design is the visual compiler and prototype environment. It is not the sole art
director, 3D modeling suite, performance engineer, or production runtime.

Its output quality is bounded by the quality of the source design system and reference
packet. Do not feed it the current Blackbox console as the only source unless you want
every product to inherit the same terminal language.

## Build three design-system layers

### 1. Neuruh Master Brand
Contains:

- logo and marks;
- master typography principles;
- core color semantics;
- icon principles;
- photography/illustration principles;
- evidence and trust language;
- motion principles;
- voice and copy hierarchy.

### 2. Neuruh Flagship World
Used by Neuruh.com and flagship presentations:

- cinematic display typography;
- spatial materials;
- lighting palette;
- depth rules;
- hero composition;
- 3D object language;
- editorial sections;
- scroll choreography;
- sound principles.

### 3. Product-Specific Systems
Separate systems for:

- DeedSonar;
- Founder Command;
- Cockpit/Galaxy;
- Adaptive Intelligence;
- Field Scout;
- LARIC;
- Find Sell Profit;
- Lead Recipe OS.

They may inherit Master Brand semantics without sharing identical page composition.

## Source assets to prepare before setup

Create a clean package containing:

- approved logo files;
- approved color tokens;
- type scale;
- 8–15 exemplary screens or frames;
- component states;
- visual-recipe cards;
- motion storyboards;
- reference cards;
- anti-reference register;
- copy examples;
- accessibility rules.

Do not upload fifteen inconsistent repositories and ask the system to discover truth.

## Claude Design workflow

1. Create or select the correct organization.
2. Set up the clean Neuruh design system.
3. Create one project per product/direction.
4. Attach the product underwrite and reference packet.
5. Ask for three directions before selecting one.
6. Save each direction before exploring another.
7. Use direct canvas editing for alignment and sizing.
8. Use inline comments for local corrections.
9. Use chat for structural changes.
10. Pull the design system into Claude Code with `/design-sync`.
11. Handoff only after `DESIGN_LOCK.yaml` is complete.

## Claude Code connection

From Claude Code:

```bash
claude mcp add --scope user --transport http claude-design https://api.anthropic.com/v1/design/mcp
/design-login
/design-sync
```

Confirm current Anthropic instructions before running commands because beta workflows can change.

## Constraint routing

When Claude Design reaches a limitation:

- 3D form problem → Spline or Blender.
- complex camera/timeline problem → Theatre.js or GSAP prototype.
- production shader problem → Three.js/R3F technical spike.
- interactive vector problem → Rive.
- exact component problem → Figma or coded Storybook.
- performance question → measured coded prototype.
- large repository question → Claude Code, not browser-only import.
- generated 3D asset question → model demo, then Blender cleanup and web optimization.

Never respond to a tool limitation by reducing the product vision prematurely. Route the
problem to the correct specialist environment, prove the capability, then integrate it.
