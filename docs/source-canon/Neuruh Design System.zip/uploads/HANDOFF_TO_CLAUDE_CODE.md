# Handoff from Claude Design to Claude Code

## Handoff package

- selected recipe;
- prototype;
- design-system source;
- tokens;
- frame exports;
- interaction annotations;
- motion storyboard;
- spatial-scene contract;
- asset manifest;
- responsive spec;
- reduced-motion spec;
- acceptance screenshots;
- `DESIGN_LOCK.yaml`;
- unresolved technical questions.

## Claude Code opening instruction

Read the entire handoff package before modifying code. Produce:

1. repository audit;
2. compatibility report;
3. implementation plan;
4. package decisions;
5. technical spikes;
6. fixture-data plan;
7. test plan;
8. blue-green environment plan.

Do not write production components until the plan and technical spike are approved.
Do not reinterpret the design. Surface conflicts instead of silently simplifying.
