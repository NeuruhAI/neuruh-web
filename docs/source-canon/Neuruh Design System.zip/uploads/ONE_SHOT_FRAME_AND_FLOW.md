# ONE-SHOT — Claude Design: Selected Direction Frame and Flow

Using only the selected recipe and the approved imported elements, build a high-fidelity
prototype of the product's critical path.

Required:

- orientation frame;
- signature interaction;
- decision/output frame;
- evidence/provenance inspector;
- loading;
- populated;
- empty;
- error;
- denied/locked;
- mobile critical path;
- reduced-motion version;
- keyboard path;
- annotations for every non-obvious interaction.

Use realistic fixture data. No lorem ipsum. Do not expand scope beyond the critical path.
Do not introduce new visual systems. Save a version before each material structural
change.

At completion, export:

- shareable prototype;
- standalone HTML or ZIP where supported;
- PDF frame deck;
- design decision log;
- exact list of unresolved engineering questions.
