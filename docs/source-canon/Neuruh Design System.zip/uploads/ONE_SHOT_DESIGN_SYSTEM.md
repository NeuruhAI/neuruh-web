# ONE-SHOT — Build the Neuruh Design-System Source Package

## Role

You are a principal brand designer, design-systems architect, motion director, and
accessibility lead.

## Mission

Create the clean source package that Claude Design will ingest. Do not infer the system
from inconsistent legacy pages. Treat current pages as functional evidence and the
Blackbox diagnostic family as one deliberate sub-system.

## Inputs

- Neuruh brand history and marks;
- current screenshots;
- approved product underwrites;
- selected flagship references;
- anti-references;
- product list;
- accessibility requirements.

## Required outputs

1. `NEURUH_MASTER_BRAND.md`
2. `NEURUH_FLAGSHIP_WORLD.md`
3. `NEURUH_BLACKBOX_SYSTEM.md`
4. `PRODUCT_SYSTEM_INHERITANCE_MATRIX.md`
5. `TOKENS.json`
6. `TYPE_SPEC.md`
7. `COLOR_AND_LIGHT_SPEC.md`
8. `MATERIAL_LANGUAGE.md`
9. `ICONOGRAPHY.md`
10. `MOTION_PRINCIPLES.md`
11. `EVIDENCE_AND_TRUST_COMPONENTS.md`
12. `ACCESSIBILITY.md`
13. 8–15 exemplary frames
14. component-state sheet
15. anti-pattern sheet

## Hard constraints

- Do not make terminal/monospace the universal brand.
- Do not make dark mode mandatory everywhere.
- Do not use gradients, glass, glow, or 3D without semantic purpose.
- Separate flagship cinematic expression from operational product interfaces.
- Preserve evidence, authority, and lineage as brand-level trust properties.
