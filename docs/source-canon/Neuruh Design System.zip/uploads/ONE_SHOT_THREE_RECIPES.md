# ONE-SHOT — Claude Design: Generate Three Visual Recipes

Paste this into a new Claude Design project after attaching the underwrite, reconnaissance
pack, source design system, and current screenshots.

---

Act as a world-class product design studio composed of a design director, interaction
designer, creative technologist, information architect, motion director, and senior
front-end engineer.

Do not produce a generic SaaS dashboard. Do not inherit the current terminal aesthetic
except where explicitly classified as Neuruh Blackbox diagnostics.

Create exactly three materially different visual and interaction directions for the
attached product.

For each direction, provide:

1. Direction name and one-sentence thesis.
2. Central metaphor.
3. Five-second product understanding.
4. Desktop primary frame.
5. Desktop decisive-output frame.
6. Mobile critical frame.
7. Signature interaction storyboard.
8. Navigation and information architecture.
9. Component sample board.
10. Loading, populated, empty, error, permission, and offline states where applicable.
11. Typography, color, material, imagery, depth, motion, and sound position.
12. What remains 2D and what becomes 3D.
13. Specialist technology justification.
14. Accessibility and reduced-motion behavior.
15. Performance risk.
16. What the direction deliberately refuses to become.
17. Reference IDs used and the principle extracted from each.

The three directions must differ in layout, metaphor, density, interaction model, motion,
and spatial depth. Do not create three color variants.

After presenting all three, create a comparison matrix. Do not merge them and do not
start production code.
