# NEURUH SPATIAL PRODUCT STUDIO OS v1

This package prevents generic AI-generated software by separating product definition,
visual reconnaissance, art direction, specialist technology, prototyping, production
engineering, performance hardening, and release cutover.

## Core rule

**Share the foundation. Never share the face.**

Shared infrastructure may include authentication, permissions, data access, telemetry,
testing, deployment, accessibility primitives, and basic interface components.

Each product must independently define its:

- central metaphor;
- signature interaction;
- information architecture;
- visual language;
- motion language;
- product vocabulary;
- evidence model;
- emotional target;
- technology justification;
- performance budget;
- acceptance criteria.

## Do not run this as one mega-prompt

Use the stages in order:

1. Product underwrite
2. Visual reconnaissance
3. Reference synthesis
4. Three design recipes
5. Selected-direction prototype
6. Design lock
7. Technical spike
8. Production build
9. Visual and functional QA
10. Blue-green release cutover

Every stage consumes the approved artifacts from the previous stage.

## Primary destinations

- **Claude Design:** visual system, screen directions, flows, high-fidelity frames, prototypes
- **Spline / Blender:** authored spatial scenes and production-ready 3D assets
- **Rive:** stateful vector animation and micro-interaction systems
- **GSAP / Theatre.js:** authored timelines, scroll choreography, camera and scene sequencing
- **Three.js / React Three Fiber:** production spatial runtime
- **Claude Code / Codex:** repository integration, engineering, tests, deployment
- **Figma:** precise design review, components, token governance, annotation
- **GitHub:** canonical source, reusable packages, issue tracking, versioned design contracts
- **Hugging Face:** experimental asset generation and model evaluation—not unreviewed production assets

## Neuruh.com mandate

Neuruh.com is the flagship expression of the entire ecosystem. It is not a normal SaaS
landing page and it is not another terminal dashboard. It must combine cinematic spatial
storytelling with immediate business clarity, remain fast and accessible, and establish
the visual quality bar every downstream product must meet without forcing every product
to copy its appearance.

Start with:

- `08_MASTER_RUNBOOK/EXECUTION_SEQUENCE.md`
- `03_CLAUDE_DESIGN/SETUP_CLAUDE_DESIGN.md`
- `04_NEURUH_COM/NEURUH_COM_FLAGSHIP_UNDERWRITE.md`
- `08_MASTER_RUNBOOK/MASTER_ORCHESTRATOR_PROMPT.md`
